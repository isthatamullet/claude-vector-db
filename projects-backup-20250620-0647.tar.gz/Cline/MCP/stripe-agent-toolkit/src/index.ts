#!/usr/bin/env node
import { StripeAgentToolkit } from "@stripe/agent-toolkit/modelcontextprotocol";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import dotenv from 'dotenv';

dotenv.config();

const server = new StripeAgentToolkit({
  secretKey: process.env.STRIPE_SECRET_KEY!,
  configuration: {
    actions: {
      customers: {
        create: true,
      },
      coupons: {
        create: true,
      },
      products: {
        create: true,
      },
      prices: {
        create: true,
      },
      paymentLinks: {
        create: true,
      },
      invoices: {
        create: true,
      },
      invoiceItems: {
        create: true,
      },
      balance: {},
      subscriptions: {
        update: true,
      },
      refunds: {
        create: true,
      },
      disputes: {
        update: true,
      },
    },
  },
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Stripe MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error in main():", error);
  process.exit(1);
});
