#!/usr/bin/env node
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
} from '@modelcontextprotocol/sdk/types.js';
import { Pool } from 'pg';
import { createClient, SupabaseClient } from '@supabase/supabase-js'; // Import createClient and SupabaseClient

const DATABASE_URL = process.env.DATABASE_URL;
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is required.');
}

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  throw new Error('Supabase environment variables (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY) are required for admin functions.');
}

class SupabaseMcpServer {
  private server: Server;
  private pool: Pool;
  private supabaseAdmin: SupabaseClient; // Supabase client for admin functions

  constructor() {
    this.server = new Server(
      {
        name: 'supabase-mcp-server',
        version: '0.1.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.pool = new Pool({
      connectionString: DATABASE_URL,
      ssl: {
        rejectUnauthorized: false, // Required for Supabase connections
      },
    });

    this.supabaseAdmin = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    this.setupToolHandlers();
    
    this.server.onerror = (error) => console.error('[MCP Error]', error);
    process.on('SIGINT', async () => {
      await this.server.close();
      await this.pool.end();
      process.exit(0);
    });
  }

  private setupToolHandlers() {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: [
        {
          name: 'execute_sql_query',
          description: 'Executes a SQL query against the Supabase PostgreSQL database.',
          inputSchema: {
            type: 'object',
            properties: {
              query: {
                type: 'string',
                description: 'The SQL query string to execute.',
              },
              params: {
                type: 'array',
                description: 'Optional array of parameters for the SQL query.',
              },
            },
            required: ['query'],
          },
        },
        {
          name: 'get_table_schema',
          description: 'Retrieves the schema (column names and data types) for a specified table.',
          inputSchema: {
            type: 'object',
            properties: {
              tableName: {
                type: 'string',
                description: 'The name of the table.',
              },
            },
            required: ['tableName'],
          },
        },
        {
          name: 'create_user',
          description: 'Creates a new user in Supabase Auth via admin API.',
          inputSchema: {
            type: 'object',
            properties: {
              email: {
                type: 'string',
                description: 'The email address for the new user.',
              },
              password: {
                type: 'string',
                description: 'The password for the new user.',
              },
            },
            required: ['email', 'password'],
          },
        },
      ],
    }));

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      switch (request.params.name) {
        case 'execute_sql_query':
          const { query, params } = request.params.arguments as { query: string; params?: any[] };
          try {
            const client = await this.pool.connect();
            try {
              const result = await client.query(query, params);
              return {
                content: [
                  {
                    type: 'text',
                    text: JSON.stringify(result.rows, null, 2),
                  },
                ],
              };
            } finally {
              client.release();
            }
          } catch (error: any) {
            return {
              content: [
                {
                  type: 'text',
                  text: `SQL execution error: ${error.message}`,
                },
              ],
              isError: true,
            };
          }

        case 'get_table_schema':
          const { tableName } = request.params.arguments as { tableName: string };
          try {
            const client = await this.pool.connect();
            try {
              const result = await client.query(
                `SELECT column_name, data_type FROM information_schema.columns WHERE table_name = $1;`,
                [tableName]
              );
              return {
                content: [
                  {
                    type: 'text',
                    text: JSON.stringify(result.rows, null, 2),
                  },
                ],
              };
            } finally {
              client.release();
            }
          } catch (error: any) {
            return {
              content: [
                {
                  type: 'text',
                  text: `Failed to get schema for table '${tableName}': ${error.message}`,
                },
              ],
              isError: true,
            };
          }

        case 'create_user':
          const { email, password } = request.params.arguments as { email: string; password: string };
          try {
            const { data, error } = await this.supabaseAdmin.auth.admin.createUser({
              email,
              password,
              email_confirm: true, // Automatically confirm email for test users
            });

            if (error) {
              throw new Error(error.message);
            }

            // Also create a corresponding profile entry
            if (data.user) {
              const { error: profileError } = await this.supabaseAdmin
                .from('profiles')
                .insert({ id: data.user.id, email: data.user.email, full_name: data.user.email?.split('@')[0] }); // Basic profile

              if (profileError) {
                console.warn('Warning: Failed to create profile for new user:', profileError.message);
                // Don't throw, as user was created in auth.users
              }
            }

            return {
              content: [
                {
                  type: 'text',
                  text: JSON.stringify({ userId: data.user?.id, email: data.user?.email }, null, 2),
                },
              ],
            };
          } catch (error: any) {
            return {
              content: [
                {
                  type: 'text',
                  text: `Failed to create user: ${error.message}`,
                },
              ],
              isError: true,
            };
          }

        default:
          throw new McpError(
            ErrorCode.MethodNotFound,
            `Unknown tool: ${request.params.name}`
          );
      }
    });
  }

  async run() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error('Supabase MCP server running on stdio');
  }
}

const server = new SupabaseMcpServer();
server.run().catch(console.error);
