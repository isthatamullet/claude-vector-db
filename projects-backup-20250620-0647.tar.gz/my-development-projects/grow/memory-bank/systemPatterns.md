# System Patterns for Grow Plant Store

## System Architecture
The Grow Plant Store will primarily follow a client-server architecture, with a React-based frontend consuming data from a Supabase backend.

## Key Technical Decisions
- **Frontend Framework:** React 18+ with Vite for fast development and build.
- **Styling:** Tailwind CSS for utility-first styling, configured with design tokens from `design-system.md`.
- **State Management:** Zustand for efficient and scalable global state management.
- **Animations:** Framer Motion for smooth UI animations and parallax effects.
- **Backend:** Supabase for database, authentication, and storage.
- **Image Handling:** Pixabay API for placeholder images, with a plan for future integration of actual product images.
- **Forms:** React Hook Form with Zod for robust form validation.
- **Routing:** React Router for client-side navigation.

## Design Patterns in Use
- **Component-Based Architecture:** UI is composed of reusable React components (e.g., `ui/`, `product/`, `cart/`).
- **Mobile-First Responsive Design:** Layouts are designed for mobile first, then progressively enhanced for larger screens.
- **Modular Store Design:** Zustand stores are designed to be modular and focused on specific domains (e.g., `cartStore.ts`, `productStore.ts`).
- **API Service Layer:** A utility layer (`utils/pixabayApi.ts`) for interacting with external APIs.

## Component Relationships
- **Layout Components:** `Header`, `Footer`, and navigation components provide the overall page structure.
- **UI Components:** Reusable atomic components like `Button`, `Card`, `Input` are used across the application.
- **Product Components:** Specific components for displaying product listings, details, and related actions.
- **Cart Components:** Components managing shopping cart functionality.
- **Page Components:** Top-level components (`Home`, `Plants`, `Supplies`, `Services`, `OrderNow`) orchestrate other components to form complete views.

## Critical Implementation Paths
- **E-commerce Flow:** Product browsing -> Add to cart -> Checkout -> Payment.
- **User Authentication:** (Future integration with Supabase Auth).
- **Parallax Effects:** Careful implementation to ensure smooth performance across devices.
- **Data Fetching and State Sync:** Efficiently fetching and updating data from Supabase and synchronizing with Zustand stores.
