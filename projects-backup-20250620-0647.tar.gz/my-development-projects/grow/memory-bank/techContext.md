# Technical Context for Grow Plant Store

## Technologies Used
- **Frontend Framework:** React 18+
- **Build Tool:** Vite
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **State Management:** Zustand
- **Animations:** Framer Motion
- **Backend:** Supabase (for database, authentication, storage)
- **Image API:** Pixabay API
- **Forms:** React Hook Form
- **Validation:** Zod
- **Routing:** React Router

## Development Setup
- **Environment:** VS Code web browser on iPad (as per `.clinerules/rules.md`)
- **Package Manager:** npm (or yarn, based on `package.json`)
- **Local Development Server:** Provided by Vite (`npm run dev`)

## Technical Constraints
- No external dependencies beyond the specified tech stack.
- Must work in modern browsers (Chrome, Firefox, Safari, Edge).
- Mobile-first development approach is mandatory.
- Performance targets: Page load time < 3 seconds, 60fps for animations.

## Dependencies
Dependencies are managed via `package.json`. Key dependencies include:
- `react`, `react-dom`
- `tailwindcss`, `postcss`, `autoprefixer`
- `zustand`
- `framer-motion`
- `react-router-dom`
- `react-hook-form`, `zod`
- `@supabase/supabase-js` (future integration)
- `axios` (or `fetch` for API calls)

## Tool Usage Patterns
- `read_file`, `write_to_file`, `replace_in_file` for file modifications.
- `execute_command` for running CLI commands (e.g., `npm install`, `npm run dev`).
- `browser_action` for testing and verifying UI in the browser.
- `search_files` for code exploration.
- `list_code_definition_names` for understanding codebase structure.
- `use_mcp_tool` and `access_mcp_resource` for interacting with MCP servers (e.g., GitHub, Supabase, Sequential Thinking).

## Available MCP Servers
- **GitHub Server:** For repository management, file operations, and issue tracking.
- **Supabase Server:** For database operations, user authentication, and data management.
- **Filesystem Server:** For local file system operations within allowed directories.
- **Context7 MCP:** For accessing up-to-date library documentation.
- **Puppeteer Server:** For browser automation and testing.
- **Sequential Thinking Server:** For complex problem-solving scenarios requiring step-by-step analysis and reasoning.
