# Consolidated Learnings

## Project Grow - Current Status & Next Steps

### Implemented Foundations:
- **Core Tech Stack:** React, Vite, TypeScript, Tailwind CSS, Framer Motion, Zustand, React Hook Form, Zod, React Router DOM are correctly set up and integrated.
- **Design System Adherence:** Comprehensive design system (colors, typography, spacing, breakpoints, component base styles) is defined in `src/index.css` and consistently applied in core UI components (`Button`, `Card`, `Input`).
- **Type Safety:** Extensive TypeScript types are defined in `src/types/index.ts`, ensuring strong typing across the application.
- **Image Handling:** Pixabay API integration (`src/utils/pixabayApi.ts`) is functional for placeholder images, including JSONP and fallbacks.
- **Cart Management:** Robust cart state management (`src/store/cartStore.ts`) using Zustand with persistence, accurate total calculations, and mock discount logic.
- **Product Data (Client-side):** `src/store/productStore.ts` manages product data (plants, supplies, services) and provides basic client-side search/filter state.
- **Supabase Integration (Initial):** Supabase client is integrated. Product data (plants, supplies, services) and reviews are now fetched from Supabase tables. Sample data has been successfully inserted into `plants`, `supplies`, `services`, and `reviews` tables.
- **User Authentication & Wishlist:** Sign In/Sign Up pages, Zustand user store with persistence, dynamic header integration, and wishlist functionality are implemented.

### Key Missing Implementations (Prioritized by PRD):

1.  **Backend Integration (Continued):**
    *   **Product Data & Inventory:** Fully replace all mock data with real API calls for product data and inventory management.
    *   **Order Processing:** Integrate cart and checkout with a backend for order submission and payment processing.
    *   **User Authentication:** Fully integrate user authentication with Supabase Auth for persistent user sessions and profile management.

2.  **E-commerce Core Functionality:**
    *   **Advanced Product Catalog Features:** High-resolution image zoom, 360 views, product videos (on detail pages).
    *   **Intelligent Search:** Implement predictive search with auto-suggestions, natural language processing, and visual search capabilities.
    *   **Shopping Cart & Checkout Enhancements:** One-click checkout option, multiple payment methods (Credit cards, PayPal, Apple Pay, Google Pay), Buy Now, Pay Later integration.
    *   **Inventory Management:** Develop a dashboard or system for real-time stock levels, low stock notifications, and out-of-stock handling.
    *   **User Reviews and Ratings System:** Implement the ability for users to leave reviews and ratings for products.
    *   **Missing Static Pages:** Privacy, Terms, About, Contact, etc.

3.  **UX/UI Enhancements:**
    *   **Product Detail Page Rendering Fix:** Resolve the current issue where the Product Detail page content is not fully visible despite data being fetched. This is a high priority.
    *   **Service Booking System:** Develop a more robust booking flow for services (e.g., calendar integration, pricing calculator).
    *   **Interactive FAQ:** Add expand/collapse functionality to the FAQ section on the Services page.
    *   **Additional UX Features:** Recently Viewed Products, Product Comparison, and Live Chat.
    *   **Parallax Scrolling Effects:** Full implementation of Homepage Hero Parallax, Product Showcase Parallax, Services Section Parallax, and About Section Parallax, ensuring performance optimization.

4.  **Performance & SEO:**
    *   Implement lazy loading for images and components.
    *   Implement code splitting.
    *   Optimize caching strategies using `React Query/TanStack Query`.
    *   Implement SEO requirements (meta tags, structured data, sitemap).

### General Learnings:
- **Mock Data Strategy:** Using mock data and Pixabay API for initial frontend development is effective for building out UI and state management independently, but clearly highlights the need for robust backend integration for full application functionality.
- **Progressive Enhancement:** The current structure allows for progressive enhancement, starting with basic functionality and adding advanced features like parallax and full booking systems later.
- **Design System Importance:** Strict adherence to the design system (CSS variables, component classes) ensures consistency and simplifies styling across the application.
- **Zustand State Management (Async Actions & Persistence):**
    - When defining asynchronous actions in Zustand stores, especially with `persist` middleware, ensure that actions returning promises are typed as `Promise<void>` in the store interface.
    - In the implementation, call `resolve()` without arguments after state updates to avoid TypeScript errors related to `set` function's callback return types.
    - Example: `login: (email: string, password: string) => Promise<void>;` and `resolve();`
- **File Editing Strategy:**
    - For complex or multi-line code modifications, or after repeated failures with `replace_in_file` due to exact matching issues, prioritize using `write_to_file` as a reliable fallback. This ensures atomicity and avoids iterative matching problems.
- **Operational Resilience (Rate Limiting):**
    - Implement adaptive delays between tool uses (e.g., 5 seconds) via `.clinerules` to mitigate API rate limit errors (429 Too Many Requests). Increase delay dynamically upon encountering such errors.
- **Supabase Integration Specifics:**
    - **Column Casing:** Supabase database columns are case-sensitive and often default to lowercase, requiring frontend types and data payloads to match exactly (e.g., `careinstructions` instead of `careInstructions`).
    - **Row Level Security (RLS):** RLS policies can block data insertion/modification by unauthenticated users. For initial data seeding or development, RLS may need to be temporarily disabled or bypassed using a service role key (if the MCP tool supports it).
    - **MCP Tool Limitations:** The `supabase-server` MCP tool's `filters` parameter does not support complex operators like `or` for `update_table` and `delete_from_table` operations, requiring individual calls for multiple targets.
- **Debugging Rendering Issues:**
    - When content is not visible despite data being fetched, the problem is likely a CSS/layout conflict within the component's JSX.
    - Use fixed-position, high-z-index debugging elements to confirm if the component is rendering at all.
    - Systematically simplify the component's internal layout (e.g., remove grids, complex nesting) and gradually reintroduce elements to pinpoint the exact problematic CSS class or structural element.
- **Tailwind CSS Configuration for Customization:** While newer Tailwind versions might offer "zero-config" for basic setups, projects with custom design systems (colors, typography, plugins) explicitly require a `tailwind.config.js` file to define and apply these customizations. The absence of this file will result in unstyled components.
- **Environmental Network Issues (Re-evaluated):** `net::ERR_NAME_NOT_RESOLVED` errors, while appearing to be network/DNS problems, can also be a symptom of external API policies (like hotlinking restrictions). Intermittent loading from the same domain can occur due to caching, specific CDN node issues, or active blocking.
- **External API Compliance (Hotlinking):** Always verify API terms of service, especially regarding hotlinking. Pixabay explicitly disallows permanent hotlinking of images, requiring them to be downloaded and served locally. Unsplash, conversely, explicitly requires hotlinking. This is a critical factor for reliable image display.
- **Image Loading Strategy:** For permanent image display, prefer hosting images locally or using APIs that explicitly allow hotlinking. Implement `onError` fallbacks for all external images to ensure graceful degradation (displaying a placeholder) if an image fails to load for any reason.
- **Tool Limitations (Browser Automation):** Programmatically extracting full text content from complex web documentation pages using browser automation tools (like `browser_action` or `puppeteer_evaluate`) can be unreliable due to dynamic content, complex layouts, or limitations in how the tool captures/returns data. In such cases, manual provision of documentation text by the user is a more reliable alternative.

## MCP Server Management

- **MCP Server Installation (Global vs Local Settings):** The active MCP configuration is stored in the global settings file at `../.codeoss/data/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json`, not in local project `cline_mcp_settings.json` files. Always update the global settings file when installing new MCP servers.
- **MCP Server Configuration Requirements:** New MCP servers must include both `disabled: false` and `autoApprove: []` properties in their configuration to be properly recognized by the system.
- **Sequential Thinking MCP Tool:** Highly effective for complex problem-solving scenarios requiring step-by-step analysis. Maintains thought history, allows dynamic adjustment of total thoughts needed, and supports hypothesis generation and verification. Ideal for planning, design with revision potential, and multi-step solutions.
