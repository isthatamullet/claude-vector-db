import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://bemkjohbifzmrxacqymo.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJlbWtqb2hiaWZ6bXJ4YWNxeW1vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg1NzQzNzcsImV4cCI6MjA2NDE1MDM3N30.9WGeyijxL4LciX2nIiR8wKY0JW_93YUg2l7T8mXBYvE';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
