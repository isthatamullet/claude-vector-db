const PIXABAY_API_KEY = '50523160-a1585f1d1edc8217bd4bef1a6';
const PIXABAY_BASE_URL = 'https://pixabay.com/api/';

export interface PixabayImage {
  id: number;
  webformatURL: string;
  largeImageURL: string;
  tags: string;
  user: string;
  views: number;
  downloads: number;
  likes: number;
}

export interface PixabayResponse {
  total: number;
  totalHits: number;
  hits: PixabayImage[];
}

// JSONP implementation for cross-origin requests
const jsonp = (url: string): Promise<any> => {
  return new Promise((resolve, reject) => {
    const callbackName = 'pixabay_callback_' + Math.random().toString(36).substr(2, 9);
    const script = document.createElement('script');
    
    // Set up the callback
    (window as any)[callbackName] = (data: any) => {
      document.head.removeChild(script);
      delete (window as any)[callbackName];
      resolve(data);
    };
    
    // Handle errors
    script.onerror = () => {
      document.head.removeChild(script);
      delete (window as any)[callbackName];
      reject(new Error('JSONP request failed'));
    };
    
    // Make the request
    script.src = url + '&callback=' + callbackName;
    document.head.appendChild(script);
  });
};

export const searchPixabayImages = async (
  query: string,
  perPage: number = 20,
  category: string = ''
): Promise<PixabayImage[]> => {
  try {
    // Ensure per_page is at least 3 (Pixabay minimum)
    const validPerPage = Math.max(perPage, 3);
    
    // Build URL for JSONP request
    let url = `${PIXABAY_BASE_URL}?key=${PIXABAY_API_KEY}&q=${encodeURIComponent(query)}&image_type=photo&per_page=${validPerPage}&safesearch=true`;
    
    // Only add category if it's a valid value
    if (category && ['backgrounds', 'fashion', 'nature', 'science', 'education', 'feelings', 'health', 'people', 'religion', 'places', 'animals', 'industry', 'computer', 'food', 'sports', 'transportation', 'travel', 'buildings', 'business', 'music'].includes(category)) {
      url += `&category=${category}`;
    }

    console.log('Pixabay JSONP URL:', url);

    const data: PixabayResponse = await jsonp(url);
    console.log('Pixabay API response:', data);
    return data.hits || [];
  } catch (error) {
    console.error('Error fetching images from Pixabay:', error);
    // Return fallback images if API fails
    return getFallbackImages(query);
  }
};

// Fallback images using verified Pixabay URLs
const getFallbackImages = (query: string): PixabayImage[] => {
  const fallbackImages: Record<string, PixabayImage[]> = {
    'monstera deliciosa': [{
      id: 1,
      webformatURL: 'https://cdn.pixabay.com/photo/2021/01/22/06/04/monstera-deliciosa-5939187_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2021/01/22/06/04/monstera-deliciosa-5939187_1280.jpg',
      tags: 'monstera, plant, houseplant',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'snake plant sansevieria': [{
      id: 2,
      webformatURL: 'https://cdn.pixabay.com/photo/2018/07/11/21/51/snake-plant-3530187_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2018/07/11/21/51/snake-plant-3530187_1280.jpg',
      tags: 'snake plant, sansevieria, houseplant',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'fiddle leaf fig ficus': [{
      id: 3,
      webformatURL: 'https://cdn.pixabay.com/photo/2020/08/05/13/12/eco-5465432_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2020/08/05/13/12/eco-5465432_1280.jpg',
      tags: 'fiddle leaf fig, plant, houseplant',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'pothos golden': [{
      id: 4,
      webformatURL: 'https://cdn.pixabay.com/photo/2020/04/28/16/18/pothos-5103055_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2020/04/28/16/18/pothos-5103055_1280.jpg',
      tags: 'pothos, plant, houseplant',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'rubber tree ficus': [{
      id: 5,
      webformatURL: 'https://cdn.pixabay.com/photo/2019/06/02/00/46/rubber-plant-4245208_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2019/06/02/00/46/rubber-plant-4245208_1280.jpg',
      tags: 'rubber plant, ficus, houseplant',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'peace lily spathiphyllum': [{
      id: 6,
      webformatURL: 'https://cdn.pixabay.com/photo/2020/05/24/10/55/peace-lily-5213029_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2020/05/24/10/55/peace-lily-5213029_1280.jpg',
      tags: 'peace lily, plant, flower',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'ceramic planters pots': [{
      id: 8,
      webformatURL: 'https://cdn.pixabay.com/photo/2020/04/08/08/08/plant-5016735_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2020/04/08/08/08/plant-5016735_1280.jpg',
      tags: 'pots, ceramic, planters',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'potting soil gardening': [{
      id: 9,
      webformatURL: 'https://cdn.pixabay.com/photo/2020/04/27/08/37/soil-5094062_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2020/04/27/08/37/soil-5094062_1280.jpg',
      tags: 'soil, potting, gardening',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }],
    'gardening tools equipment': [{
      id: 10,
      webformatURL: 'https://cdn.pixabay.com/photo/2020/04/06/13/37/gardening-5009508_640.jpg',
      largeImageURL: 'https://cdn.pixabay.com/photo/2020/04/06/13/37/gardening-5009508_1280.jpg',
      tags: 'tools, gardening, equipment',
      user: 'pixabay',
      views: 1000,
      downloads: 500,
      likes: 100
    }]
  };

  // Return the specific query or default to monstera
  return fallbackImages[query] || fallbackImages['monstera deliciosa'];
};

// Get specific plant images
export const getPlantImage = async (plantName: string): Promise<string> => {
  const images = await searchPixabayImages(plantName, 3, 'nature');
  return images[0]?.webformatURL || '';
};

// Get hero background image
export const getHeroImage = async (): Promise<string> => {
  const images = await searchPixabayImages('plant nursery greenhouse', 3, 'nature');
  return images[0]?.largeImageURL || 'https://cdn.pixabay.com/photo/2021/01/22/06/04/monstera-deliciosa-5939187_1280.jpg';
};

// Get supply images
export const getSupplyImage = async (supplyName: string): Promise<string> => {
  const images = await searchPixabayImages(supplyName, 3);
  return images[0]?.webformatURL || '';
};

// Get service images
export const getServiceImage = async (serviceName: string): Promise<string> => {
  const images = await searchPixabayImages(`${serviceName} plants`, 3, 'nature');
  return images[0]?.webformatURL || '';
};
