import React from 'react';
import type { InputProps } from '../../types';

const Input = React.forwardRef<HTMLInputElement, InputProps>(({
  label,
  error,
  icon,
  className = '',
  ...rest // Capture all other standard input props
}, ref) => {
  const inputId = `input-${label.toLowerCase().replace(/\s+/g, '-')}`;
  const hasError = !!error;

  return (
    <div className={`form-group ${className}`}>
      <label htmlFor={inputId} className="form-label">
        {label}
        {rest.required && <span className="text-red-500 ml-1" aria-label="required">*</span>}
      </label>
      
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
            {icon}
          </div>
        )}
        
        <input
          id={inputId}
          ref={ref} // Pass the ref to the native input element
          className={`
            form-input
            ${icon ? 'pl-10' : ''}
            ${hasError ? 'form-input-error' : ''}
            ${rest.disabled ? 'opacity-50 cursor-not-allowed' : ''}
          `.trim()}
          aria-invalid={hasError}
          aria-describedby={hasError ? `${inputId}-error` : undefined}
          {...rest} // Spread the rest of the props (type, placeholder, value, onChange, etc.)
        />
      </div>
      
      {hasError && (
        <div id={`${inputId}-error`} className="form-error" role="alert">
          {error}
        </div>
      )}
    </div>
  );
});

Input.displayName = 'Input'; // Add display name for React DevTools

export default Input;
