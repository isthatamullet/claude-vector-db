import React from 'react';
import type { CardProps } from '../../types';

const Card: React.FC<CardProps> = ({
  variant = 'default',
  children,
  className = '',
  onClick,
}) => {
  const baseClasses = 'card';
  const variantClasses = {
    default: '',
    featured: 'card-featured',
    compact: 'card-compact',
  };

  const classes = [
    baseClasses,
    variantClasses[variant],
    onClick && 'cursor-pointer',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const Component = onClick ? 'button' : 'div';

  return (
    <Component
      className={classes}
      onClick={onClick}
      {...(onClick && {
        type: 'button',
        'aria-label': 'Card button',
      })}
    >
      {children}
    </Component>
  );
};

export default Card;
