// Product Types
export interface Plant {
  id: string;
  name: string;
  scientificname: string;
  price: number;
  originalprice?: number;
  image: string;
  images: string[];
  description: string;
  careinstructions: {
    light: string;
    water: string;
    humidity: string;
    temperature: string;
    soil: string;
  };
  category: PlantCategory;
  size: PlantSize;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  instock: boolean;
  stockquantity: number;
  rating: number;
  reviewcount: number;
  features: string[];
  tags: string[];
}

export interface Supply {
  id: string;
  name: string;
  price: number;
  originalprice?: number;
  image: string;
  images: string[];
  description: string;
  category: SupplyCategory;
  brand: string;
  instock: boolean;
  stockquantity: number;
  rating: number;
  reviewcount: number;
  specifications: Record<string, string>;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string;
  image: string;
  features: string[];
  availability: 'Available' | 'Limited' | 'Unavailable';
  category: 'Repotting' | 'Plant Party' | 'Consultation' | 'Maintenance';
}

// Category Types
export type PlantCategory = 
  | 'Houseplants'
  | 'Succulents'
  | 'Tropical'
  | 'Air Plants'
  | 'Flowering'
  | 'Foliage'
  | 'Rare & Exotic';

export type SupplyCategory =
  | 'Pots & Planters'
  | 'Soil & Fertilizer'
  | 'Tools'
  | 'Watering'
  | 'Lighting'
  | 'Care Products';

export type PlantSize = 'Small' | 'Medium' | 'Large' | 'Extra Large';

// Cart Types
export interface CartItem {
  id: string;
  type: 'plant' | 'supply' | 'service';
  product: Plant | Supply | Service;
  quantity: number;
  selectedOptions?: Record<string, string>;
}

export interface Cart {
  items: CartItem[];
  total: number;
  subtotal: number;
  tax: number;
  shipping: number;
  discount?: {
    code: string;
    amount: number;
    type: 'percentage' | 'fixed';
  };
}

// User Types
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  addresses: Address[];
  preferences: UserPreferences;
  orderHistory: Order[];
}

export interface Address {
  id: string;
  type: 'shipping' | 'billing';
  firstName: string;
  lastName: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  isDefault: boolean;
}

export interface UserPreferences {
  newsletter: boolean;
  smsUpdates: boolean;
  careReminders: boolean;
  theme: 'light' | 'dark' | 'auto';
  language: string;
}

// Order Types
export interface Order {
  id: string;
  orderNumber: string;
  status: OrderStatus;
  items: CartItem[];
  total: number;
  subtotal: number;
  tax: number;
  shipping: number;
  discount?: {
    code: string;
    amount: number;
    type: 'percentage' | 'fixed';
  };
  shippingAddress: Address;
  billingAddress: Address;
  paymentMethod: PaymentMethod;
  createdAt: string;
  updatedAt: string;
  estimatedDelivery?: string;
  trackingNumber?: string;
}

export type OrderStatus = 
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'refunded';

export interface PaymentMethod {
  id: string;
  type: 'credit_card' | 'paypal' | 'apple_pay' | 'google_pay';
  last4?: string;
  brand?: string;
  expiryMonth?: number;
  expiryYear?: number;
}

// Review Types
export interface Review {
  id: string;
  productid: string;
  producttype: 'plant' | 'supply' | 'service';
  userid: string;
  username: string;
  rating: number;
  title: string;
  comment: string;
  images?: string[];
  verified: boolean;
  helpful: number;
  createdat: string;
  updatedat: string;
}

// Filter Types
export interface ProductFilters {
  category?: string[];
  priceRange?: {
    min: number;
    max: number;
  };
  size?: PlantSize[];
  difficulty?: string[];
  inStock?: boolean;
  rating?: number;
  features?: string[];
  sortBy?: 'name' | 'price' | 'rating' | 'newest' | 'popular';
  sortOrder?: 'asc' | 'desc';
}

// Search Types
export interface SearchResult {
  plants: Plant[];
  supplies: Supply[];
  services: Service[];
  total: number;
  query: string;
  suggestions?: string[];
}

// API Types
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
  errors?: string[];
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

// Form Types
export interface ContactForm {
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
}

export interface NewsletterForm {
  email: string;
  preferences?: {
    careGuides: boolean;
    newProducts: boolean;
    sales: boolean;
  };
}

export interface CheckoutForm {
  email: string;
  shippingAddress: Omit<Address, 'id' | 'type' | 'isDefault'>;
  billingAddress: Omit<Address, 'id' | 'type' | 'isDefault'>;
  sameAsShipping: boolean;
  paymentMethod: {
    type: 'credit_card' | 'paypal';
    cardNumber?: string;
    expiryMonth?: string;
    expiryYear?: string;
    cvv?: string;
    nameOnCard?: string;
  };
  specialInstructions?: string;
  newsletter: boolean;
}

// Component Props Types
export interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  disabled?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;
  children: React.ReactNode;
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  type?: 'button' | 'submit' | 'reset';
  className?: string;
}

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  icon?: React.ReactNode;
  className?: string;
}

export interface CardProps {
  variant?: 'default' | 'featured' | 'compact';
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

// Navigation Types
export interface NavigationItem {
  label: string;
  href: string;
  icon?: React.ReactNode;
  submenu?: NavigationItem[];
  external?: boolean;
}

// Pixabay API Types
export interface PixabayImage {
  id: number;
  webformatURL: string;
  largeImageURL: string;
  tags: string;
  user: string;
  views: number;
  downloads: number;
  likes: number;
}

export interface PixabayResponse {
  total: number;
  totalHits: number;
  hits: PixabayImage[];
}

// Store Types (Zustand)
export interface CartStore {
  cart: Cart;
  addItem: (item: Omit<CartItem, 'id'>) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  applyDiscount: (code: string) => Promise<boolean>;
  removeDiscount: () => void;
}

// Wishlist Types
export interface WishlistItem {
  id: string; // Unique ID for the wishlist item (e.g., product.id)
  type: 'plant' | 'supply' | 'service';
  product: Plant | Supply | Service;
  addedAt: string; // ISO date string
}

export interface WishlistStore {
  items: WishlistItem[];
  addItem: (item: Omit<WishlistItem, 'id' | 'addedAt'>) => void;
  removeItem: (itemId: string) => void;
  isItemInWishlist: (itemId: string) => boolean;
}

export interface UserStore {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>; // Changed to Promise<void> for consistency with async actions
  register: (userData: Partial<User>) => Promise<void>;
  updateProfile: (userData: Partial<User>) => Promise<void>;
}

export interface ProductStore {
  plants: Plant[];
  supplies: Supply[];
  services: Service[];
  loading: boolean;
  error: string | null;
  filters: ProductFilters;
  searchQuery: string;
  fetchPlants: () => Promise<void>;
  fetchSupplies: () => Promise<void>;
  fetchServices: () => Promise<void>;
  setFilters: (filters: Partial<ProductFilters>) => void;
  setSearchQuery: (query: string) => void;
  searchProducts: (query: string) => Promise<SearchResult>;
}

// Utility Types
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;
