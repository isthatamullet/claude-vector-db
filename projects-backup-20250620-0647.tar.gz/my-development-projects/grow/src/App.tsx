import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import Plants from './pages/Plants';
import Supplies from './pages/Supplies';
import Services from './pages/Services';
import OrderNow from './pages/OrderNow';
import ProductDetail from './pages/ProductDetail';
import SearchResults from './pages/SearchResults';
import SignIn from './pages/SignIn'; // Import SignIn
import SignUp from './pages/SignUp'; // Import SignUp

function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-white">
        <a href="#main-content" className="skip-link">
          Skip to main content
        </a>
        
        <Header />
        
        <main id="main-content" className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/plants" element={<Plants />} />
            <Route path="/plants/:id" element={<ProductDetail />} />
            <Route path="/supplies" element={<Supplies />} />
            <Route path="/supplies/:id" element={<ProductDetail />} />
            <Route path="/services" element={<Services />} />
            <Route path="/services/:id" element={<ProductDetail />} />
            <Route path="/order-now" element={<OrderNow />} />
            <Route path="/search" element={<SearchResults />} />
            <Route path="/signin" element={<SignIn />} /> {/* Route for sign in */}
            <Route path="/signup" element={<SignUp />} /> {/* Route for sign up */}
          </Routes>
        </main>
        
        <Footer />
      </div>
    </Router>
  );
}

export default App;
