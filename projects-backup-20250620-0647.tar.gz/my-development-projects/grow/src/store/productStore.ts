import { create } from 'zustand';
import type { ProductStore, Plant, Supply, Service, ProductFilters, SearchResult } from '../types';
import { supabase } from '../utils/supabaseClient';

const initialFilters: ProductFilters = {
  sortBy: 'name',
  sortOrder: 'asc',
};

export const useProductStore = create<ProductStore>((set, get) => ({
  plants: [],
  supplies: [],
  services: [],
  loading: false,
  error: null,
  filters: initialFilters,
  searchQuery: '',

  fetchPlants: async () => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase.from('plants').select('*');
      if (error) throw error;
      set({ plants: data as Plant[], loading: false });
    } catch (error: any) {
      set({ error: `Failed to fetch plants: ${error.message}`, loading: false });
    }
  },

  fetchSupplies: async () => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase.from('supplies').select('*');
      if (error) throw error;
      set({ supplies: data as Supply[], loading: false });
    } catch (error: any) {
      set({ error: `Failed to fetch supplies: ${error.message}`, loading: false });
    }
  },

  fetchServices: async () => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase.from('services').select('*');
      if (error) throw error;
      set({ services: data as Service[], loading: false });
    } catch (error: any) {
      set({ error: `Failed to fetch services: ${error.message}`, loading: false });
    }
  },

  setFilters: (newFilters) => {
    set({ filters: { ...get().filters, ...newFilters } });
  },

  setSearchQuery: (query) => {
    set({ searchQuery: query });
  },

  searchProducts: async (query) => {
    const { plants, supplies, services } = get();
    const lowercaseQuery = query.toLowerCase();

    const filteredPlants = plants.filter(plant =>
      plant.name.toLowerCase().includes(lowercaseQuery) ||
      plant.scientificname.toLowerCase().includes(lowercaseQuery) ||
      plant.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery)) ||
      plant.category.toLowerCase().includes(lowercaseQuery)
    );

    const filteredSupplies = supplies.filter(supply =>
      supply.name.toLowerCase().includes(lowercaseQuery) ||
      supply.description.toLowerCase().includes(lowercaseQuery) ||
      supply.category.toLowerCase().includes(lowercaseQuery) ||
      supply.brand.toLowerCase().includes(lowercaseQuery)
    );

    const filteredServices = services.filter(service =>
      service.name.toLowerCase().includes(lowercaseQuery) ||
      service.description.toLowerCase().includes(lowercaseQuery) ||
      service.category.toLowerCase().includes(lowercaseQuery)
    );

    const result: SearchResult = {
      plants: filteredPlants,
      supplies: filteredSupplies,
      services: filteredServices,
      total: filteredPlants.length + filteredSupplies.length + filteredServices.length,
      query,
      suggestions: query.length > 2 ? [
        'monstera',
        'snake plant',
        'pothos',
        'ceramic pots',
        'potting soil',
        'plant tools',
        'repotting service'
      ].filter(suggestion => 
        suggestion.includes(lowercaseQuery) && suggestion !== lowercaseQuery
      ) : []
    };

    return result;
  },
}));
