import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { WishlistStore, WishlistItem, Plant, Supply, Service } from '../types';

export const useWishlistStore = create<WishlistStore>()(
  persist(
    (set, get) => ({
      items: [],

      addItem: (itemToAdd: Omit<WishlistItem, 'id' | 'addedAt'>) => {
        const { items } = get();
        const existingItem = items.find(
          (item) => item.product.id === itemToAdd.product.id && item.type === itemToAdd.type
        );

        if (!existingItem) {
          const newItem: WishlistItem = {
            id: itemToAdd.product.id, // Use product id as wishlist item id
            type: itemToAdd.type,
            product: itemToAdd.product,
            addedAt: new Date().toISOString(),
          };
          set({ items: [...items, newItem] });
        }
      },

      removeItem: (itemId: string) => {
        set((state) => ({
          items: state.items.filter((item) => item.id !== itemId),
        }));
      },

      isItemInWishlist: (itemId: string) => {
        const { items } = get();
        return items.some((item) => item.id === itemId);
      },
    }),
    {
      name: 'grow-wishlist-storage',
      partialize: (state) => ({ items: state.items }),
    }
  )
);
