import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { UserStore, User } from '../types';

const initialUser: User | null = null;

export const useUserStore = create<UserStore>()(
  persist(
    (set) => ({
      user: initialUser,
      isAuthenticated: false,

      login: async (email, password) => {
        return new Promise((resolve) => {
          setTimeout(() => {
            if (email === 'test@example.com' && password === 'password123') {
              const mockUser: User = {
                id: 'user-1',
                email: 'test@example.com',
                firstName: 'Test',
                lastName: 'User',
                addresses: [],
                preferences: {
                  newsletter: true,
                  smsUpdates: false,
                  careReminders: true,
                  theme: 'light',
                  language: 'en',
                },
                orderHistory: [],
              };
              set({ user: mockUser, isAuthenticated: true });
              resolve(); // No boolean argument
            } else {
              alert('Invalid email or password.');
              resolve(); // No boolean argument
            }
          }, 500);
        });
      },

      logout: async () => {
        return new Promise((resolve) => {
          setTimeout(() => {
            set({ user: initialUser, isAuthenticated: false });
            resolve(); // No boolean argument
          }, 300);
        });
      },

      register: async (userData) => {
        return new Promise((resolve) => {
          setTimeout(() => {
            if (userData.email && userData.firstName && userData.lastName) {
              const newUser: User = {
                id: `user-${Date.now()}`,
                email: userData.email,
                firstName: userData.firstName,
                lastName: userData.lastName,
                addresses: [],
                preferences: {
                  newsletter: true,
                  smsUpdates: false,
                  careReminders: true,
                  theme: 'light',
                  language: 'en',
                },
                orderHistory: [],
                ...userData,
              };
              set({ user: newUser, isAuthenticated: true });
              resolve(); // No boolean argument
            } else {
              alert('Registration failed: Missing required data.');
              resolve(); // No boolean argument
            }
          }, 700);
        });
      },

      updateProfile: async (userData) => {
        return new Promise((resolve) => {
          setTimeout(() => {
            set((state) => ({
              user: state.user ? { ...state.user, ...userData } : state.user,
            }));
            resolve(); // No boolean argument
          }, 500);
        });
      },
    }),
    {
      name: 'grow-user-storage',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);
