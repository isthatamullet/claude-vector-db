import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { CartStore, Cart, CartItem } from '../types';

const initialCart: Cart = {
  items: [],
  total: 0,
  subtotal: 0,
  tax: 0,
  shipping: 0,
};

const TAX_RATE = 0.08; // 8% tax rate
const FREE_SHIPPING_THRESHOLD = 75;
const SHIPPING_COST = 9.99;

const calculateCartTotals = (items: CartItem[]): Omit<Cart, 'items' | 'discount'> => {
  const subtotal = items.reduce((sum, item) => {
    return sum + (item.product.price * item.quantity);
  }, 0);

  const tax = subtotal * TAX_RATE;
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
  const total = subtotal + tax + shipping;

  return {
    subtotal: Math.round(subtotal * 100) / 100,
    tax: Math.round(tax * 100) / 100,
    shipping: Math.round(shipping * 100) / 100,
    total: Math.round(total * 100) / 100,
  };
};

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      cart: initialCart,

      addItem: (newItem) => {
        const { cart } = get();
        const existingItemIndex = cart.items.findIndex(
          (item) => 
            item.product.id === newItem.product.id && 
            item.type === newItem.type &&
            JSON.stringify(item.selectedOptions) === JSON.stringify(newItem.selectedOptions)
        );

        let updatedItems: CartItem[];

        if (existingItemIndex >= 0) {
          // Update quantity of existing item
          updatedItems = cart.items.map((item, index) =>
            index === existingItemIndex
              ? { ...item, quantity: item.quantity + newItem.quantity }
              : item
          );
        } else {
          // Add new item
          const cartItem: CartItem = {
            id: `${newItem.type}-${newItem.product.id}-${Date.now()}`,
            ...newItem,
          };
          updatedItems = [...cart.items, cartItem];
        }

        const totals = calculateCartTotals(updatedItems);
        
        set({
          cart: {
            ...cart,
            items: updatedItems,
            ...totals,
          },
        });
      },

      removeItem: (itemId) => {
        const { cart } = get();
        const updatedItems = cart.items.filter((item) => item.id !== itemId);
        const totals = calculateCartTotals(updatedItems);

        set({
          cart: {
            ...cart,
            items: updatedItems,
            ...totals,
          },
        });
      },

      updateQuantity: (itemId, quantity) => {
        const { cart } = get();
        
        if (quantity <= 0) {
          get().removeItem(itemId);
          return;
        }

        const updatedItems = cart.items.map((item) =>
          item.id === itemId ? { ...item, quantity } : item
        );

        const totals = calculateCartTotals(updatedItems);

        set({
          cart: {
            ...cart,
            items: updatedItems,
            ...totals,
          },
        });
      },

      clearCart: () => {
        set({ cart: initialCart });
      },

      applyDiscount: async (code) => {
        // Mock discount validation
        const validCodes = {
          'WELCOME10': { amount: 10, type: 'percentage' as const },
          'SAVE5': { amount: 5, type: 'fixed' as const },
          'FREESHIP': { amount: 0, type: 'fixed' as const }, // Special case for free shipping
        };

        const discount = validCodes[code as keyof typeof validCodes];
        
        if (!discount) {
          return false;
        }

        const { cart } = get();
        let discountAmount = 0;

        if (code === 'FREESHIP') {
          // Free shipping discount
          const totals = calculateCartTotals(cart.items);
          const total = totals.subtotal + totals.tax; // No shipping
          
          set({
            cart: {
              ...cart,
              discount: { code, amount: totals.shipping, type: 'fixed' },
              shipping: 0,
              total: Math.round(total * 100) / 100,
            },
          });
        } else {
          // Regular discount
          if (discount.type === 'percentage') {
            discountAmount = (cart.subtotal * discount.amount) / 100;
          } else {
            discountAmount = discount.amount;
          }

          const newTotal = Math.max(0, cart.total - discountAmount);

          set({
            cart: {
              ...cart,
              discount: { code, amount: discountAmount, type: discount.type },
              total: Math.round(newTotal * 100) / 100,
            },
          });
        }

        return true;
      },

      removeDiscount: () => {
        const { cart } = get();
        const totals = calculateCartTotals(cart.items);

        set({
          cart: {
            ...cart,
            discount: undefined,
            ...totals,
          },
        });
      },
    }),
    {
      name: 'grow-cart-storage',
      partialize: (state) => ({ cart: state.cart }),
    }
  )
);
