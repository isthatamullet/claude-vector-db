import React, { useEffect, useState } from 'react';
import { useCartStore } from '../store/cartStore';
import { Button, Card, Input } from '../components/ui';
import { getPlantImage, getSupplyImage } from '../utils/pixabayApi';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Elements, useStripe, useElements, CardElement } from '@stripe/react-stripe-js'; // Import Stripe Elements
import { loadStripe } from '@stripe/stripe-js'; // Import loadStripe

// Define a new Zod schema for the quick order form fields
const quickOrderSchema = z.object({
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone number is required').max(15, 'Phone number is too long'),
  address: z.string().min(10, 'Delivery address is required'),
  specialInstructions: z.string().optional(),
});

// Infer the TypeScript type from the schema
type QuickOrderFormData = z.infer<typeof quickOrderSchema>;

// Load Stripe outside of component render to avoid recreating Stripe object on every render
const stripePromise = loadStripe('pk_test_TYooMQauvdEDq54NiTphSbIE'); // Replace with your actual Stripe publishable key

const CheckoutFormContent: React.FC<{ onSubmit: (data: QuickOrderFormData) => void; cartItemsCount: number }> = ({ onSubmit, cartItemsCount }) => {
  const { register, handleSubmit, formState: { errors } } = useForm<QuickOrderFormData>({
    resolver: zodResolver(quickOrderSchema),
    defaultValues: {
      email: '',
      phone: '',
      address: '',
      specialInstructions: '',
    },
  });

  const stripe = useStripe();
  const elements = useElements();

  const handlePaymentSubmit = async (data: QuickOrderFormData) => {
    if (!stripe || !elements) {
      // Stripe.js has not yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    }

    // Create payment method
    const { error, paymentMethod } = await stripe.createPaymentMethod({
      type: 'card',
      card: elements.getElement(CardElement)!,
    });

    if (error) {
      console.error('[Stripe error]', error);
      alert(error.message);
    } else {
      console.log('[PaymentMethod]', paymentMethod);
      // In a real application, you would send paymentMethod.id to your backend
      // to complete the payment. For this mock, we just proceed.
      onSubmit(data);
    }
  };

  return (
    <form onSubmit={handleSubmit(handlePaymentSubmit)} className="space-y-6">
      <Input
        label="Email Address"
        type="email"
        placeholder="your@email.com"
        {...register('email')}
        error={errors.email?.message}
        required
      />

      <Input
        label="Phone Number"
        type="tel"
        placeholder="(555) 123-4567"
        {...register('phone')}
        error={errors.phone?.message}
        required
      />

      <div className="form-group">
        <label htmlFor="address" className="form-label">
          Delivery Address *
        </label>
        <textarea
          id="address"
          className={`form-input min-h-[100px] resize-none ${errors.address ? 'form-input-error' : ''}`}
          placeholder="Enter your full delivery address..."
          {...register('address')}
          required
        />
        {errors.address && (
          <div className="form-error" role="alert">
            {errors.address.message}
          </div>
        )}
      </div>

      <div className="form-group">
        <label htmlFor="specialInstructions" className="form-label">
          Special Instructions
        </label>
        <textarea
          id="specialInstructions"
          className="form-input min-h-[80px] resize-none"
          placeholder="Any special delivery instructions or plant preferences..."
          {...register('specialInstructions')}
        />
      </div>

      {/* Stripe Card Element */}
      <div className="bg-neutral-50 p-4 rounded-lg">
        <h3 className="text-h6 font-semibold text-neutral-900 mb-2">
          Payment Information
        </h3>
        <div className="border border-neutral-300 p-4 rounded-lg">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                  '::placeholder': {
                    color: '#aab7c4',
                  },
                },
                invalid: {
                  color: '#9e2146',
                },
              },
            }}
          />
        </div>
        <p className="text-body-sm text-neutral-600 mt-2">
          Your payment will be securely processed by Stripe.
        </p>
      </div>

      <Button
        type="submit"
        variant="primary"
        size="lg"
        className="w-full"
        disabled={!stripe || !elements || cartItemsCount === 0}
      >
        Submit Quick Order
      </Button>

      <p className="text-body-sm text-neutral-600 text-center">
        We'll contact you shortly to confirm your order and arrange payment.
      </p>
    </form>
  );
};

const OrderNow: React.FC = () => {
  const { cart } = useCartStore();
  
  // State for popular item images
  const [popularItemImages, setPopularItemImages] = useState({
    monstera: '',
    snake: '',
    pothos: '',
    starterKit: ''
  });

  // Load images on component mount
  useEffect(() => {
    const loadImages = async () => {
      try {
        const [monsteraImg, snakeImg, pothosImg, starterKitImg] = await Promise.all([
          getPlantImage('monstera deliciosa'),
          getPlantImage('snake plant sansevieria'),
          getPlantImage('pothos golden'),
          getSupplyImage('plant starter kit')
        ]);

        setPopularItemImages({
          monstera: monsteraImg,
          snake: snakeImg,
          pothos: pothosImg,
          starterKit: starterKitImg
        });
      } catch (error) {
        console.error('Error loading popular item images:', error);
      }
    };

    loadImages();
  }, []);

  const onSubmit = (data: QuickOrderFormData) => { // Use QuickOrderFormData here
    // Handle quick order submission with validated data
    console.log('Quick order submitted:', {
      ...data,
      cart
    });
    alert('Order submitted! We\'ll contact you shortly to confirm your order and arrange payment.');
    // In a real app, you would send this data to your backend
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Page Header */}
      <section className="bg-primary-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-h1 font-bold text-neutral-900 mb-4">
              Quick Order
            </h1>
            <p className="text-body-lg text-neutral-600 max-w-2xl mx-auto">
              Need plants fast? Use our express ordering system for quick delivery of our most popular items.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Quick Order Form */}
          <div>
            <Card className="p-8">
              <h2 className="text-h3 font-bold text-neutral-900 mb-6">
                Express Checkout
              </h2>
              
              {/* Wrap CheckoutFormContent with Elements provider */}
              {stripePromise && (
                <Elements stripe={stripePromise}>
                  <CheckoutFormContent onSubmit={onSubmit} cartItemsCount={cart.items.length} />
                </Elements>
              )}
            </Card>
          </div>

          {/* Popular Items */}
          <div>
            <h2 className="text-h3 font-bold text-neutral-900 mb-6">
              Popular Quick Order Items
            </h2>
            
            <div className="space-y-4">
              <Card className="p-6">
                <div className="flex items-center space-x-4">
                  {popularItemImages.monstera ? (
                    <img
                      src={popularItemImages.monstera}
                      alt="Monstera Deliciosa"
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-neutral-200 rounded-lg animate-pulse"></div>
                  )}
                  <div className="flex-1">
                    <h3 className="text-h6 font-semibold text-neutral-900">
                      Monstera Deliciosa
                    </h3>
                    <p className="text-body-sm text-neutral-600">
                      Perfect beginner plant
                    </p>
                    <p className="text-h6 font-bold text-primary-600">$45.99</p>
                  </div>
                  <Button variant="outline" size="sm">
                    Add
                  </Button>
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center space-x-4">
                  {popularItemImages.snake ? (
                    <img
                      src={popularItemImages.snake}
                      alt="Snake Plant"
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-neutral-200 rounded-lg animate-pulse"></div>
                  )}
                  <div className="flex-1">
                    <h3 className="text-h6 font-semibold text-neutral-900">
                      Snake Plant
                    </h3>
                    <p className="text-body-sm text-neutral-600">
                      Low maintenance favorite
                    </p>
                    <p className="text-h6 font-bold text-primary-600">$29.99</p>
                  </div>
                  <Button variant="outline" size="sm">
                    Add
                  </Button>
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center space-x-4">
                  {popularItemImages.pothos ? (
                    <img
                      src={popularItemImages.pothos}
                      alt="Golden Pothos"
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-neutral-200 rounded-lg animate-pulse"></div>
                  )}
                  <div className="flex-1">
                    <h3 className="text-h6 font-semibold text-neutral-900">
                      Golden Pothos
                    </h3>
                    <p className="text-body-sm text-neutral-600">
                      Fast-growing trailing vine
                    </p>
                    <p className="text-h6 font-bold text-primary-600">$19.99</p>
                  </div>
                  <Button variant="outline" size="sm">
                    Add
                  </Button>
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center space-x-4">
                  {popularItemImages.starterKit ? (
                    <img
                      src={popularItemImages.starterKit}
                      alt="Starter Kit"
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-neutral-200 rounded-lg animate-pulse"></div>
                  )}
                  <div className="flex-1">
                    <h3 className="text-h6 font-semibold text-neutral-900">
                      Plant Starter Kit
                    </h3>
                    <p className="text-body-sm text-neutral-600">
                      Everything you need to start
                    </p>
                    <p className="text-h6 font-bold text-primary-600">$89.99</p>
                  </div>
                  <Button variant="outline" size="sm">
                    Add
                  </Button>
                </div>
              </Card>
            </div>

            {/* Quick Order Benefits */}
            <Card className="p-6 mt-8 bg-primary-50">
              <h3 className="text-h6 font-semibold text-neutral-900 mb-4">
                Why Choose Quick Order?
              </h3>
              <ul className="space-y-2">
                <li className="flex items-start space-x-2 text-body-sm">
                  <svg className="w-4 h-4 text-primary-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Same-day delivery available</span>
                </li>
                <li className="flex items-start space-x-2 text-body-sm">
                  <svg className="w-4 h-4 text-primary-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Personal consultation included</span>
                </li>
                <li className="flex items-start space-x-2 text-body-sm">
                  <svg className="w-4 h-4 text-primary-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Flexible payment options</span>
                </li>
                <li className="flex items-start space-x-2 text-body-sm">
                  <svg className="w-4 h-4 text-primary-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>30-day plant guarantee</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderNow;
