import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button, Input, Card } from '../components/ui';
import { useUserStore } from '../store/userStore';

const signUpSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type SignUpFormData = z.infer<typeof signUpSchema>;

const SignUp: React.FC = () => {
  const navigate = useNavigate();
  const { register: registerUser, isAuthenticated } = useUserStore();

  const { register, handleSubmit, formState: { errors } } = useForm<SignUpFormData>({
    resolver: zodResolver(signUpSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      password: '',
    },
  });

  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/'); // Redirect to home if already authenticated
    }
  }, [isAuthenticated, navigate]);

  const onSubmit = async (data: SignUpFormData) => {
    await registerUser({
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      // Password would be handled by a backend in a real app
    });
    // The register action handles alerts internally for mock success/failure
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <Card className="max-w-md w-full space-y-8 p-8">
        <div>
          <h2 className="mt-6 text-center text-h2 font-bold text-neutral-900">
            Create your account
          </h2>
          <p className="mt-2 text-center text-body text-neutral-600">
            Or{' '}
            <Link to="/signin" className="font-medium text-primary-600 hover:text-primary-500">
              sign in to your existing account
            </Link>
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit(onSubmit)}>
          <Input
            label="First Name"
            type="text"
            placeholder="Your first name"
            {...register('firstName')}
            error={errors.firstName?.message}
            required
          />
          <Input
            label="Last Name"
            type="text"
            placeholder="Your last name"
            {...register('lastName')}
            error={errors.lastName?.message}
            required
          />
          <Input
            label="Email address"
            type="email"
            placeholder="you@example.com"
            {...register('email')}
            error={errors.email?.message}
            required
          />
          <Input
            label="Password"
            type="password"
            placeholder="Create a password"
            {...register('password')}
            error={errors.password?.message}
            required
          />
          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full"
          >
            Create Account
          </Button>
        </form>
      </Card>
    </div>
  );
};

export default SignUp;
