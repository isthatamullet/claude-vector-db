import React, { useEffect, useState, useCallback } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useCartStore } from '../store/cartStore';
import { useWishlistStore } from '../store/wishlistStore';
import { Button, Input, Card } from '../components/ui';
import type { Plant, Supply, Service, Review } from '../types';
import { supabase } from '../utils/supabaseClient';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addItem } = useCartStore();
  const { addItem: addToWishlist, removeItem: removeFromWishlist, isItemInWishlist } = useWishlistStore();
  const [product, setProduct] = useState<Plant | Supply | Service | null>(null);
  const [currentImage, setCurrentImage] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newReviewText, setNewReviewText] = useState<string>('');
  const [newReviewRating, setNewReviewRating] = useState<number>(0);
  const [relatedProducts, setRelatedProducts] = useState<(Plant | Supply | Service)[]>([]);
  const [loadingProduct, setLoadingProduct] = useState(true);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [productError, setProductError] = useState<string | null>(null);
  const [reviewError, setReviewError] = useState<string | null>(null);

  // Determine if it's a plant, supply, or service for specific details
  const isPlant = (p: Plant | Supply | Service): p is Plant => (p as Plant).scientificname !== undefined;
  const isSupply = (p: Plant | Supply | Service): p is Supply => (p as Supply).brand !== undefined;
  const isService = (p: Plant | Supply | Service): p is Service => (p as Service).duration !== undefined;

  const fetchProduct = useCallback(async () => {
    setLoadingProduct(true);
    setProductError(null);
    let foundProduct: Plant | Supply | Service | null = null;

    console.log('Fetching product with ID:', id);

    try {
      // Try fetching from plants table
      const { data: plantData, error: plantError } = await supabase
        .from('plants')
        .select('*')
        .eq('id', id)
        .single();
      console.log('Plants table response:', JSON.stringify({ plantData, plantError }, null, 2));
      if (plantData) {
        foundProduct = plantData as Plant;
      } else if (plantError && plantError.code !== 'PGRST116') { // PGRST116 means no rows found
        throw plantError;
      }

      // If not found, try supplies table
      if (!foundProduct) {
        const { data: supplyData, error: supplyError } = await supabase
          .from('supplies')
          .select('*')
          .eq('id', id)
          .single();
        console.log('Supplies table response:', JSON.stringify({ supplyData, supplyError }, null, 2));
        if (supplyData) {
          foundProduct = supplyData as Supply;
        } else if (supplyError && supplyError.code !== 'PGRST116') {
          throw supplyError;
        }
      }

      // If not found, try services table
      if (!foundProduct) {
        const { data: serviceData, error: serviceError } = await supabase
          .from('services')
          .select('*')
          .eq('id', id)
          .single();
        console.log('Services table response:', JSON.stringify({ serviceData, serviceError }, null, 2));
        if (serviceData) {
          foundProduct = serviceData as Service;
        } else if (serviceError && serviceError.code !== 'PGRST116') {
          throw serviceError;
        }
      }

      console.log('Found product:', JSON.stringify(foundProduct, null, 2));
      setProduct(foundProduct);
      if (foundProduct) {
        setCurrentImage(foundProduct.image || (('images' in foundProduct && foundProduct.images[0]) || ''));
      } else {
        setCurrentImage('');
      }
    } catch (error: any) {
      setProductError(`Failed to load product: ${error.message}`);
      console.error('Error fetching product:', error);
    } finally {
      setLoadingProduct(false);
    }
  }, [id]);

  const fetchReviews = useCallback(async () => {
    setLoadingReviews(true);
    setReviewError(null);
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('productid', id)
        .order('createdat', { ascending: false });
      if (error) throw error;
      setReviews(data as Review[]);
    } catch (error: any) {
      setReviewError(`Failed to load reviews: ${error.message}`);
      console.error('Error fetching reviews:', error);
    } finally {
      setLoadingReviews(false);
    }
  }, [id]);

  useEffect(() => {
    if (id) {
      fetchProduct();
      fetchReviews();
    }
  }, [id, fetchProduct, fetchReviews]);

  // Mock related products for now, will be replaced by AI recommendations later
  useEffect(() => {
    if (product) {
      // This logic will need to be updated to fetch from Supabase once all products are in a single table or a more complex relationship is defined.
      // For now, it will remain client-side mock based on the product type.
      const mockRelated: (Plant | Supply | Service)[] = []; // Placeholder for actual related products
      setRelatedProducts(mockRelated);
    }
  }, [product]);


  if (loadingProduct) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <h1 className="text-h2 font-bold text-neutral-900 mb-4">Loading Product...</h1>
          <div className="loading-spinner w-12 h-12 mx-auto"></div>
        </div>
      </div>
    );
  }

  if (productError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <h1 className="text-h2 font-bold text-error-600 mb-4">Error</h1>
          <p className="text-body-lg text-neutral-600">
            {productError}
          </p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <h1 className="text-h2 font-bold text-neutral-900 mb-4">Product Not Found</h1>
          <p className="text-body-lg text-neutral-600">
            The product you are looking for does not exist.
          </p>
        </div>
      </div>
    );
  }

  const handleAddToCart = (item: Plant | Supply | Service) => {
    let type: 'plant' | 'supply' | 'service';
    if (isPlant(item)) type = 'plant';
    else if (isSupply(item)) type = 'supply';
    else if (isService(item)) type = 'service';
    else return; // Should not happen

    addItem({
      type,
      product: item,
      quantity: quantity,
    });
    alert(`${quantity} x ${item.name} added to cart!`);
  };

  const handleWishlistToggle = (item: Plant | Supply | Service) => {
    let type: 'plant' | 'supply' | 'service';
    if (isPlant(item)) type = 'plant';
    else if (isSupply(item)) type = 'supply';
    else if (isService(item)) type = 'service';
    else return; // Should not happen

    if (isItemInWishlist(item.id)) {
      removeFromWishlist(item.id);
      alert(`${item.name} removed from wishlist!`);
    } else {
      addToWishlist({
        type,
        product: item,
      });
      alert(`${item.name} added to wishlist!`);
    }
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity > 0 && (!('stockquantity' in product) || newQuantity <= product.stockquantity)) {
      setQuantity(newQuantity);
    } else if (newQuantity <= 0) {
      setQuantity(1); // Minimum quantity is 1
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newReviewText.trim() === '' || newReviewRating === 0) {
      alert('Please provide a rating and a comment for your review.');
      return;
    }

    if (!product) {
      alert('Cannot submit review: product not found.');
      return;
    }

    // Determine product type for the review
    let productType: 'plant' | 'supply' | 'service';
    if (isPlant(product)) productType = 'plant';
    else if (isSupply(product)) productType = 'supply';
    else if (isService(product)) productType = 'service';
    else {
      alert('Unknown product type for review submission.');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('reviews')
        .insert({
          id: `review-${Date.now()}`, // Generate a unique ID for the review
          productid: product.id,
          producttype: productType,
          userid: 'mock-user-id', // Placeholder: replace with actual user ID from auth
          username: 'Anonymous User', // Placeholder: replace with actual user name
          rating: newReviewRating,
          title: `Review for ${product.name}`, // Placeholder title
          comment: newReviewText,
          images: [], // No images for now
          verified: false, // Placeholder
          helpful: 0, // Initial helpful count
          createdat: new Date().toISOString(),
          updatedat: new Date().toISOString(),
        })
        .select(); // Select the inserted data to get the full Review object

      if (error) throw error;

      // Add the newly inserted review to the state
      setReviews((prevReviews) => [data[0] as Review, ...prevReviews]);
      setNewReviewText('');
      setNewReviewRating(0);
      alert('Your review has been submitted!');
    } catch (error: any) {
      alert(`Failed to submit review: ${error.message}`);
      console.error('Error submitting review:', error);
    }
  };

  const isInWishlist = isItemInWishlist(product.id);

  return (
    <div className="min-h-screen bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image Gallery */}
          <div>
            <div className="w-full h-96 bg-neutral-200 rounded-lg flex items-center justify-center text-neutral-500 text-lg overflow-hidden relative">
              {/* Main Image */}
              {currentImage ? (
                <img src={currentImage} alt={product.name} className="w-full h-full object-cover rounded-lg" />
              ) : (
                <span>Product Image Placeholder</span>
              )}
            </div>
            {/* Thumbnails */}
            {(isPlant(product) || isSupply(product)) && product.images && product.images.length > 0 && (
              <div className="flex space-x-2 mt-4 overflow-x-auto pb-2">
                {product.images.map((img: string, index: number) => (
                  <button
                    key={index}
                    className={`w-20 h-20 flex-shrink-0 rounded-md overflow-hidden border-2 ${
                      currentImage === img ? 'border-primary-500' : 'border-transparent'
                    } hover:border-primary-400 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2`}
                    onClick={() => setCurrentImage(img)}
                    aria-label={`View image ${index + 1}`}
                  >
                    <img src={img} alt={`${product.name} thumbnail ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details */}
          <div>
            <h1 className="text-h1 font-bold text-neutral-900 mb-2">
              {product.name}
            </h1>
            {isPlant(product) && (
              <p className="text-body-lg text-neutral-600 italic mb-4">
                {product.scientificname}
              </p>
            )}
            {isSupply(product) && (
              <p className="text-body-lg text-neutral-600 mb-4">
                Brand: {product.brand}
              </p>
            )}
            {isService(product) && (
              <p className="text-body-lg text-neutral-600 mb-4">
                Duration: {product.duration}
              </p>
            )}

            <div className="flex items-center space-x-4 mb-6">
              <span className="text-display-lg font-bold text-primary-600">
                ${product.price.toFixed(2)}
              </span>
              {(isPlant(product) || isSupply(product)) && product.originalprice && (
                <span className="text-body-lg text-neutral-400 line-through">
                  ${product.originalprice.toFixed(2)}
                </span>
              )}
              {'rating' in product && (
                <div className="flex items-center space-x-1">
                  <svg className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 20 20">
                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                  </svg>
                  <span className="text-body-lg text-neutral-600">
                    {product.rating} ({'reviewcount' in product ? product.reviewcount : 0} reviews)
                  </span>
                </div>
              )}
            </div>

            <p className="text-body text-neutral-700 mb-8">
              {product.description}
            </p>

            {isPlant(product) && (
              <div className="mb-8">
                <h3 className="text-h5 font-semibold text-neutral-900 mb-4">Care Instructions</h3>
                <ul className="space-y-2 text-body text-neutral-700">
                  <li><strong>Light:</strong> {product.careinstructions.light}</li>
                  <li><strong>Water:</strong> {product.careinstructions.water}</li>
                  <li><strong>Humidity:</strong> {product.careinstructions.humidity}</li>
                  <li><strong>Temperature:</strong> {product.careinstructions.temperature}</li>
                  <li><strong>Soil:</strong> {product.careinstructions.soil}</li>
                </ul>
              </div>
            )}

            {isSupply(product) && (
              <div className="mb-8">
                <h3 className="text-h5 font-semibold text-neutral-900 mb-4">Specifications</h3>
                <ul className="space-y-2 text-body text-neutral-700">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <li key={key}><strong>{key}:</strong> {value}</li>
                  ))}
                </ul>
              </div>
            )}

            {isService(product) && (
              <div className="mb-8">
                <h3 className="text-h5 font-semibold text-neutral-900 mb-4">Features</h3>
                <ul className="space-y-2 text-body text-neutral-700">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <svg className="w-5 h-5 text-primary-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {'instock' in product && (
              <div className="mb-8">
                <p className={`text-h6 font-semibold ${product.instock ? 'text-green-600' : 'text-red-600'}`}>
                  {product.instock ? `In Stock (${product.stockquantity} available)` : 'Out of Stock'}
                </p>
              </div>
            )}

            <div className="flex items-center space-x-4 mb-8">
              {('instock' in product && product.instock && product.stockquantity > 0) && (
                <div className="flex items-center border border-neutral-300 rounded-lg">
                  <button
                    className="p-2 text-neutral-600 hover:bg-neutral-100 rounded-l-lg"
                    onClick={() => handleQuantityChange(quantity - 1)}
                    disabled={quantity <= 1}
                    aria-label="Decrease quantity"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>
                  </button>
                  <input
                    type="number"
                    className="w-16 text-center border-x border-neutral-300 text-h6 font-semibold text-neutral-900 focus:outline-none"
                    value={quantity}
                    onChange={(e) => handleQuantityChange(parseInt(e.target.value))}
                    min="1"
                    max={'stockquantity' in product ? product.stockquantity : 999}
                    aria-label="Product quantity"
                  />
                  <button
                    className="p-2 text-neutral-600 hover:bg-neutral-100 rounded-r-lg"
                    onClick={() => handleQuantityChange(quantity + 1)}
                    disabled={('stockquantity' in product && quantity >= product.stockquantity)}
                    aria-label="Increase quantity"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                  </button>
                </div>
              )}
              
              <Button
                variant="primary"
                size="lg"
                className="flex-1"
                onClick={() => handleAddToCart(product)}
                disabled={('instock' in product && !product.instock) || ('stockquantity' in product && product.stockquantity === 0)}
              >
                {('instock' in product && !product.instock) || ('stockquantity' in product && product.stockquantity === 0) ? 'Out of Stock' : 'Add to Cart'}
              </Button>

              {/* Wishlist Button */}
              <Button
                variant={isInWishlist ? "secondary" : "outline"}
                size="lg"
                onClick={() => handleWishlistToggle(product)}
                className="flex items-center space-x-2"
                aria-label={isInWishlist ? "Remove from wishlist" : "Add to wishlist"}
              >
                <svg 
                  className={`w-5 h-5 ${isInWishlist ? 'fill-current text-red-500' : 'stroke-current'}`} 
                  fill={isInWishlist ? "currentColor" : "none"} 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                <span className="hidden sm:inline">
                  {isInWishlist ? 'Saved' : 'Save'}
                </span>
              </Button>
            </div>

            {/* Customer Reviews */}
            <div className="mt-12">
              <h2 className="text-h3 font-bold text-neutral-900 mb-6">Customer Reviews</h2>
              
              {/* Review Submission Form */}
              <Card className="p-6 mb-8">
                <h3 className="text-h5 font-semibold text-neutral-900 mb-4">Write a Review</h3>
                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="review-rating" className="form-label">Your Rating</label>
                    <div className="flex items-center space-x-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          className={`text-2xl ${
                            star <= newReviewRating ? 'text-yellow-400' : 'text-neutral-300'
                          } hover:text-yellow-300 transition-colors`}
                          onClick={() => setNewReviewRating(star)}
                          aria-label={`${star} star rating`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>
                  <Input
                    label="Your Comment"
                    type="text"
                    placeholder="Share your thoughts on this product..."
                    value={newReviewText}
                    onChange={(e) => setNewReviewText(e.target.value)}
                    required
                  />
                  <Button type="submit" variant="primary" size="md">
                    Submit Review
                  </Button>
                </form>
              </Card>

              {/* Existing Reviews List */}
              {reviews.length > 0 ? (
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <Card key={review.id} className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-1">
                          {[...Array(review.rating)].map((_, i) => (
                            <svg key={i} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                              <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                            </svg>
                          ))}
                          {[...Array(5 - review.rating)].map((_, i) => (
                            <svg key={i + review.rating} className="w-4 h-4 text-neutral-300 fill-current" viewBox="0 0 20 20">
                              <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                            </svg>
                          ))}
                        </div>
                        <span className="text-body-sm text-neutral-500">
                          {new Date(review.createdat).toLocaleDateString()}
                        </span>
                      </div>
                      <h3 className="text-h6 font-semibold text-neutral-900 mb-2">
                        {review.username}
                      </h3>
                      <p className="text-body text-neutral-700">
                        {review.comment}
                      </p>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-body text-neutral-600">
                  No reviews yet. Be the first to review this product!
                </p>
              )}
            </div>

            {/* Related Products */}
            <div className="mt-12">
              <h2 className="text-h3 font-bold text-neutral-900 mb-6">Related Products</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {relatedProducts.length > 0 ? (
                  relatedProducts.map((relatedProduct) => {
                    let pathPrefix = '';
                    if (isPlant(relatedProduct)) {
                      pathPrefix = 'plants';
                    } else if (isSupply(relatedProduct)) {
                      pathPrefix = 'supplies';
                    } else if (isService(relatedProduct)) {
                      pathPrefix = 'services';
                    }

                    return (
                      <Card key={relatedProduct.id} className="group">
                        <Link to={`/${pathPrefix}/${relatedProduct.id}`} className="block">
                          <img
                            src={relatedProduct.image}
                            alt={relatedProduct.name}
                            className="w-full h-32 object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-105"
                          />
                          <div className="p-4">
                            <h3 className="text-h6 font-semibold text-neutral-900 mb-1">
                              {relatedProduct.name}
                            </h3>
                            <p className="text-body-sm text-neutral-600">
                              ${relatedProduct.price.toFixed(2)}
                            </p>
                          </div>
                        </Link>
                      </Card>
                    );
                  })
                ) : (
                  <p className="text-body text-neutral-600 col-span-full">
                    No related products found.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
