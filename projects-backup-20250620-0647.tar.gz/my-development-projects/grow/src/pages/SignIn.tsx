import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button, Input, Card } from '../components/ui';
import { useUserStore } from '../store/userStore';

const signInSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type SignInFormData = z.infer<typeof signInSchema>;

const SignIn: React.FC = () => {
  const navigate = useNavigate();
  const { login, isAuthenticated } = useUserStore();

  const { register, handleSubmit, formState: { errors } } = useForm<SignInFormData>({
    resolver: zodResolver(signInSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/'); // Redirect to home if already authenticated
    }
  }, [isAuthenticated, navigate]);

  const onSubmit = async (data: SignInFormData) => {
    await login(data.email, data.password);
    // The login action handles alerts internally for mock success/failure
    // If a real backend, you'd check the response here.
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <Card className="max-w-md w-full space-y-8 p-8">
        <div>
          <h2 className="mt-6 text-center text-h2 font-bold text-neutral-900">
            Sign in to your account
          </h2>
          <p className="mt-2 text-center text-body text-neutral-600">
            Or{' '}
            <Link to="/signup" className="font-medium text-primary-600 hover:text-primary-500">
              create a new account
            </Link>
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit(onSubmit)}>
          <Input
            label="Email address"
            type="email"
            placeholder="you@example.com"
            {...register('email')}
            error={errors.email?.message}
            required
          />
          <Input
            label="Password"
            type="password"
            placeholder="••••••••"
            {...register('password')}
            error={errors.password?.message}
            required
          />
          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full"
          >
            Sign In
          </Button>
        </form>
      </Card>
    </div>
  );
};

export default SignIn;
