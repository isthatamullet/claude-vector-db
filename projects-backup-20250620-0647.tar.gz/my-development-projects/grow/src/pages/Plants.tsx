import React, { useEffect, useState, useMemo } from 'react';
import { useProductStore } from '../store/productStore';
import { useCartStore } from '../store/cartStore';
import { Button, Card } from '../components/ui';
import { Link } from 'react-router-dom';
import type { Plant, PlantCategory, PlantSize, ProductFilters } from '../types';

const Plants: React.FC = () => {
  const { plants, fetchPlants, loading, filters, setFilters } = useProductStore();
  const { addItem } = useCartStore();

  useEffect(() => {
    fetchPlants();
  }, [fetchPlants]);

  const handleAddToCart = (plant: Plant) => {
    addItem({
      type: 'plant',
      product: plant,
      quantity: 1,
    });
  };

  const handleFilterChange = (filterType: keyof ProductFilters, value: any) => {
    setFilters({
      ...filters,
      [filterType]: value,
    });
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const [sortBy, sortOrder] = e.target.value.split('-');
    setFilters({
      ...filters,
      sortBy: sortBy as ProductFilters['sortBy'],
      sortOrder: sortOrder as ProductFilters['sortOrder'],
    });
  };

  const filteredAndSortedPlants = useMemo(() => {
    let filtered = [...plants];

    // Apply category filter
    if (filters.category && filters.category.length > 0) {
      filtered = filtered.filter(plant => filters.category?.includes(plant.category));
    }

    // Apply size filter
    if (filters.size && filters.size.length > 0) {
      filtered = filtered.filter(plant => filters.size?.includes(plant.size));
    }

    // Apply difficulty filter
    if (filters.difficulty && filters.difficulty.length > 0) {
      filtered = filtered.filter(plant => filters.difficulty?.includes(plant.difficulty));
    }

    // Apply inStock filter
    if (filters.inStock !== undefined) {
      filtered = filtered.filter(plant => plant.instock === filters.inStock);
    }

    // Apply price range filter
    if (filters.priceRange) {
      filtered = filtered.filter(plant => 
        plant.price >= filters.priceRange!.min && plant.price <= filters.priceRange!.max
      );
    }

    // Apply sorting
    if (filters.sortBy) {
      filtered.sort((a, b) => {
        let valA: any;
        let valB: any;

        switch (filters.sortBy) {
          case 'name':
            valA = a.name.toLowerCase();
            valB = b.name.toLowerCase();
            break;
          case 'price':
            valA = a.price;
            valB = b.price;
            break;
          case 'rating':
            valA = a.rating;
            valB = b.rating;
            break;
          // Add more cases for other sort options if needed
          default:
            valA = a.name.toLowerCase();
            valB = b.name.toLowerCase();
        }

        if (valA < valB) return filters.sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return filters.sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [plants, filters]);

  const plantCategories: PlantCategory[] = ['Houseplants', 'Succulents', 'Tropical', 'Air Plants', 'Flowering', 'Foliage', 'Rare & Exotic'];
  const plantSizes: PlantSize[] = ['Small', 'Medium', 'Large', 'Extra Large'];
  const plantDifficulties = ['Beginner', 'Intermediate', 'Advanced'];


  return (
    <div className="min-h-screen bg-white">
      {/* Page Header */}
      <section className="bg-primary-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-h1 font-bold text-neutral-900 mb-4">
              Our Plant Collection
            </h1>
            <p className="text-body-lg text-neutral-600 max-w-2xl mx-auto">
              Discover our carefully curated selection of premium houseplants, from beginner-friendly varieties to rare exotic species.
            </p>
          </div>
        </div>
      </section>

      {/* Plants Grid with Filters and Sorting */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8 space-y-4 md:space-y-0">
            {/* Filters */}
            <div className="flex flex-wrap gap-4">
              {/* Category Filter */}
              <select
                className="form-input w-full md:w-auto"
                value={filters.category && filters.category.length > 0 ? filters.category[0] : ''}
                onChange={(e) => handleFilterChange('category', e.target.value ? [e.target.value] : [])}
              >
                <option value="">All Categories</option>
                {plantCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>

              {/* Size Filter */}
              <select
                className="form-input w-full md:w-auto"
                value={filters.size && filters.size.length > 0 ? filters.size[0] : ''}
                onChange={(e) => handleFilterChange('size', e.target.value ? [e.target.value] : [])}
              >
                <option value="">All Sizes</option>
                {plantSizes.map(size => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>

              {/* Difficulty Filter */}
              <select
                className="form-input w-full md:w-auto"
                value={filters.difficulty && filters.difficulty.length > 0 ? filters.difficulty[0] : ''}
                onChange={(e) => handleFilterChange('difficulty', e.target.value ? [e.target.value] : [])}
              >
                <option value="">All Difficulties</option>
                {plantDifficulties.map(diff => (
                  <option key={diff} value={diff}>{diff}</option>
                ))}
              </select>

              {/* In Stock Filter */}
              <label className="flex items-center space-x-2 text-body text-neutral-700">
                <input
                  type="checkbox"
                  className="form-checkbox rounded text-primary-500 focus:ring-primary-500"
                  checked={filters.inStock || false}
                  onChange={(e) => handleFilterChange('inStock', e.target.checked)}
                />
                <span>In Stock</span>
              </label>
            </div>

            {/* Sorting */}
            <div className="flex items-center space-x-2">
              <label htmlFor="sort-by" className="text-body text-neutral-700">Sort by:</label>
              <select
                id="sort-by"
                className="form-input w-full md:w-auto"
                value={`${filters.sortBy}-${filters.sortOrder}`}
                onChange={handleSortChange}
              >
                <option value="name-asc">Name (A-Z)</option>
                <option value="name-desc">Name (Z-A)</option>
                <option value="price-asc">Price (Low to High)</option>
                <option value="price-desc">Price (High to Low)</option>
                <option value="rating-desc">Rating (High to Low)</option>
                <option value="rating-asc">Rating (Low to High)</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-neutral-200 h-64 rounded-lg mb-4"></div>
                  <div className="bg-neutral-200 h-4 rounded mb-2"></div>
                  <div className="bg-neutral-200 h-4 rounded w-3/4 mb-2"></div>
                  <div className="bg-neutral-200 h-8 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredAndSortedPlants.length > 0 ? (
                filteredAndSortedPlants.map((plant) => (
                  <Link to={`/plants/${plant.id}`} key={plant.id} className="block">
                    <Card className="group">
                      <div className="relative overflow-hidden">
                        <img
                          src={plant.image}
                          alt={plant.name}
                          className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                          onError={(e) => { e.currentTarget.src = '/vite.svg'; }} // Add onError fallback
                        />
                        {plant.originalprice && (
                          <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded text-sm font-medium">
                            Sale
                          </div>
                        )}
                        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-xs font-medium text-neutral-700">
                          {plant.difficulty}
                        </div>
                      </div>
                      
                      <div className="p-6">
                        <h3 className="text-h6 font-semibold text-neutral-900 mb-1">
                          {plant.name}
                        </h3>
                        <p className="text-body-sm text-neutral-500 mb-3 italic">
                          {plant.scientificname}
                        </p>
                        
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <span className="text-h6 font-bold text-primary-600">
                              ${plant.price}
                            </span>
                            {plant.originalprice && (
                              <span className="text-body-sm text-neutral-400 line-through">
                                ${plant.originalprice}
                              </span>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-1">
                            <svg className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                              <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                            </svg>
                            <span className="text-body-sm text-neutral-600">
                              {plant.rating}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-1 mb-4">
                          {plant.features.slice(0, 2).map((feature) => (
                            <span
                              key={feature}
                              className="px-2 py-1 bg-primary-50 text-primary-700 text-xs rounded-full"
                            >
                              {feature}
                            </span>
                          ))}
                        </div>
                        
                        <div className="space-y-2 mb-4">
                          <div className="flex justify-between text-body-sm">
                            <span className="text-neutral-600">Light:</span>
                            <span className="text-neutral-900">{plant.careinstructions.light}</span>
                          </div>
                          <div className="flex justify-between text-body-sm">
                            <span className="text-neutral-600">Light:</span>
                            <span className="text-neutral-900">{plant.careinstructions.light}</span>
                          </div>
                          <div className="flex justify-between text-body-sm">
                            <span className="text-neutral-600">Stock:</span>
                            <span className={`${plant.instock ? 'text-green-600' : 'text-red-600'}`}>
                              {plant.instock ? `${plant.stockquantity} available` : 'Out of stock'}
                            </span>
                          </div>
                        </div>
                        
                        <Button
                          variant="primary"
                          size="sm"
                          className="w-full"
                          onClick={(e) => { e.preventDefault(); handleAddToCart(plant); }}
                          disabled={!plant.instock}
                        >
                          {plant.instock ? 'Add to Cart' : 'Out of Stock'}
                        </Button>
                      </div>
                    </Card>
                  </Link>
                ))
              ) : (
                <div className="text-center py-16 col-span-full">
                  <div className="w-24 h-24 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg className="w-12 h-12 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                    </svg>
                  </div>
                  <h3 className="text-h5 font-semibold text-neutral-900 mb-2">
                    No plants found matching your criteria.
                  </h3>
                  <p className="text-body text-neutral-600">
                    Try adjusting your filters or search terms.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Plants;
