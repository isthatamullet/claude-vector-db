import React, { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useProductStore } from '../store/productStore';
import { Card } from '../components/ui';
import type { Plant, Supply, Service, SearchResult } from '../types';

const SearchResults: React.FC = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const { searchProducts, loading } = useProductStore();
  const [results, setResults] = useState<SearchResult | null>(null);

  useEffect(() => {
    const performSearch = async () => {
      if (query) {
        const searchResult = await searchProducts(query);
        setResults(searchResult);
      } else {
        setResults(null);
      }
    };
    performSearch();
  }, [query, searchProducts]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <h1 className="text-h2 font-bold text-neutral-900 mb-4">Searching...</h1>
          <p className="text-body-lg text-neutral-600">
            Please wait while we find your green treasures.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-h1 font-bold text-neutral-900 mb-8">
          Search Results for "{query}"
        </h1>

        {results && results.total > 0 ? (
          <div className="space-y-12">
            {results.plants.length > 0 && (
              <div>
                <h2 className="text-h2 font-bold text-neutral-900 mb-6">Plants ({results.plants.length})</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {results.plants.map((plant) => (
                    <Link to={`/plants/${plant.id}`} key={plant.id} className="block">
                      <Card className="group">
                        <img
                          src={plant.image}
                          alt={plant.name}
                          className="w-full h-48 object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-105"
                        />
                        <div className="p-4">
                          <h3 className="text-h6 font-semibold text-neutral-900 mb-1">
                            {plant.name}
                          </h3>
                          <p className="text-body-sm text-neutral-600">
                            ${plant.price.toFixed(2)}
                          </p>
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {results.supplies.length > 0 && (
              <div>
                <h2 className="text-h2 font-bold text-neutral-900 mb-6">Supplies ({results.supplies.length})</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {results.supplies.map((supply) => (
                    <Link to={`/supplies/${supply.id}`} key={supply.id} className="block">
                      <Card className="group">
                        <img
                          src={supply.image}
                          alt={supply.name}
                          className="w-full h-48 object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-105"
                        />
                        <div className="p-4">
                          <h3 className="text-h6 font-semibold text-neutral-900 mb-1">
                            {supply.name}
                          </h3>
                          <p className="text-body-sm text-neutral-600">
                            ${supply.price.toFixed(2)}
                          </p>
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {results.services.length > 0 && (
              <div>
                <h2 className="text-h2 font-bold text-neutral-900 mb-6">Services ({results.services.length})</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {results.services.map((service) => (
                    <Link to={`/services/${service.id}`} key={service.id} className="block">
                      <Card className="group">
                        <img
                          src={service.image}
                          alt={service.name}
                          className="w-full h-48 object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-105"
                        />
                        <div className="p-4">
                          <h3 className="text-h6 font-semibold text-neutral-900 mb-1">
                            {service.name}
                          </h3>
                          <p className="text-body-sm text-neutral-600">
                            ${service.price.toFixed(2)}
                          </p>
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-12 h-12 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-h5 font-semibold text-neutral-900 mb-2">
              No results found for "{query}"
            </h3>
            <p className="text-body text-neutral-600">
              Try a different search term or browse our categories.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchResults;
