import React, { useEffect } from 'react';
import { useProductStore } from '../store/productStore';
import { useCartStore } from '../store/cartStore';
import { Button, Card } from '../components/ui';
import { Link } from 'react-router-dom'; // Import Link
import type { Service } from '../types';

const Services: React.FC = () => {
  const { services, fetchServices, loading } = useProductStore();
  const { addItem } = useCartStore();

  useEffect(() => {
    fetchServices();
  }, [fetchServices]);

  const handleBookService = (service: Service) => {
    addItem({
      type: 'service',
      product: service,
      quantity: 1,
    });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Page Header */}
      <section className="bg-accent-warm-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-h1 font-bold text-neutral-900 mb-4">
              Expert Plant Services
            </h1>
            <p className="text-body-lg text-neutral-600 max-w-2xl mx-auto">
              Let our plant experts help you succeed. From professional repotting to fun plant parties, we're here to support your green journey.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-neutral-200 h-64 rounded-lg mb-4"></div>
                  <div className="bg-neutral-200 h-4 rounded mb-2"></div>
                  <div className="bg-neutral-200 h-4 rounded w-3/4 mb-2"></div>
                  <div className="bg-neutral-200 h-8 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service) => (
                <Link to={`/services/${service.id}`} key={service.id} className="block"> {/* Wrap Card with Link */}
                  <Card className="group h-full flex flex-col">
                    <div className="relative overflow-hidden">
                      <img
                        src={service.image}
                        alt={service.name}
                        className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-xs font-medium text-neutral-700">
                        {service.duration}
                      </div>
                      <div className={`absolute top-4 left-4 px-2 py-1 rounded text-xs font-medium ${
                        service.availability === 'Available' 
                          ? 'bg-green-100 text-green-800' 
                          : service.availability === 'Limited'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {service.availability}
                      </div>
                    </div>
                    
                    <div className="p-6 flex-1 flex flex-col">
                      <h3 className="text-h5 font-semibold text-neutral-900 mb-3">
                        {service.name}
                      </h3>
                      <p className="text-body-sm text-neutral-600 mb-4 flex-1">
                        {service.description}
                      </p>
                      
                      <div className="mb-4">
                        <h4 className="text-label font-semibold text-neutral-900 mb-2">
                          What's Included:
                        </h4>
                        <ul className="space-y-1">
                          {service.features.map((feature, index) => (
                            <li key={index} className="flex items-start space-x-2 text-body-sm text-neutral-600">
                              <svg className="w-4 h-4 text-primary-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                              </svg>
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                        <div className="text-h4 font-bold text-primary-600">
                          ${service.price}
                        </div>
                        <div className="text-body-sm text-neutral-600">
                          {service.category}
                        </div>
                      </div>
                      
                      <Button
                        variant="primary"
                        size="md"
                        className="w-full"
                        onClick={(e) => { e.preventDefault(); handleBookService(service); }} // Prevent navigation on add to cart
                        disabled={service.availability === 'Unavailable'}
                      >
                        {service.availability === 'Unavailable' ? 'Currently Unavailable' : 'Book Service'}
                      </Button>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          )}

          {!loading && services.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-12 h-12 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-h5 font-semibold text-neutral-900 mb-2">
                No services found
              </h3>
              <p className="text-body text-neutral-600">
                We're currently updating our service offerings. Please check back soon!
              </p>
            </div>
          )}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-neutral-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-h2 font-bold text-neutral-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-body-lg text-neutral-600">
              Have questions about our services? We've got answers.
            </p>
          </div>

          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">
                How do I schedule a service?
              </h3>
              <p className="text-body text-neutral-600">
                Simply click "Book Service" on any service above, add it to your cart, and proceed to checkout. We'll contact you within 24 hours to schedule your appointment.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">
                Do you provide plants for repotting services?
              </h3>
              <p className="text-body text-neutral-600">
                You can bring your own plants, or we can provide new plants for an additional cost. We'll discuss your preferences when scheduling your appointment.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">
                What's included in a plant party?
              </h3>
              <p className="text-body text-neutral-600">
                Our plant party package includes plants, pots, soil, tools, expert guidance, take-home care guides, and party decorations for up to 8 people. Perfect for birthdays, team building, or just fun with friends!
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">
                Can I cancel or reschedule my service?
              </h3>
              <p className="text-body text-neutral-600">
                Yes! We understand plans change. You can cancel or reschedule up to 24 hours before your appointment without any fees.
              </p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
