import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useProductStore } from '../store/productStore';
import { useCartStore } from '../store/cartStore';
import { Button, Card } from '../components/ui';
import type { Plant } from '../types';
import { motion, useScroll, useTransform } from 'framer-motion';
import { getHeroImage } from '../utils/pixabayApi';

const Home: React.FC = () => {
  const { plants, fetchPlants, loading } = useProductStore();
  const { addItem } = useCartStore();

  useEffect(() => {
    fetchPlants();
  }, [fetchPlants]);

  const featuredPlants = plants.slice(0, 3);

  const handleAddToCart = (plant: Plant) => {
    addItem({
      type: 'plant',
      product: plant,
      quantity: 1,
    });
  };

  // Hero Section Parallax
  const heroRef = useRef(null);
  const { scrollYProgress: heroScrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });
  const heroBgY = useTransform(heroScrollYProgress, [0, 1], ["0%", "50%"]);
  const heroContentOpacity = useTransform(heroScrollYProgress, [0, 0.5], [1, 0]);

  const [heroImage, setHeroImage] = React.useState('');

  useEffect(() => {
    const fetchImage = async () => {
      const img = await getHeroImage();
      setHeroImage(img);
    };
    fetchImage();
  }, []);

  // Featured Plants Section Parallax
  const featuredRef = useRef(null);
  const { scrollYProgress: featuredScrollYProgress } = useScroll({
    target: featuredRef,
    offset: ["start end", "end start"]
  });
  const featuredY = useTransform(featuredScrollYProgress, [0, 1], ["-50%", "0%"]);
  const featuredOpacity = useTransform(featuredScrollYProgress, [0, 0.5], [0, 1]);

  // Services Preview Section Parallax
  const servicesRef = useRef(null);
  const { scrollYProgress: servicesScrollYProgress } = useScroll({
    target: servicesRef,
    offset: ["start end", "end start"]
  });
  const servicesBgY = useTransform(servicesScrollYProgress, [0, 1], ["-30%", "0%"]);
  const servicesContentY = useTransform(servicesScrollYProgress, [0, 1], ["30%", "0%"]);
  const servicesOpacity = useTransform(servicesScrollYProgress, [0, 0.5], [0, 1]);


  return (
    <div className="min-h-screen">
      {/* Hero Section with Parallax */}
      <section ref={heroRef} className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image with Parallax */}
        <motion.div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat parallax-bg"
          style={{
            backgroundImage: heroImage ? `url(${heroImage})` : 'url(https://cdn.pixabay.com/photo/2021/01/22/06/04/monstera-deliciosa-5939187_1280.jpg)',
            y: heroBgY, // Apply parallax effect
          }}
        >
          <div className="absolute inset-0 bg-black/40"></div>
        </motion.div>

        {/* Hero Content with Fade Out */}
        <motion.div
          className="relative z-10 text-center text-white max-w-4xl mx-auto px-4"
          style={{ opacity: heroContentOpacity }} // Apply fade out effect
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <h1 className="text-display-xl md:text-display-lg mb-6">
            Grow Your Green Paradise
          </h1>
          <p className="text-body-lg md:text-h6 mb-8 max-w-2xl mx-auto">
            Discover premium houseplants, expert care services, and everything you need to create your perfect indoor garden.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/plants">
              <Button size="xl">Shop Plants</Button>
            </Link>
            <Link to="/services">
              <Button variant="outline" size="xl">Explore Services</Button>
            </Link>
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ y: 0 }}
          animate={{ y: [0, -10, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </motion.div>
      </section>

      {/* Featured Plants Section with Parallax */}
      <section ref={featuredRef} className="py-20 bg-white overflow-hidden">
        <motion.div
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
          style={{ y: featuredY, opacity: featuredOpacity }}
        >
          <div className="text-center mb-16">
            <h2 className="text-h2 font-bold text-neutral-900 mb-4">
              Featured Plants
            </h2>
            <p className="text-body-lg text-neutral-600 max-w-2xl mx-auto">
              Handpicked favorites that bring life and beauty to any space. Perfect for beginners and plant enthusiasts alike.
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-neutral-200 h-64 rounded-lg mb-4"></div>
                  <div className="bg-neutral-200 h-4 rounded mb-2"></div>
                  <div className="bg-neutral-200 h-4 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredPlants.map((plant) => (
                <Card key={plant.id} className="group">
                  <div className="relative overflow-hidden">
                    <img
                      src={plant.image}
                      alt={plant.name}
                      className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    {plant.originalPrice && (
                      <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded text-sm font-medium">
                        Sale
                      </div>
                    )}
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-h5 font-semibold text-neutral-900 mb-2">
                      {plant.name}
                    </h3>
                    <p className="text-body-sm text-neutral-600 mb-2">
                      {plant.scientificName}
                    </p>
                    <p className="text-body-sm text-neutral-600 mb-4 line-clamp-2">
                      {plant.description}
                    </p>
                    
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-h6 font-bold text-primary-600">
                          ${plant.price}
                        </span>
                        {plant.originalPrice && (
                          <span className="text-body-sm text-neutral-400 line-through">
                            ${plant.originalPrice}
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        <svg className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                          <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                        </svg>
                        <span className="text-body-sm text-neutral-600">
                          {plant.rating} ({plant.reviewCount})
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {plant.features.slice(0, 2).map((feature) => (
                        <span
                          key={feature}
                          className="px-2 py-1 bg-primary-50 text-primary-700 text-xs rounded-full"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                    
                    <Button
                      variant="primary"
                      size="md"
                      className="w-full"
                      onClick={() => handleAddToCart(plant)}
                    >
                      Add to Cart
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link to="/plants">
              <Button variant="outline" size="lg">View All Plants</Button>
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Services Preview Section with Parallax */}
      <section ref={servicesRef} className="py-20 bg-primary-50 relative overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url(https://cdn.pixabay.com/photo/2016/11/22/19/30/botanical-1850099_1280.jpg)', // Example botanical pattern
            y: servicesBgY,
            scale: 1.1, // Slightly scale up for depth effect
          }}
        />
        <motion.div
          className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
          style={{ y: servicesContentY, opacity: servicesOpacity }}
        >
          <div className="text-center mb-16">
            <h2 className="text-h2 font-bold text-neutral-900 mb-4">
              Expert Plant Services
            </h2>
            <p className="text-body-lg text-neutral-600 max-w-2xl mx-auto">
              From repotting to plant parties, our expert team is here to help you succeed with your green journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center p-8">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
              </div>
              <h3 className="text-h5 font-semibold text-neutral-900 mb-4">
                Plant Repotting
              </h3>
              <p className="text-body text-neutral-600 mb-6">
                Professional repotting service with premium soil and expert care for your plants.
              </p>
              <Button variant="outline" size="sm">
                Learn More
              </Button>
            </Card>

            <Card className="text-center p-8">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-h5 font-semibold text-neutral-900 mb-4">
                Plant Parties
              </h3>
              <p className="text-body text-neutral-600 mb-6">
                Host memorable plant potting parties with friends, family, or colleagues.
              </p>
              <Button variant="outline" size="sm">
                Learn More
              </Button>
            </Card>

            <Card className="text-center p-8">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <h3 className="text-h5 font-semibold text-neutral-900 mb-4">
                Plant Consultation</h3>
              <p className="text-body text-neutral-600 mb-6">
                Get personalized advice from our plant experts to solve any plant problems.
              </p>
              <Button variant="outline" size="sm">
                Learn More
              </Button>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Link to="/services">
              <Button variant="primary" size="lg">View All Services</Button>
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-h2 font-bold text-neutral-900 mb-4">
              Why Choose Grow?
            </h2>
            <p className="text-body-lg text-neutral-600 max-w-2xl mx-auto">
              We're passionate about plants and committed to helping you create the perfect green space.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">Premium Quality</h3>
              <p className="text-body-sm text-neutral-600">
                Hand-selected plants from trusted growers, ensuring the highest quality for your home.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">Fast Delivery</h3>
              <p className="text-body-sm text-neutral-600">
                Quick and safe delivery to your door, with special packaging to protect your plants.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">Expert Support</h3>
              <p className="text-body-sm text-neutral-600">
                Our plant experts are always ready to help with care tips and troubleshooting.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-h6 font-semibold text-neutral-900 mb-2">Plant Guarantee</h3>
              <p className="text-body-sm text-neutral-600">
                30-day plant guarantee - if your plant doesn't thrive, we'll make it right.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
