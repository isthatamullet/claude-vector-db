---
description: Universal web development principles and best practices for Cline across all projects.
author: Your Name/Organization
version: 1.0
tags: ["web-development", "best-practices", "general-rules", "ui-ux", "accessibility", "performance", "code-quality"]
globs: ["*"] # These rules apply to all projects
---

# Global Web Development Principles for Cline

These principles are fundamental guidelines for developing any web application, ensuring consistency, quality, and efficiency across all your projects.

## 1. Core Development Principles

*   **Follow Project Documentation:** ALWAYS adhere to instructions in project-specific `/docs` and `.clinerules` directories.
*   **Mobile-First Responsive Design:** ALWAYS implement mobile-first responsive design, utilizing a defined design system's breakpoint system.
*   **Design System Adherence:** ALWAYS use the exact color tokens, typography classes, and spacing variables defined in the project's design system.
*   **Structured Implementation Order:** ALWAYS follow the defined project or Product Requirements Document (PRD) implementation order.

## 2. Design System & UI/UX Compliance

*   **Component Library Usage:** Implement styles using a defined component library (e.g., button variants, card components, form inputs with focus states and validation).
*   **Animation & Interaction Patterns:** Include proper animation and interaction patterns (e.g., page transitions, micro-interactions, loading states, hover effects, focus management).
*   **Respect User Preferences:** Respect `prefers-reduced-motion` settings.

## 3. Technical Requirements

*   **Specified Tech Stack:** ALWAYS use the exact technology stack specified for the project.
*   **Type Safety:** Use TypeScript for type safety in all applicable codebases.
*   **Styling Framework Configuration:** Follow the exact installation and configuration process for the chosen styling framework (e.g., Tailwind CSS).
*   **Data Structure Typing:** Implement proper TypeScript interfaces matching the data structures defined in project requirements.
*   **External API Guidelines:** Follow guidelines for integrating and using specified external APIs (e.g., for images, data).

## 4. Responsive Design & Accessibility

*   **Mobile-First Implementation:** Start with mobile layouts (e.g., 320px+) and use progressive enhancement for larger screens. Ensure touch targets are minimum 44px.
*   **Accessibility Features:** Include proper ARIA labels and roles, semantic HTML structure, keyboard navigation support, screen reader compatibility, and focus management.
*   **WCAG Compliance:** Implement WCAG 2.1 AA compliance (e.g., color contrast ratios of 4.5:1 minimum, focus indicators, alt text for images, proper heading hierarchy).

## 5. Development Workflow & Quality

*   **Functional Components:** Create functional components where all links navigate, all buttons have `onClick` handlers, and all forms handle submission (even if not fully functional). All interactive elements must provide user feedback.
*   **Robust Error Handling:** Implement proper error handling (e.g., try-catch blocks for async operations, loading states for data fetching, error boundaries for UI components, user-friendly error messages).
*   **Thorough Testing:** Verify all responsive breakpoints, test all user flows, validate form submissions, check accessibility, and ensure cross-browser compatibility.
*   **Performance Optimization:** Optimize performance by lazy loading images and components, implementing proper caching strategies, minimizing bundle sizes, and using semantic HTML for better SEO.

## 6. Code Organization

*   **Consistent Project Structure:** Follow a consistent and logical project structure (e.g., `src/components/ui/`, `src/pages/`, `src/hooks/`).
*   **Consistent Naming Conventions:** Use consistent naming conventions (e.g., PascalCase for components, camelCase for functions/variables, kebab-case for CSS classes/file names, UPPER_SNAKE_CASE for constants).

## 7. Prohibited Practices (Never Do These Things)

*   **Avoid Hardcoding:** NEVER hardcode colors, spacing, or typography values; ALWAYS use design system tokens.
*   **Prioritize Mobile:** NEVER skip mobile layouts; ALWAYS design mobile-first.
*   **Follow Order:** NEVER implement features out of order; ALWAYS follow the defined implementation schedule.
*   **Ensure Accessibility:** NEVER ignore accessibility; all features MUST be accessible.
*   **Avoid Unapproved CDNs:** NEVER use external CDNs unless explicitly approved and documented.
*   **Functional UI:** NEVER implement placeholder buttons or UI elements without functionality; all interactive elements MUST work.
*   **Handle States:** NEVER skip error handling or loading states.
*   **Avoid Inline Styles:** NEVER use inline styles; ALWAYS use CSS classes and the design system.

## 8. Success Criteria (General)

Each feature implementation must generally include:
*   ✅ Mobile-responsive design
*   ✅ Accessibility compliance
*   ✅ Loading and error states
*   ✅ Proper TypeScript types (where applicable)
*   ✅ Design system adherence
*   ✅ User feedback mechanisms
*   ✅ Smooth animations and transitions

---

**Note on File Editing Best Practices:** The "Optimized File Editing Best Practices" from your original custom instructions are now fully covered and superseded by the `memory-bank.md` and `cline-continuous-improvement-protocol.md` rules, which dictate how I manage information and reflect on my actions. Therefore, those specific instructions are no longer needed as a separate section.
