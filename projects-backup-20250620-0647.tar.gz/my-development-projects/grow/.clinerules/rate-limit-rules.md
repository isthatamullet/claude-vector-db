---
description: Rules for managing API rate limits to ensure smoother operation.
author: Cline
version: 1.0
tags: ["rate-limit", "api", "performance", "protocol"]
globs: ["*"] # These rules apply to all projects
---

# Rate Limit Management

*   **Tool Use Request Limit:** NEVER exceed 15 requests per minute.
