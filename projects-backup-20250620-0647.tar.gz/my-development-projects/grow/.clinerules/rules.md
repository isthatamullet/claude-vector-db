# Cline Rules for Grow Plant Store Project

## Project Overview
You are developing a premium e-commerce website for "Grow" - a plant store specializing in houseplants, gardening supplies, and plant services. The site must feature cutting-edge UX/UI with parallax scrolling effects and mobile-first responsive design.

## Essential Documents
ALWAYS reference these project documents before making any decisions:
- `/docs/prd.md` - Project Requirements Document
- `/docs/design-system.md` - Complete design system specifications
- `/docs/tailwind-installation.md` - Tailwind CSS setup instructions

## Development Rules

### 1. Technology Stack Requirements
- **Framework:** React + Vite + TypeScript (mandatory)
- **Styling:** Tailwind CSS (follow installation guide exactly)
- **State Management:** Zustand for global state
- **Animations:** Framer Motion for parallax effects
- **Images:** Pixabay API integration (API key: 50523160-a1585f1d1edc8217bd4bef1a6)
- **Forms:** React Hook Form + Zod validation
- **Routing:** React Router

### 2. Project Structure Requirements
```
src/
├── components/
│   ├── ui/           # Reusable UI components
│   ├── layout/       # Header, footer, navigation
│   ├── product/      # Product-specific components
│   └── cart/         # Shopping cart components
├── pages/            # Route components (Home, Plants, Supplies, Services, OrderNow)
├── hooks/            # Custom React hooks
├── store/            # Zustand stores
├── types/            # TypeScript definitions
├── utils/            # Utility functions
└── styles/           # Global styles
```

### 3. Required Pages
Create these exact pages with full functionality:
- **Home** - Hero with parallax, featured products, services overview
- **Plants** - Product catalog with filtering and search
- **Supplies** - Gardening supplies with categories
- **Services** - Repotting and plant party services
- **Order Now** - Express checkout page

### 4. Design System Compliance
- Use ONLY colors, typography, and spacing defined in design-system.md
- Implement the exact component library specifications
- Follow accessibility standards (WCAG 2.1 AA)
- Maintain mobile-first responsive design principles

### 5. Parallax Implementation Requirements
Implement these specific parallax effects:
- **Hero section:** Background plants moving slower than foreground text
- **Product showcase:** Horizontal scrolling with depth layers
- **Services section:** Background botanical patterns with varying speeds
- **Performance:** Maintain 60fps, optimize for mobile devices

### 6. E-commerce Functionality
- **Product catalog** with search, filtering, and sorting
- **Shopping cart** with persistent state
- **Checkout process** with form validation
- **Payment integration** (Stripe development mode)
- **Inventory tracking** (mock data initially)
- **User reviews and ratings** system

### 7. Content Guidelines
- Generate appropriate plant-related content for all sections
- Use Pixabay API for all placeholder images
- Create realistic product data with proper plant information
- Include care instructions and plant specifications

### 8. Performance Requirements
- Page load time < 3 seconds
- Mobile-optimized interactions
- Lazy loading for images and components
- Code splitting for optimal bundle size

### 9. Code Quality Standards
- Use TypeScript for type safety
- Implement proper error boundaries
- Add loading states for all async operations
- Include comprehensive form validation
- Follow React best practices (hooks, components)

### 10. Testing and Validation
- Test on multiple screen sizes (mobile, tablet, desktop)
- Validate accessibility with keyboard navigation
- Ensure cross-browser compatibility
- Verify all links and buttons are functional

### 11. Implementation Order
Follow this exact sequence:
1. Project setup and basic structure
2. Tailwind CSS configuration with design tokens
3. Core layout components (header, footer, navigation)
4. Page routing and basic page layouts
5. Pixabay API integration
6. Product catalog and filtering system
7. Shopping cart functionality
8. Parallax effects implementation
9. Checkout and payment integration
10. Final polish and optimization

### 12. Development Constraints
- Development environment: VS Code web browser on iPad
- No external dependencies beyond specified tech stack
- Must work in modern browsers (Chrome, Firefox, Safari, Edge)
- Mobile-first development approach mandatory

### 13. Error Handling
- Implement graceful error boundaries
- Provide user-friendly error messages
- Include fallback UI for failed API calls
- Handle offline scenarios appropriately

### 14. Data Management
- Use mock data initially for products and services
- Implement proper data validation with Zod schemas
- Maintain data consistency across components
- Plan for future API integration

### 15. Styling Guidelines
- Use Tailwind utility classes exclusively
- Follow the design system color palette exactly
- Implement dark mode support where specified
- Ensure consistent spacing using design system tokens

## Critical Reminders
- NEVER deviate from the specified tech stack
- ALWAYS check design-system.md for styling decisions
- ALWAYS reference PRD for feature requirements
- ALWAYS test mobile responsiveness
- ALWAYS implement accessibility features
- ALWAYS use the provided Pixabay API key
- ALWAYS follow the implementation order specified

## Quality Checkpoints
Before considering any feature complete, verify:
- ✅ Responsive design works on all devices
- ✅ Accessibility standards are met
- ✅ Design system is correctly implemented
- ✅ Performance metrics are within requirements
- ✅ All interactions are functional
- ✅ Error states are handled gracefully
- ✅ Code follows TypeScript best practices

## Success Criteria
The project is successful when:
- All 5 pages are fully functional
- Shopping cart and checkout work end-to-end
- Parallax effects perform smoothly
- Mobile experience is optimized
- Design matches the premium brand vision
- All e-commerce features are implemented
- Code is maintainable and well-documented

---
description: Defines Cline's mandatory protocol for self-reflection, persistent knowledge capture using dedicated logs, and continuous improvement of its operational knowledge before task completion.
author: https://github.com/jeanibarz
version: 1.0
tags: ["protocol", "meta", "learning", "reflection", "knowledge-management", "core-behavior"]
globs: ["*"] # This core protocol is always active and applies to all Cline operations.
---
# Cline Continuous Improvement Protocol

**Objective:** Ensure Cline proactively learns from tasks, captures knowledge in a structured way, **distills fundamental insights,** refines understanding, and improves efficiency and reliability. This protocol maintains two key files: `memory-bank/raw_reflection_log.md` for initial detailed logging, and `memory-bank/consolidated_learnings.md` for pruned, actionable, long-term knowledge. This is vital for optimal performance and avoiding redundant effort.

**Core Principle:** Continuous learning and adaptation are **mandatory**. This protocol **must be executed before `attempt_completion`** for tasks with new learning, problem-solving, user feedback, or multiple steps. Trivial mechanical tasks *may* be exempt per higher-level rules; otherwise, execution is default.

**Key Knowledge Files:**
*   **`memory-bank/raw_reflection_log.md`**: Contains detailed, timestamped, and task-referenced raw entries from the "Task Review & Analysis" phase. This is the initial dump of all observations.
*   **`memory-bank/consolidated_learnings.md`**: Contains curated, summarized, and actionable insights derived from `raw_reflection_log.md`. This is the primary, refined knowledge base for long-term use. It should be kept concise and highly relevant.

---

## 1. Mandatory Pre-Completion Reflection & Raw Knowledge Capture

Before signaling task completion (e.g., via `attempt_completion`), Cline **must** perform the following internal steps:

### 1.1. Task Review & Analysis:
* Review the completed task (conversation, logs, artifacts).
* **Identify Learnings:** What new information, techniques, **underlying patterns,** API behaviors, project-specific commands (e.g., test, build, run flags), environment variables, setup quirks, or successful outcomes were discovered? **What core principles can be extracted?**
* **Identify Difficulties & Mistakes (as Learning Opportunities):** What challenges were faced? Were there any errors, misunderstandings, or inefficiencies? **How can these experiences refine future approaches (resilience & adaptation)?** Did user feedback indicate a misstep?
* **Identify Successes:** What went particularly well? What strategies or tools were notably effective? **What were the key contributing factors?**

### 1.2. Logging to `memory-bank/raw_reflection_log.md`:
* Based on Task Review & Analysis (1.1), create a timestamped, task-referenced entry in `memory-bank/raw_reflection_log.md` detailing all learnings, difficulties (and their resolutions/learnings), and successes (and contributing factors).
* This file serves as the initial, detailed record. Its entries are candidates for later consolidation.
* *Example Entry in `memory-bank/raw_reflection_log.md`:*
    ```markdown
    ---
    Date: {{CURRENT_DATE_YYYY_MM_DD}}
    TaskRef: "Implement JWT refresh logic for Project Alpha"

    Learnings:
    - Discovered `jose` library's `createRemoteJWKSet` is highly effective for dynamic key fetching for Project Alpha's auth.
    - Confirmed that a 401 error with `X-Reason: token-signature-invalid` from the auth provider requires re-fetching JWKS.
    - Project Alpha's integration tests: `cd services/auth && poetry run pytest -m integration --maxfail=1`
    - Required ENV for local testing of Project Alpha auth: `AUTH_API_KEY="test_key_alpha"`

    Difficulties:
    - Initial confusion about JWKS caching led to intermittent validation failures. Resolved by implementing a 5-minute cache.

    Successes:
    - The 5-minute JWKS cache with explicit bust mechanism proved effective.

    Improvements_Identified_For_Consolidation:
    - General pattern: JWKS caching strategy (5-min cache, explicit bust).
    - Project Alpha: Specific commands and ENV vars.
    ---
    ```

---

## 2. Knowledge Consolidation & Refinement Process (Periodic)

This outlines refining knowledge from `memory-bank/raw_reflection_log.md` into `memory-bank/consolidated_learnings.md`. This occurs periodically or when `raw_reflection_log.md` grows significantly, not necessarily after each task.

### 2.1. Review and Identify for Consolidation:
* Periodically, or when prompted by the user or significant new raw entries, review `memory-bank/raw_reflection_log.md`.
* Identify entries/parts representing durable, actionable, or broadly applicable knowledge (e.g., reusable patterns, critical configurations, effective strategies, resolved errors).

### 2.2. Synthesize and Transfer to `memory-bank/consolidated_learnings.md`:
* For identified insights:
    * Concisely synthesize, summarize, and **distill into generalizable principles or actionable patterns.**
    * Add refined knowledge to `memory-bank/consolidated_learnings.md`, organizing logically (by topic, project, tech) for easy retrieval.
    * Ensure `consolidated_learnings.md` content is actionable, **generalizable,** and non-redundant.
* *Example Entry in `memory-bank/consolidated_learnings.md` (derived from above raw log example):*
    ```markdown
    ## JWT Handling & JWKS
    **Pattern: JWKS Caching Strategy**
    - For systems using JWKS for token validation, implement a short-lived cache (e.g., 5 minutes) for fetched JWKS.
    - Include an explicit cache-bust mechanism if immediate key rotation needs to be handled.
    - *Rationale:* Balances performance by reducing frequent JWKS re-fetching against timely key updates. Mitigates intermittent validation failures due to stale keys.

    ## Project Alpha - Specifics
    **Auth Module:**
    - **Integration Tests:** `cd services/auth && poetry run pytest -m integration --maxfail=1`
    - **Local Testing ENV:** `AUTH_API_KEY="test_key_alpha"`
    ```

### 2.3. Prune `memory-bank/raw_reflection_log.md`:
* **Crucially, once information has been successfully transferred and consolidated into `memory-bank/consolidated_learnings.md`, the corresponding original entries or processed parts **must be removed** from `memory-bank/raw_reflection_log.md`.**
* This keeps `raw_reflection_log.md` focused on recent, unprocessed reflections and prevents it from growing indefinitely with redundant information.

### 2.4. Proposing `.clinerule` Enhancements (Exceptional):
* The primary focus of this protocol is the maintenance of `raw_reflection_log.md` and `consolidated_learnings.md`.
* If a significant, broadly applicable insight in `consolidated_learnings.md` strongly suggests modifying *another active `.clinerule`* (e.g., core workflow, tech guidance), Cline MAY propose this change after user confirmation. This is exceptional.

---

## 3. Guidelines for Knowledge Content

These guidelines apply to entries in `memory-bank/raw_reflection_log.md` (initial capture) and especially to `memory-bank/consolidated_learnings.md` (refined, long-term knowledge).

*   **Prioritize High-Value Insights:** Focus on lessons that significantly impact future performance, **lead to more robust or generalizable understanding,** or detail critical errors and their resolutions, major time-saving discoveries, fundamental shifts in understanding, and essential project-specific configurations.
*   **Be Concise & Actionable (especially for `consolidated_learnings.md`):** Information should be clear, to the point, and useful when revisited. What can be *done* differently or leveraged next time?
*   **Strive for Clarity and Future Usability:** Document insights in a way that is clear and easily understandable for future review, facilitating effective knowledge retrieval and application (akin to self-explainability).
*   **Document Persistently, Refine & Prune Continuously:** Capture raw insights immediately. Systematically refine, consolidate, and prune this knowledge as per Section 2.
*   **Organize for Retrieval:** Structure `consolidated_learnings.md` logically. Use clear headings and Markdown formatting.
*   **Avoid Low-Utility Information in `consolidated_learnings.md`:** This file should not contain trivial statements. Raw, verbose thoughts belong in `raw_reflection_log.md` before pruning.
*   **Support Continuous Improvement:** The ultimate goal is to avoid repeating mistakes, accelerate future tasks, and make Cline's operations more robust and reliable. Frame all knowledge with this in mind.
*   **Manage Information Density:** Actively work to keep `consolidated_learnings.md` dense with high-value information and free of outdated or overly verbose content. The pruning of `raw_reflection_log.md` is key to this.

---
description: A guide for effectively using the sequentialthinking MCP tool for dynamic and reflective problem-solving.
author: https://github.com/rafaelkallis
version: 1.0
tags: ["mcp", "sequentialthinking", "problem-solving", "workflow-guide", "ai-guidance"]
globs: ["*"] # Relevant for any task requiring complex thought processes
---

# Guide to Using the `sequentialthinking` MCP Tool

## 1. Objective

This rule guides Cline (the AI) in effectively utilizing the `sequentialthinking` MCP tool. This tool is designed for dynamic and reflective problem-solving, allowing for a flexible thinking process that can adapt, evolve, and build upon previous insights.

## 2. When to Use the `sequentialthinking` Tool

Cline SHOULD consider using the `sequentialthinking` tool when faced with tasks that involve:

*   **Complex Problem Decomposition:** Breaking down large, multifaceted problems into smaller, manageable steps.
*   **Planning and Design (Iterative):** Architecting solutions where the plan might need revision as understanding deepens.
*   **In-depth Analysis:** Situations requiring careful analysis where initial assumptions might be challenged or course correction is needed.
*   **Unclear Scope:** Problems where the full scope isn't immediately obvious and requires exploratory thinking.
*   **Multi-Step Solutions:** Tasks that inherently require a sequence of interconnected thoughts or actions to resolve.
*   **Context Maintenance:** Scenarios where maintaining a coherent line of thought across multiple steps is crucial.
*   **Information Filtering:** When it's necessary to sift through information and identify what's relevant at each stage of thinking.
*   **Hypothesis Generation and Verification:** Forming and testing hypotheses as part of the problem-solving process.

## 3. Core Principles for Using `sequentialthinking`

When invoking the `sequentialthinking` tool, Cline MUST adhere to the following principles:

*   **Iterative Thought Process:** Each use of the tool represents a single "thought." Build upon, question, or revise previous thoughts in subsequent calls.
*   **Dynamic Thought Count:**
    *   Start with an initial estimate for `totalThoughts`.
    *   Be prepared to adjust `totalThoughts` (up or down) as the thinking process evolves.
    *   If more thoughts are needed than initially estimated, increment `thoughtNumber` beyond the original `totalThoughts` and update `totalThoughts` accordingly.
*   **Honest Reflection:**
    *   Express uncertainty if it exists.
    *   Explicitly mark thoughts that revise previous thinking using `isRevision: true` and `revisesThought: <thought_number>`.
    *   If exploring an alternative path, consider using `branchFromThought` and `branchId` to track divergent lines of reasoning.
*   **Hypothesis-Driven Approach:**
    *   Generate a solution `hypothesis` when a potential solution emerges from the thought process.
    *   Verify the `hypothesis` based on the preceding Chain of Thought steps.
    *   Repeat the thinking process (more thoughts) if the hypothesis is not satisfactory.
*   **Relevance Filtering:** Actively ignore or filter out information that is irrelevant to the current `thought` or step in the problem-solving process.
*   **Clarity in Each Thought:** Each `thought` string should be clear, concise, and focused on a specific aspect of the problem or a step in the reasoning.
*   **Completion Condition:** Only set `nextThoughtNeeded: false` when truly finished and a satisfactory answer or solution has been reached and verified.

## 4. Parameters of the `sequentialthinking` Tool

Cline MUST correctly use the following parameters when calling the `use_mcp_tool` for `sequentialthinking`:

*   **`thought` (string, required):** The current thinking step. This can be an analytical step, a question, a revision, a hypothesis, etc.
*   **`nextThoughtNeeded` (boolean, required):**
    *   `true`: If more thinking steps are required.
    *   `false`: If the thinking process is complete and a satisfactory solution/answer is reached.
*   **`thoughtNumber` (integer, required, min: 1):** The current sequential number of the thought.
*   **`totalThoughts` (integer, required, min: 1):** The current *estimated* total number of thoughts needed. This can be adjusted.
*   **`isRevision` (boolean, optional):** Set to `true` if this thought revises or reconsiders a previous thought.
*   **`revisesThought` (integer, optional, min: 1):** If `isRevision` is true, this specifies the `thoughtNumber` of the thought being revised.
*   **`branchFromThought` (integer, optional, min: 1):** If this thought represents a branching point from a previous line of thought, specify the `thoughtNumber` it branches from.
*   **`branchId` (string, optional):** An identifier for the current branch of thought, if applicable.
*   **`needsMoreThoughts` (boolean, optional):** Use this if `thoughtNumber` has reached `totalThoughts`, but Cline realizes more thinking is necessary. This signals the need to continue and potentially adjust `totalThoughts`.

## 5. Workflow Example (Conceptual)

This illustrates how Cline might use the tool iteratively.

**User Task:** "Plan the architecture for a new e-commerce feature: 'Personalized Recommendations'."

**Cline's Internal Process using `sequentialthinking`:**

1.  **Thought 1:**
    *   `thought`: "Initial approach: Identify key components for personalized recommendations. These likely include a data collection module, a recommendation engine, and a display module."
    *   `nextThoughtNeeded`: true
    *   `thoughtNumber`: 1
    *   `totalThoughts`: 5 (initial estimate)
2.  **Thought 2 (User provides feedback or Cline realizes something):**
    *   `thought`: "Refining components: Data collection needs to capture user behavior (views, purchases, ratings). The engine might use collaborative filtering. Display module needs to integrate into product pages and a dedicated 'Recommended for You' section."
    *   `nextThoughtNeeded`: true
    *   `thoughtNumber`: 2
    *   `totalThoughts`: 5
3.  **Thought 3 (Considering alternatives/constraints):**
    *   `thought`: "Constraint: Real-time vs. batch processing for recommendations. Real-time offers better UX but is more complex. Batch might be a good MVP. Let's assume batch for MVP to simplify."
    *   `nextThoughtNeeded`: true
    *   `thoughtNumber`: 3
    *   `totalThoughts`: 5
4.  **Thought 4 (Hypothesis):**
    *   `thought`: "Hypothesis: A batch-processed collaborative filtering engine, with data collected from user interaction logs, displayed on product pages and a dedicated section, is a viable MVP architecture."
    *   `nextThoughtNeeded`: true
    *   `thoughtNumber`: 4
    *   `totalThoughts`: 5
5.  **Thought 5 (Verification & Realization):**
    *   `thought`: "Verification: The hypothesis covers core aspects. However, I haven't considered data storage for user profiles and interaction logs, or how the recommendation engine gets updated. More thoughts needed."
    *   `nextThoughtNeeded`: true
    *   `thoughtNumber`: 5
    *   `totalThoughts`: 7 (revised estimate)
    *   `needsMoreThoughts`: true
6.  **Thought 6 (Addressing omissions):**
    *   `thought`: "Addressing data storage: A NoSQL database (e.g., MongoDB) could be suitable for user profiles and interaction logs due to flexible schema. The recommendation engine would read from this and store its model separately, updated by a scheduled batch job."
    *   `nextThoughtNeeded`: true
    *   `thoughtNumber`: 6
    *   `totalThoughts`: 7
7.  **Thought 7 (Finalizing plan for MVP):**
    *   `thought`: "Final MVP Plan: 1. User interaction logger (to NoSQL DB). 2. Batch collaborative filtering engine (reads from NoSQL, updates model). 3. API to serve recommendations. 4. UI integration on product pages & dedicated section. This seems complete for an MVP."
    *   `nextThoughtNeeded`: false
    *   `thoughtNumber`: 7
    *   `totalThoughts`: 7

## 6. Critical Reminders for Cline

*   **DO NOT** use this tool for simple, single-step tasks. It is for complex reasoning.
*   **ALWAYS** ensure `thoughtNumber` increments correctly.
*   **BE PREPARED** to adjust `totalThoughts` as understanding evolves.
*   **FOCUS** on making progress towards a solution with each thought.
*   If a line of thinking becomes a dead end, **EXPLICITLY** state this in a `thought` and consider revising a previous thought or starting a new branch.

This guide should help Cline leverage the `sequentialthinking` MCP tool to its full potential.
