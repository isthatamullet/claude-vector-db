# Pixabay API Implementation Guide
*For Home Property Management Platform Development*

## 🔑 API Configuration

**API Key**: `50523160-a1585f1d1edc8217bd4bef1a6`
**Base URL**: `https://pixabay.com/api/`
**Documentation**: https://pixabay.com/api/docs/

## 🎯 Required Image Categories for Property Management

### Primary Categories
1. **Property Exteriors**
   - Search terms: "house exterior", "apartment building", "residential property", "modern home", "property facade"
   - Use for: Property listings, hero sections, property cards

2. **Interior Spaces**
   - Search terms: "modern kitchen", "living room", "bedroom interior", "bathroom design", "apartment interior"
   - Use for: Property detail pages, room showcases, listing galleries

3. **Maintenance & Tools**
   - Search terms: "maintenance tools", "repair work", "construction", "home improvement", "handyman"
   - Use for: Maintenance request forms, vendor profiles, work order sections

4. **Financial & Business**
   - Search terms: "calculator", "financial planning", "money management", "business meeting", "contract signing"
   - Use for: Payment pages, financial dashboards, reporting sections

5. **People & Interactions**
   - Search terms: "handshake", "real estate agent", "happy family", "professional meeting", "tenant landlord"
   - Use for: About pages, testimonials, user avatars (with proper licensing)

6. **Technology & Apps**
   - Search terms: "smartphone", "mobile app", "tablet", "technology", "digital interface"
   - Use for: App showcase, feature highlights, tech-focused sections

## 🛠️ Implementation Code

### Basic API Function
```javascript
const PIXABAY_API_KEY = '50523160-a1585f1d1edc8217bd4bef1a6'
const PIXABAY_BASE_URL = 'https://pixabay.com/api/'

/**
 * Fetch images from Pixabay API
 * @param {string} query - Search term
 * @param {object} options - Additional parameters
 * @returns {Promise<object>} - API response with images
 */
async function fetchPixabayImages(query, options = {}) {
  const defaultParams = {
    key: PIXABAY_API_KEY,
    q: encodeURIComponent(query),
    image_type: 'photo',
    orientation: 'horizontal',
    category: 'buildings', // or 'business', 'computer', etc.
    min_width: 1920,
    min_height: 1080,
    per_page: 20,
    safesearch: 'true',
    order: 'popular'
  }

  const params = { ...defaultParams, ...options }
  const searchParams = new URLSearchParams(params)
  
  try {
    const response = await fetch(`${PIXABAY_BASE_URL}?${searchParams}`)
    
    if (!response.ok) {
      throw new Error(`Pixabay API error: ${response.status}`)
    }
    
    const data = await response.json()
    return data
  } catch (error) {
    console.error('Error fetching Pixabay images:', error)
    throw error
  }
}
```

### React Hook for Image Management
```javascript
import { useState, useEffect } from 'react'

/**
 * Custom hook for managing Pixabay images
 * @param {string} query - Search query
 * @param {object} options - API options
 * @returns {object} - { images, loading, error, refetch }
 */
export function usePixabayImages(query, options = {}) {
  const [images, setImages] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const fetchImages = async () => {
    if (!query) return

    setLoading(true)
    setError(null)

    try {
      const data = await fetchPixabayImages(query, options)
      setImages(data.hits || [])
    } catch (err) {
      setError(err.message)
      setImages([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchImages()
  }, [query])

  return {
    images,
    loading,
    error,
    refetch: fetchImages,
    totalHits: images.totalHits || 0
  }
}
```

### Property Image Component
```jsx
import React from 'react'
import { usePixabayImages } from '../hooks/usePixabayImages'

const PropertyImagePlaceholder = ({ 
  searchTerm = "modern apartment", 
  className = "",
  alt = "Property image",
  fallbackSrc = "/default-property.jpg"
}) => {
  const { images, loading, error } = usePixabayImages(searchTerm, {
    category: 'buildings',
    orientation: 'horizontal',
    per_page: 5
  })

  if (loading) {
    return (
      <div className={`bg-neutral-200 animate-pulse ${className}`}>
        <div className="flex items-center justify-center h-full">
          <span className="text-neutral-500">Loading...</span>
        </div>
      </div>
    )
  }

  if (error || !images.length) {
    return (
      <img 
        src={fallbackSrc}
        alt={alt}
        className={className}
        onError={(e) => {
          e.target.src = "/placeholder-property.svg"
        }}
      />
    )
  }

  const randomImage = images[Math.floor(Math.random() * images.length)]

  return (
    <div className="relative">
      <img 
        src={randomImage.webformatURL}
        alt={alt}
        className={className}
        loading="lazy"
      />
      {/* Attribution overlay (optional, position as needed) */}
      <div className="absolute bottom-1 right-1 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
        <a 
          href={`https://pixabay.com/users/${randomImage.user}-${randomImage.user_id}/`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-white hover:underline"
        >
          {randomImage.user}
        </a>
      </div>
    </div>
  )
}
```

## 📋 API Parameters Reference

### Essential Parameters
```javascript
const commonParams = {
  key: PIXABAY_API_KEY,           // Required - Your API key
  q: 'search term',               // Search query
  image_type: 'photo',            // 'all', 'photo', 'illustration', 'vector'
  orientation: 'horizontal',       // 'all', 'horizontal', 'vertical'
  min_width: 1920,                // Minimum image width
  min_height: 1080,               // Minimum image height
  per_page: 20,                   // Images per request (3-200)
  safesearch: 'true',             // Filter adult content
  order: 'popular'                // 'popular', 'latest', 'ec', 'editors_choice'
}
```

### Category Options
```javascript
const categories = [
  'backgrounds',    // Background textures and patterns
  'fashion',       // Fashion and style images
  'nature',        // Natural landscapes and environments
  'science',       // Science and technology
  'education',     // Educational content
  'feelings',      // Emotions and feelings
  'health',        // Health and medical
  'people',        // People and portraits
  'religion',      // Religious content
  'places',        // Geographic locations
  'animals',       // Animals and wildlife
  'industry',      // Industrial and manufacturing
  'computer',      // Technology and computers
  'food',          // Food and drinks
  'sports',        // Sports and activities
  'transportation', // Vehicles and transport
  'travel',        // Travel and tourism
  'buildings',     // Architecture and buildings
  'business',      // Business and finance
  'music'          // Music and instruments
]
```

## 🎨 Specific Search Queries for Property Management

### Property Listings
```javascript
const propertyQueries = [
  'modern apartment exterior',
  'residential building facade',
  'luxury condo building',
  'single family home',
  'duplex house exterior',
  'apartment complex',
  'townhouse row',
  'high rise building'
]
```

### Interior Spaces
```javascript
const interiorQueries = [
  'modern kitchen design',
  'spacious living room',
  'master bedroom interior',
  'bathroom with shower',
  'dining room table',
  'home office space',
  'apartment balcony',
  'walk in closet'
]
```

### Maintenance & Operations
```javascript
const maintenanceQueries = [
  'maintenance tools on table',
  'plumber fixing pipe',
  'electrician working',
  'hvac technician',
  'home repair tools',
  'construction worker',
  'paint brush and roller',
  'toolbox with tools'
]
```

### Business & Finance
```javascript
const businessQueries = [
  'handshake business deal',
  'calculator and documents',
  'real estate contract',
  'financial planning meeting',
  'laptop with charts',
  'money and calculator',
  'business presentation',
  'professional meeting'
]
```

## 🔒 Attribution & Legal Requirements

### Attribution Format
```html
<!-- For visible attribution -->
<div class="image-attribution">
  Image by <a href="https://pixabay.com/users/username-userid/">Username</a> 
  from <a href="https://pixabay.com/">Pixabay</a>
</div>
```

### Metadata Storage
```javascript
// Store image metadata for proper attribution
const imageMetadata = {
  id: image.id,
  sourceUrl: image.pageURL,
  author: image.user,
  authorId: image.user_id,
  authorUrl: `https://pixabay.com/users/${image.user}-${image.user_id}/`,
  license: 'Pixabay License',
  downloadUrl: image.webformatURL,
  tags: image.tags.split(', ')
}
```

## ⚡ Performance Optimization

### Image Lazy Loading
```jsx
const LazyPixabayImage = ({ searchTerm, className, alt }) => {
  const [isInView, setIsInView] = useState(false)
  const imgRef = useRef()

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true)
          observer.disconnect()
        }
      },
      { threshold: 0.1 }
    )

    if (imgRef.current) {
      observer.observe(imgRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <div ref={imgRef} className={className}>
      {isInView ? (
        <PropertyImagePlaceholder 
          searchTerm={searchTerm}
          className="w-full h-full object-cover"
          alt={alt}
        />
      ) : (
        <div className="bg-neutral-200 animate-pulse w-full h-full" />
      )}
    </div>
  )
}
```

### Caching Strategy
```javascript
// Simple in-memory cache for development
const imageCache = new Map()

async function getCachedPixabayImages(query, options = {}) {
  const cacheKey = `${query}-${JSON.stringify(options)}`
  
  if (imageCache.has(cacheKey)) {
    return imageCache.get(cacheKey)
  }
  
  const data = await fetchPixabayImages(query, options)
  imageCache.set(cacheKey, data)
  
  // Optional: Clean cache after some time
  setTimeout(() => {
    imageCache.delete(cacheKey)
  }, 5 * 60 * 1000) // 5 minutes
  
  return data
}
```

## 🚨 Error Handling & Fallbacks

### Comprehensive Error Handling
```javascript
const handlePixabayError = (error, searchTerm) => {
  console.warn(`Pixabay API error for "${searchTerm}":`, error)
  
  // Track error for debugging (optional)
  if (typeof analytics !== 'undefined') {
    analytics.track('Pixabay API Error', {
      searchTerm,
      error: error.message
    })
  }
  
  // Return fallback image data
  return {
    hits: [{
      id: 'fallback',
      webformatURL: '/images/property-placeholder.jpg',
      user: 'Default',
      user_id: 0,
      tags: 'placeholder, property, default'
    }],
    total: 1,
    totalHits: 1
  }
}
```

### Progressive Enhancement
```jsx
const EnhancedPropertyImage = ({ searchTerm, className, alt }) => {
  const [imageState, setImageState] = useState('loading')
  const { images, loading, error } = usePixabayImages(searchTerm)

  const handleImageLoad = () => setImageState('loaded')
  const handleImageError = () => setImageState('error')

  // Show skeleton while loading
  if (loading || imageState === 'loading') {
    return (
      <div className={`bg-gradient-to-r from-neutral-200 to-neutral-300 animate-pulse ${className}`}>
        <div className="flex items-center justify-center h-full">
          <div className="w-8 h-8 border-2 border-neutral-400 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    )
  }

  // Show error state with fallback
  if (error || imageState === 'error' || !images.length) {
    return (
      <div className={`bg-neutral-100 border-2 border-dashed border-neutral-300 ${className}`}>
        <div className="flex flex-col items-center justify-center h-full text-neutral-500">
          <svg className="w-12 h-12 mb-2" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
          </svg>
          <span className="text-sm">Property Image</span>
        </div>
      </div>
    )
  }

  const image = images[0] // Use first image
  
  return (
    <img 
      src={image.webformatURL}
      alt={alt}
      className={className}
      onLoad={handleImageLoad}
      onError={handleImageError}
      loading="lazy"
    />
  )
}
```

## 📝 Usage Guidelines

1. **Always** use appropriate search terms for the context
2. **Always** implement proper error handling and fallbacks
3. **Always** respect rate limits (5,000 requests per hour)
4. **Always** cache images when possible to reduce API calls
5. **Always** provide meaningful alt text for accessibility
6. **Never** use offensive or inappropriate search terms
7. **Never** rely solely on Pixabay without fallback images
8. **Consider** attribution requirements for commercial use

This implementation provides a robust foundation for using Pixabay images throughout the property management platform development process.