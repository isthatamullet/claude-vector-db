# Grow Plant Store - Design System

## Overview

The Grow design system creates a premium, nature-inspired digital experience that connects users with the beauty and tranquility of plant life. This comprehensive system ensures consistency across all touchpoints while maintaining the organic, growth-focused brand essence.

## Brand Guidelines

### Brand Essence
- **Mission:** Bringing nature into every home through accessible, premium plant experiences
- **Vision:** A world where everyone can successfully grow and nurture plants
- **Values:** Growth, Sustainability, Beauty, Expertise, Community
- **Personality:** Nurturing, Expert, Premium, Accessible, Inspiring

### Brand Voice & Tone
- **Voice:** Knowledgeable yet approachable, passionate about plants
- **Tone Variations:**
  - **Educational:** Clear, helpful, encouraging
  - **Marketing:** Inspiring, aspirational, warm
  - **Support:** Patient, understanding, solution-focused
  - **Error States:** Gentle, reassuring, helpful

## Typography Scale

### Primary Typeface: Inter
**Usage:** Headlines, UI elements, body text
**Rationale:** Modern, highly legible, excellent screen optimization

### Secondary Typeface: Playfair Display
**Usage:** Accent headlines, quotes, special callouts
**Rationale:** Elegant serif that adds premium feel

### Typography Hierarchy

```css
/* Display Styles */
.text-display-xl {
  font-family: 'Playfair Display', serif;
  font-size: 4.5rem; /* 72px */
  line-height: 1.1;
  font-weight: 400;
  letter-spacing: -0.02em;
}

.text-display-lg {
  font-family: 'Playfair Display', serif;
  font-size: 3.75rem; /* 60px */
  line-height: 1.2;
  font-weight: 400;
  letter-spacing: -0.02em;
}

/* Heading Styles */
.text-h1 {
  font-family: 'Inter', sans-serif;
  font-size: 3rem; /* 48px */
  line-height: 1.2;
  font-weight: 700;
  letter-spacing: -0.01em;
}

.text-h2 {
  font-family: 'Inter', sans-serif;
  font-size: 2.25rem; /* 36px */
  line-height: 1.3;
  font-weight: 600;
  letter-spacing: -0.01em;
}

.text-h3 {
  font-family: 'Inter', sans-serif;
  font-size: 1.875rem; /* 30px */
  line-height: 1.3;
  font-weight: 600;
}

.text-h4 {
  font-family: 'Inter', sans-serif;
  font-size: 1.5rem; /* 24px */
  line-height: 1.4;
  font-weight: 600;
}

.text-h5 {
  font-family: 'Inter', sans-serif;
  font-size: 1.25rem; /* 20px */
  line-height: 1.4;
  font-weight: 600;
}

.text-h6 {
  font-family: 'Inter', sans-serif;
  font-size: 1.125rem; /* 18px */
  line-height: 1.4;
  font-weight: 600;
}

/* Body Styles */
.text-body-lg {
  font-family: 'Inter', sans-serif;
  font-size: 1.125rem; /* 18px */
  line-height: 1.6;
  font-weight: 400;
}

.text-body {
  font-family: 'Inter', sans-serif;
  font-size: 1rem; /* 16px */
  line-height: 1.6;
  font-weight: 400;
}

.text-body-sm {
  font-family: 'Inter', sans-serif;
  font-size: 0.875rem; /* 14px */
  line-height: 1.5;
  font-weight: 400;
}

/* Label Styles */
.text-label-lg {
  font-family: 'Inter', sans-serif;
  font-size: 1rem; /* 16px */
  line-height: 1.5;
  font-weight: 500;
}

.text-label {
  font-family: 'Inter', sans-serif;
  font-size: 0.875rem; /* 14px */
  line-height: 1.5;
  font-weight: 500;
}

.text-label-sm {
  font-family: 'Inter', sans-serif;
  font-size: 0.75rem; /* 12px */
  line-height: 1.5;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
```

## Color System

### Primary Colors

```css
:root {
  /* Primary Green Palette */
  --color-primary-50: #f0fdf4;
  --color-primary-100: #dcfce7;
  --color-primary-200: #bbf7d0;
  --color-primary-300: #86efac;
  --color-primary-400: #4ade80;
  --color-primary-500: #22c55e; /* Primary brand color */
  --color-primary-600: #16a34a;
  --color-primary-700: #15803d;
  --color-primary-800: #166534;
  --color-primary-900: #14532d;
  --color-primary-950: #052e16;
}
```

### Secondary Colors

```css
:root {
  /* Earth Tones */
  --color-secondary-50: #fafaf9;
  --color-secondary-100: #f5f5f4;
  --color-secondary-200: #e7e5e4;
  --color-secondary-300: #d6d3d1;
  --color-secondary-400: #a8a29e;
  --color-secondary-500: #78716c; /* Secondary brand color */
  --color-secondary-600: #57534e;
  --color-secondary-700: #44403c;
  --color-secondary-800: #292524;
  --color-secondary-900: #1c1917;
  --color-secondary-950: #0c0a09;
}
```

### Accent Colors

```css
:root {
  /* Warm Accent */
  --color-accent-warm-50: #fefce8;
  --color-accent-warm-100: #fef9c3;
  --color-accent-warm-400: #facc15;
  --color-accent-warm-500: #eab308;
  
  /* Cool Accent */
  --color-accent-cool-50: #ecfeff;
  --color-accent-cool-100: #cffafe;
  --color-accent-cool-400: #22d3ee;
  --color-accent-cool-500: #06b6d4;
}
```

### Semantic Colors

```css
:root {
  /* Success */
  --color-success-50: #f0fdf4;
  --color-success-500: #22c55e;
  --color-success-600: #16a34a;
  
  /* Warning */
  --color-warning-50: #fefce8;
  --color-warning-500: #eab308;
  --color-warning-600: #ca8a04;
  
  /* Error */
  --color-error-50: #fef2f2;
  --color-error-500: #ef4444;
  --color-error-600: #dc2626;
  
  /* Info */
  --color-info-50: #eff6ff;
  --color-info-500: #3b82f6;
  --color-info-600: #2563eb;
}
```

### Neutral System

```css
:root {
  /* Neutral Grays */
  --color-neutral-0: #ffffff;
  --color-neutral-50: #fafafa;
  --color-neutral-100: #f5f5f5;
  --color-neutral-200: #e5e5e5;
  --color-neutral-300: #d4d4d4;
  --color-neutral-400: #a3a3a3;
  --color-neutral-500: #737373;
  --color-neutral-600: #525252;
  --color-neutral-700: #404040;
  --color-neutral-800: #262626;
  --color-neutral-900: #171717;
  --color-neutral-950: #0a0a0a;
}
```

### Dark Mode Colors

```css
[data-theme="dark"] {
  /* Dark mode overrides */
  --color-background: var(--color-neutral-900);
  --color-surface: var(--color-neutral-800);
  --color-surface-variant: var(--color-neutral-700);
  --color-text-primary: var(--color-neutral-50);
  --color-text-secondary: var(--color-neutral-300);
  --color-text-disabled: var(--color-neutral-500);
}
```

## Spacing and Layout Grids

### Spacing Scale

```css
:root {
  /* Spacing Scale (8px base) */
  --spacing-0: 0;
  --spacing-px: 1px;
  --spacing-0_5: 0.125rem; /* 2px */
  --spacing-1: 0.25rem;    /* 4px */
  --spacing-1_5: 0.375rem; /* 6px */
  --spacing-2: 0.5rem;     /* 8px */
  --spacing-2_5: 0.625rem; /* 10px */
  --spacing-3: 0.75rem;    /* 12px */
  --spacing-3_5: 0.875rem; /* 14px */
  --spacing-4: 1rem;       /* 16px */
  --spacing-5: 1.25rem;    /* 20px */
  --spacing-6: 1.5rem;     /* 24px */
  --spacing-7: 1.75rem;    /* 28px */
  --spacing-8: 2rem;       /* 32px */
  --spacing-9: 2.25rem;    /* 36px */
  --spacing-10: 2.5rem;    /* 40px */
  --spacing-11: 2.75rem;   /* 44px */
  --spacing-12: 3rem;      /* 48px */
  --spacing-14: 3.5rem;    /* 56px */
  --spacing-16: 4rem;      /* 64px */
  --spacing-20: 5rem;      /* 80px */
  --spacing-24: 6rem;      /* 96px */
  --spacing-28: 7rem;      /* 112px */
  --spacing-32: 8rem;      /* 128px */
  --spacing-36: 9rem;      /* 144px */
  --spacing-40: 10rem;     /* 160px */
  --spacing-44: 11rem;     /* 176px */
  --spacing-48: 12rem;     /* 192px */
  --spacing-52: 13rem;     /* 208px */
  --spacing-56: 14rem;     /* 224px */
  --spacing-60: 15rem;     /* 240px */
  --spacing-64: 16rem;     /* 256px */
  --spacing-72: 18rem;     /* 288px */
  --spacing-80: 20rem;     /* 320px */
  --spacing-96: 24rem;     /* 384px */
}
```

### Layout Grid System

```css
/* Container Sizes */
.container-sm { max-width: 640px; }
.container-md { max-width: 768px; }
.container-lg { max-width: 1024px; }
.container-xl { max-width: 1280px; }
.container-2xl { max-width: 1536px; }

/* Grid System */
.grid-12 {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: var(--spacing-6);
}

.grid-auto {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: var(--spacing-6);
}

/* Responsive Breakpoints */
:root {
  --breakpoint-sm: 640px;
  --breakpoint-md: 768px;
  --breakpoint-lg: 1024px;
  --breakpoint-xl: 1280px;
  --breakpoint-2xl: 1536px;
}
```

## Component Library

### Button Components

#### Primary Button
```tsx
interface ButtonProps {
  variant: 'primary' | 'secondary' | 'outline' | 'ghost';
  size: 'sm' | 'md' | 'lg' | 'xl';
  disabled?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

// Usage Examples:
<Button variant="primary" size="lg">Shop Plants</Button>
<Button variant="outline" size="md" icon={<CartIcon />}>Add to Cart</Button>
```

#### Button Styles
```css
/* Base Button */
.btn {
  @apply inline-flex items-center justify-center rounded-lg font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2;
}

/* Primary Button */
.btn-primary {
  @apply bg-primary-500 text-white hover:bg-primary-600 focus:ring-primary-500;
}

/* Secondary Button */
.btn-secondary {
  @apply bg-secondary-500 text-white hover:bg-secondary-600 focus:ring-secondary-500;
}

/* Outline Button */
.btn-outline {
  @apply border-2 border-primary-500 text-primary-600 hover:bg-primary-50 focus:ring-primary-500;
}

/* Ghost Button */
.btn-ghost {
  @apply text-primary-600 hover:bg-primary-50 focus:ring-primary-500;
}

/* Button Sizes */
.btn-sm {
  @apply px-3 py-1.5 text-sm;
}

.btn-md {
  @apply px-4 py-2 text-base;
}

.btn-lg {
  @apply px-6 py-3 text-lg;
}

.btn-xl {
  @apply px-8 py-4 text-xl;
}
```

### Card Components

#### Product Card
```tsx
interface ProductCardProps {
  product: {
    id: string;
    name: string;
    price: number;
    image: string;
    rating: number;
    inStock: boolean;
  };
  variant?: 'default' | 'featured' | 'compact';
}
```

#### Card Styles
```css
.card {
  @apply bg-white rounded-2xl shadow-sm border border-neutral-200 overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1;
}

.card-featured {
  @apply bg-gradient-to-br from-primary-50 to-accent-warm-50 border-primary-200;
}

.card-compact {
  @apply rounded-lg shadow-xs;
}
```

### Form Components

#### Input Field
```tsx
interface InputProps {
  label: string;
  type: 'text' | 'email' | 'password' | 'tel' | 'url';
  placeholder?: string;
  error?: string;
  icon?: React.ReactNode;
  required?: boolean;
}
```

#### Form Styles
```css
.form-group {
  @apply space-y-2;
}

.form-label {
  @apply block text-sm font-medium text-neutral-700;
}

.form-input {
  @apply block w-full px-3 py-2 border border-neutral-300 rounded-lg shadow-sm placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500;
}

.form-input-error {
  @apply border-error-500 focus:ring-error-500 focus:border-error-500;
}

.form-error {
  @apply text-sm text-error-600;
}
```

### Navigation Components

#### Header Navigation
```tsx
interface NavigationProps {
  items: NavigationItem[];
  logo: React.ReactNode;
  actions?: React.ReactNode;
}

interface NavigationItem {
  label: string;
  href: string;
  submenu?: NavigationItem[];
}
```

#### Navigation Styles
```css
.nav-header {
  @apply bg-white/95 backdrop-blur-md border-b border-neutral-200 sticky top-0 z-50;
}

.nav-link {
  @apply text-neutral-700 hover:text-primary-600 transition-colors duration-200 font-medium;
}

.nav-link-active {
  @apply text-primary-600;
}
```

## Interaction Patterns and Animations

### Micro-interactions

#### Hover Effects
```css
/* Button Hover */
.btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

/* Card Hover */
.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
}

/* Icon Hover */
.icon-hover:hover {
  transform: scale(1.1);
  color: var(--color-primary-500);
}
```

#### Loading States
```css
.loading-spinner {
  @apply animate-spin rounded-full h-4 w-4 border-b-2 border-primary-500;
}

.loading-skeleton {
  @apply animate-pulse bg-neutral-200 rounded;
}
```

### Page Transitions
```css
.page-enter {
  opacity: 0;
  transform: translateY(20px);
}

.page-enter-active {
  opacity: 1;
  transform: translateY(0);
  transition: opacity 300ms, transform 300ms;
}

.page-exit {
  opacity: 1;
  transform: translateY(0);
}

.page-exit-active {
  opacity: 0;
  transform: translateY(-20px);
  transition: opacity 300ms, transform 300ms;
}
```

### Parallax Animation Specifications

#### Homepage Hero Parallax
```css
.parallax-hero {
  height: 100vh;
  overflow: hidden;
  position: relative;
}

.parallax-bg {
  transform: translateZ(-1px) scale(1.5);
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

.parallax-content {
  transform: translateZ(0);
  position: relative;
  z-index: 1;
}
```

#### Scroll-triggered Animations
```javascript
// Intersection Observer for scroll animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -10% 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('animate-in');
    }
  });
}, observerOptions);
```

## UX Guidelines and User Flows

### Navigation Principles
1. **Clear Hierarchy:** Primary → Secondary → Tertiary navigation levels
2. **Consistent Patterns:** Same interaction patterns across all pages
3. **Breadcrumbs:** Always show user's current location
4. **Search Integration:** Prominent search with predictive results

### Shopping Flow
```
Home → Category → Product → Cart → Checkout → Confirmation
```

#### Key UX Considerations
- **Guest Checkout:** Allow purchases without account creation
- **Progress Indicators:** Show checkout steps clearly
- **Error Recovery:** Helpful error messages with solutions
- **Mobile Optimization:** Touch-friendly interactions

### Product Discovery Flow
```
Search/Browse → Filter → Compare → Details → Reviews → Purchase Decision
```

#### Enhancement Features
- **Quick View:** Modal for rapid product overview
- **Wishlist Integration:** Save for later functionality
- **Related Products:** AI-powered recommendations
- **Social Proof:** Reviews, ratings, user photos

## Accessibility Standards

### WCAG 2.1 AA Compliance

#### Color Contrast
- **Normal text:** 4.5:1 minimum contrast ratio
- **Large text:** 3:1 minimum contrast ratio
- **UI components:** 3:1 minimum contrast ratio

#### Keyboard Navigation
```css
/* Focus indicators */
.focus-visible {
  @apply outline-none ring-2 ring-primary-500 ring-offset-2;
}

/* Skip links */
.skip-link {
  @apply sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-primary-500 text-white px-4 py-2 rounded;
}
```

#### Screen Reader Support
```tsx
// Semantic HTML examples
<nav aria-label="Main navigation">
<main aria-label="Product catalog">
<section aria-labelledby="featured-products">

// ARIA labels
<button aria-label="Add to cart" aria-describedby="price-info">
<img alt="Monstera deliciosa in ceramic pot" />
```

#### Form Accessibility
```tsx
// Proper labeling
<label htmlFor="email">Email Address</label>
<input 
  id="email" 
  type="email" 
  aria-describedby="email-error"
  aria-invalid={hasError}
/>
<span id="email-error" role="alert">{errorMessage}</span>
```

### Mobile Accessibility
- **Touch targets:** Minimum 44px x 44px
- **Gesture alternatives:** Provide non-gesture alternatives
- **Screen orientation:** Support both portrait and landscape
- **Zoom support:** Up to 200% without horizontal scrolling

## Code Implementation Examples

### React Component Structure
```tsx
// Component with design system integration
interface PlantCardProps {
  plant: Plant;
  variant?: 'default' | 'featured';
  size?: 'sm' | 'md' | 'lg';
}

export const PlantCard: React.FC<PlantCardProps> = ({
  plant,
  variant = 'default',
  size = 'md'
}) => {
  const cardClasses = cn(
    'card',
    {
      'card-featured': variant === 'featured',
      'p-4': size === 'sm',
      'p-6': size === 'md',
      'p-8': size === 'lg',
    }
  );

  return (
    <article className={cardClasses}>
      <img 
        src={plant.image} 
        alt={plant.name}
        className="w-full h-48 object-cover rounded-lg"
      />
      <div className="mt-4">
        <h3 className="text-h5">{plant.name}</h3>
        <p className="text-body-sm text-neutral-600 mt-1">
          {plant.scientificName}
        </p>
        <div className="flex items-center justify-between mt-4">
          <span className="text-h6 text-primary-600">
            ${plant.price}
          </span>
          <Button variant="outline" size="sm">
            Add to Cart
          </Button>
        </div>
      </div>
    </article>
  );
};
```

### Tailwind Configuration
```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0fdf4',
          500: '#22c55e',
          600: '#16a34a',
          // ... full palette
        },
        secondary: {
          // ... earth tone palette
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
      },
      spacing: {
        // Custom spacing scale
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
        'slide-up': 'slideUp 0.3s ease-out',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0px)', opacity: '1' },
        }
      }
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
};
```

## Responsive Behavior Specifications

### Breakpoint Strategy
- **Mobile First:** Design for mobile, enhance for larger screens
- **Fluid Design:** Use relative units and flexible layouts
- **Content Priority:** Most important content first on small screens

### Device-Specific Considerations

#### Mobile (320px - 768px)
- Single column layouts
- Collapsible navigation
- Touch-optimized interactions
- Simplified parallax effects

#### Tablet (768px - 1024px)
- Two-column layouts where appropriate
- Hybrid navigation (drawer + horizontal)
- Enhanced parallax effects
- Grid-based product layouts

#### Desktop (1024px+)
- Multi-column layouts
- Full horizontal navigation
- Complex parallax effects
- Hover states and animations

### Performance Considerations
- **Image Optimization:** Responsive images with srcset
- **Code Splitting:** Route-based code splitting
- **Lazy Loading:** Content below the fold
- **Critical CSS:** Inline critical styles

---

*This design system serves as the comprehensive guide for creating consistent, accessible, and beautiful user experiences for the Grow plant store e-commerce website.*