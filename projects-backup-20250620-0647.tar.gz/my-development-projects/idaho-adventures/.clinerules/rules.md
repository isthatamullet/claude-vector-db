# Idaho Adventures - Cline Development Rules

## Project Overview
This project is a premium outdoor adventure website for Idaho Adventures, featuring jet boat tours, helicopter tours, and glamping. Follow these rules to ensure consistent, high-quality development.

## Technology Stack Rules

### Core Framework
- Use React 18+ with Vite as the build tool
- Use functional components with hooks exclusively
- Implement React Router for client-side routing
- Use TypeScript for type safety when beneficial

### Styling Standards
- Use Tailwind CSS for all styling
- Implement Framer Motion for animations and parallax effects
- Follow mobile-first responsive design principles
- Use custom CSS only when Tailwind utilities are insufficient

### Required Dependencies
Install these essential packages:
```bash
npm install react-router-dom framer-motion react-intersection-observer lucide-react react-hook-form date-fns
npm install -D tailwindcss postcss autoprefixer @types/node
```

## File Structure Rules

### Directory Organization
```
src/
├── components/
│   ├── common/          # Reusable UI components
│   ├── navigation/      # Header, Footer, Menu components
│   ├── sections/        # Page-specific sections
│   ├── forms/          # Form components and validation
│   └── animations/     # Animation wrapper components
├── pages/              # Route components (Home, River, etc.)
├── hooks/              # Custom React hooks
├── utils/              # Helper functions and constants
├── data/               # Static data and content
└── styles/             # Global styles and Tailwind config
```

### Component Naming
- Use PascalCase for component files: `HeroSection.jsx`
- Use camelCase for utility files: `formatDate.js`
- Use kebab-case for page routes: `/river`, `/copter`, `/glamp`

## Development Standards

### Component Architecture
- Keep components under 200 lines when possible
- Extract reusable logic into custom hooks
- Use composition over inheritance
- Implement proper prop validation

### Performance Rules
- Lazy load all page components using `React.lazy()`
- Optimize images with proper sizing and formats
- Use `React.memo()` for expensive re-renders
- Implement proper loading states

### Responsive Design
- Design mobile-first, then enhance for larger screens
- Use Tailwind's responsive prefixes: `sm:`, `md:`, `lg:`, `xl:`
- Test on these breakpoints: 320px, 768px, 1024px, 1440px
- Ensure touch-friendly interfaces (44px minimum touch targets)

## Content and Design Rules

### Visual Design Standards
- Color palette: emerald greens, sky blues, sunset oranges, slate grays
- Use high-impact hero imagery with proper fallbacks
- Implement consistent spacing using Tailwind's spacing scale
- Maintain 4.5:1 color contrast ratio for accessibility

### Typography Scale
- Headings: Use `text-4xl` to `text-6xl` for heroes, `text-xl` to `text-3xl` for sections
- Body text: Use `text-base` or `text-lg` for readability
- Mobile: Reduce heading sizes by one step (e.g., `text-4xl` becomes `text-3xl`)

### Animation Guidelines
- Use Framer Motion for all animations
- Keep animations under 500ms for UI feedback
- Use easing curves: `ease-out` for entrances, `ease-in` for exits
- Implement `prefers-reduced-motion` for accessibility

## Page Implementation Rules

### Home Page Requirements
1. Full-screen hero with parallax background video/image
2. Three adventure highlight cards with hover animations
3. Testimonials carousel with auto-play
4. Sticky booking CTA button
5. Instagram feed integration placeholder

### Service Pages (River, Copter, Glamp)
1. Each page needs hero section, content sections, booking widget
2. Implement image galleries with lightbox functionality
3. Add FAQ sections with expandable items
4. Include pricing tables with clear CTAs

### About Page Requirements
1. Company timeline with scroll-triggered animations
2. Team member cards with hover effects
3. Certification badges and awards section

### Booking Page Requirements
1. Multi-step form with progress indicator
2. Date picker with availability checking
3. Form validation with clear error messages
4. Mobile-optimized form layouts

## Code Quality Rules

### React Best Practices
- Use functional components exclusively
- Implement proper error boundaries
- Handle loading and error states consistently
- Use meaningful variable and function names

### State Management
- Use `useState` for local component state
- Use `useContext` for shared state when needed
- Avoid prop drilling beyond 2-3 levels
- Keep state as close to where it's used as possible

### API Integration
- Create custom hooks for API calls
- Implement proper error handling
- Use loading states for all async operations
- Cache frequently accessed data

## Testing and Quality Assurance

### Browser Testing
- Test on Chrome, Firefox, Safari, Edge
- Prioritize mobile Safari and Chrome
- Ensure functionality without JavaScript (progressive enhancement)

### Performance Benchmarks
- PageSpeed Insights score >90
- First Contentful Paint <2 seconds
- Cumulative Layout Shift <0.1
- Largest Contentful Paint <3 seconds

### Accessibility Requirements
- Use semantic HTML elements
- Implement proper ARIA labels
- Ensure keyboard navigation
- Test with screen readers
- Maintain focus management

## Content Guidelines

### Image Requirements
- Use WebP format with JPEG fallbacks
- Implement responsive images with `srcset`
- Include descriptive alt text for all images
- Optimize for Core Web Vitals

### Copy Standards
- Write in active voice
- Keep paragraphs under 3 sentences
- Use bullet points for scannable content
- Include clear calls-to-action

## Implementation Priority Order

### Phase 1: Foundation (Days 1-2)
1. Set up Vite + React project with proper folder structure
2. Install and configure all dependencies
3. Create base layout components (Header, Footer, Layout)
4. Implement routing structure
5. Set up Tailwind CSS configuration

### Phase 2: Core Pages (Days 3-6)
1. Build Home page with hero and adventure highlights
2. Create River tours page with gallery
3. Develop Helicopter tours page with interactive elements
4. Build Glamping page with accommodation details

### Phase 3: Supporting Pages (Days 7-8)
1. Complete About page with team profiles
2. Build comprehensive Booking page
3. Add contact and legal pages

### Phase 4: Polish and Optimization (Days 9-10)
1. Implement all animations and micro-interactions
2. Optimize performance and loading times
3. Conduct cross-browser testing
4. Finalize responsive design details

## Error Handling Rules

### User Experience
- Always provide feedback for user actions
- Use toast notifications for success/error messages
- Implement graceful fallbacks for failed API calls
- Show helpful error messages, not technical jargon

### Development
- Use try-catch blocks for async operations
- Log errors appropriately for debugging
- Implement error boundaries for component crashes
- Validate all user inputs

## Final Notes

- Follow these rules consistently throughout development
- Update rules if project requirements change
- Document any deviations with clear reasoning
- Prioritize user experience over perfect code
- Test on actual devices, not just browser dev tools

When in doubt, refer back to the full PRD for detailed requirements and specifications.