import React, { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

// Layout components
import Header from './components/navigation/Header';
import Footer from './components/navigation/Footer';
import LoadingSpinner from './components/common/LoadingSpinner';

// Lazy load pages for better performance
const Home = React.lazy(() => import('./pages/Home'));
const RiverTours = React.lazy(() => import('./pages/RiverTours'));
const HelicopterTours = React.lazy(() => import('./pages/HelicopterTours'));
const Glamping = React.lazy(() => import('./pages/Glamping'));
const About = React.lazy(() => import('./pages/About'));
const Booking = React.lazy(() => import('./pages/Booking'));

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-slate-50">
        <Header />
        
        <main className="relative">
          <Suspense fallback={<LoadingSpinner />}>
            <AnimatePresence mode="wait">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/river" element={<RiverTours />} />
                <Route path="/copter" element={<HelicopterTours />} />
                <Route path="/glamp" element={<Glamping />} />
                <Route path="/about" element={<About />} />
                <Route path="/book" element={<Booking />} />
              </Routes>
            </AnimatePresence>
          </Suspense>
        </main>
        
        <Footer />
      </div>
    </Router>
  );
}

export default App;
