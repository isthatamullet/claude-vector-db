import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mountain, Phone, Mail, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { path: '/', label: 'Home' },
    { path: '/river', label: 'River Tours' },
    { path: '/copter', label: 'Helicopter Tours' },
    { path: '/glamp', label: 'Glamping' },
    { path: '/about', label: 'About Us' },
    { path: '/book', label: 'Book Now' },
  ];

  const contactInfo = [
    { icon: Phone, text: '(208) 555-0123', href: 'tel:+12085550123' },
    { icon: Mail, text: 'info@idahoadventures.com', href: 'mailto:info@idahoadventures.com' },
    { icon: MapPin, text: 'Boise, Idaho', href: '#' },
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Twitter, href: '#', label: 'Twitter' },
  ];

  return (
    <footer className="bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <div className="flex items-center justify-center w-10 h-10 bg-emerald-600 rounded-lg">
                <Mountain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">Idaho Adventures</span>
            </Link>
            <p className="text-slate-300 mb-6 max-w-md">
              Experience the thrill of Idaho's wilderness with our premium outdoor adventures. 
              From jet boat tours on the Snake River to helicopter flights over stunning landscapes, 
              we create unforgettable memories in nature's playground.
            </p>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  className="flex items-center justify-center w-10 h-10 bg-slate-800 rounded-lg hover:bg-emerald-600 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-slate-300 hover:text-emerald-400 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              {contactInfo.map((contact, index) => (
                <li key={index}>
                  <a
                    href={contact.href}
                    className="flex items-center space-x-3 text-slate-300 hover:text-emerald-400 transition-colors"
                  >
                    <contact.icon className="w-5 h-5 flex-shrink-0" />
                    <span>{contact.text}</span>
                  </a>
                </li>
              ))}
            </ul>

            {/* Operating Hours */}
            <div className="mt-6">
              <h4 className="font-semibold mb-2">Operating Hours</h4>
              <div className="text-slate-300 text-sm space-y-1">
                <p>Mon - Fri: 8:00 AM - 6:00 PM</p>
                <p>Sat - Sun: 7:00 AM - 7:00 PM</p>
                <p className="text-emerald-400">Seasonal hours may vary</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-slate-400 text-sm">
              © {currentYear} Idaho Adventures. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm">
              <Link to="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                Privacy Policy
              </Link>
              <Link to="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                Terms of Service
              </Link>
              <Link to="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                Safety Guidelines
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
