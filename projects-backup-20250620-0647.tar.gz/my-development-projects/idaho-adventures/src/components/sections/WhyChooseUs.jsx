import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Shield, Award, Users, Clock, Heart, Star } from 'lucide-react';

const WhyChooseUs = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const features = [
    {
      icon: Shield,
      title: 'Safety First',
      description: 'We prioritize your well-being with certified guides, comprehensive training, and top-tier safety equipment.',
      color: 'emerald'
    },
    {
      icon: Award,
      title: 'Award Winning',
      description: 'Recognized as Idaho\'s premier adventure company with multiple tourism and safety awards.',
      color: 'sky'
    },
    {
      icon: Users,
      title: 'Expert Guides',
      description: 'Our experienced local guides know every hidden gem and will share Idaho\'s rich history and wildlife.',
      color: 'orange'
    },
    {
      icon: Clock,
      title: '15+ Years Experience',
      description: 'Over a decade of creating unforgettable adventures with thousands of satisfied customers.',
      color: 'emerald'
    },
    {
      icon: Heart,
      title: 'Personalized Service',
      description: 'Every adventure is tailored to your group\'s interests and skill level for the perfect experience.',
      color: 'sky'
    },
    {
      icon: Star,
      title: 'Premium Quality',
      description: 'We use only the best equipment and maintain the highest standards in everything we do.',
      color: 'orange'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { 
      opacity: 0, 
      y: 30,
      scale: 0.9
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const getColorClasses = (color) => {
    const colorMap = {
      emerald: 'bg-emerald-100 text-emerald-600',
      sky: 'bg-sky-100 text-sky-600',
      orange: 'bg-orange-100 text-orange-600'
    };
    return colorMap[color] || colorMap.emerald;
  };

  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          ref={ref}
        >
          <h2 className="section-heading">Why Choose Idaho Adventures?</h2>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            With over 15 years of experience and thousands of happy adventurers, 
            we're Idaho's most trusted outdoor adventure company.
          </p>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="group"
              variants={itemVariants}
            >
              <div className="bg-white rounded-xl p-8 shadow-sm hover:shadow-lg transition-all duration-300 h-full">
                {/* Icon */}
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-xl mb-6 ${getColorClasses(feature.color)}`}>
                  <feature.icon className="w-8 h-8" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-slate-800 mb-4">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Stats Section */}
        <motion.div
          className="mt-20 bg-white rounded-2xl p-8 md:p-12 shadow-lg"
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-slate-800 mb-4">
              Trusted by Thousands
            </h3>
            <p className="text-lg text-slate-600">
              Our numbers speak for themselves
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <motion.div
                className="text-3xl md:text-4xl font-bold text-emerald-600 mb-2"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                10,000+
              </motion.div>
              <div className="text-slate-600 font-medium">Happy Customers</div>
            </div>

            <div className="text-center">
              <motion.div
                className="text-3xl md:text-4xl font-bold text-sky-600 mb-2"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: 0.7 }}
              >
                15+
              </motion.div>
              <div className="text-slate-600 font-medium">Years Experience</div>
            </div>

            <div className="text-center">
              <motion.div
                className="text-3xl md:text-4xl font-bold text-orange-600 mb-2"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: 0.8 }}
              >
                100%
              </motion.div>
              <div className="text-slate-600 font-medium">Satisfaction</div>
            </div>

            <div className="text-center">
              <motion.div
                className="text-3xl md:text-4xl font-bold text-emerald-600 mb-2"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: 0.9 }}
              >
                4.9★
              </motion.div>
              <div className="text-slate-600 font-medium">Average Rating</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
