import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Link } from 'react-router-dom';
import { Waves, Plane, Tent, ArrowRight } from 'lucide-react';

const AdventureHighlights = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const adventures = [
    {
      id: 'river',
      title: 'Snake River Tours',
      description: 'Experience the thrill of jet boat tours through Hell\'s Canyon, North America\'s deepest river gorge.',
      image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      icon: Waves,
      link: '/river',
      features: ['Hell\'s Canyon Tours', 'Wildlife Viewing', 'Rapids Adventure'],
      duration: '4-8 hours',
      price: 'From $149'
    },
    {
      id: 'helicopter',
      title: 'Helicopter Tours',
      description: 'Soar above Idaho\'s majestic landscapes and witness breathtaking views from a bird\'s eye perspective.',
      image: 'https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      icon: Plane,
      link: '/copter',
      features: ['Scenic Flights', 'Mountain Views', 'Photo Opportunities'],
      duration: '30-90 minutes',
      price: 'From $299'
    },
    {
      id: 'glamping',
      title: 'Luxury Glamping',
      description: 'Enjoy the great outdoors in comfort with our premium glamping experiences in pristine wilderness.',
      image: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      icon: Tent,
      link: '/glamp',
      features: ['Luxury Tents', 'Gourmet Meals', 'Stargazing'],
      duration: '1-7 nights',
      price: 'From $199/night'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.9
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          ref={ref}
        >
          <h2 className="section-heading">Choose Your Adventure</h2>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            From heart-pounding river rapids to serene mountain vistas, Idaho Adventures 
            offers unforgettable experiences for every type of adventurer.
          </p>
        </motion.div>

        {/* Adventure Cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {adventures.map((adventure, index) => (
            <motion.div
              key={adventure.id}
              className="group"
              variants={cardVariants}
            >
              <div className="card h-full">
                {/* Image */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={adventure.image}
                    alt={adventure.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  
                  {/* Icon */}
                  <div className="absolute top-4 left-4">
                    <div className="flex items-center justify-center w-12 h-12 bg-emerald-600 rounded-lg">
                      <adventure.icon className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  {/* Price Badge */}
                  <div className="absolute top-4 right-4">
                    <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                      <span className="text-sm font-semibold text-slate-800">{adventure.price}</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-slate-800 mb-2">{adventure.title}</h3>
                  <p className="text-slate-600 mb-4 line-clamp-3">{adventure.description}</p>

                  {/* Features */}
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-2">
                      {adventure.features.map((feature, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-1 bg-emerald-50 text-emerald-700 text-xs rounded-full"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Duration */}
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-sm text-slate-500">Duration: {adventure.duration}</span>
                  </div>

                  {/* CTA Button */}
                  <Link
                    to={adventure.link}
                    className="flex items-center justify-center w-full py-3 px-4 bg-slate-100 hover:bg-emerald-600 text-slate-700 hover:text-white rounded-lg transition-all duration-300 group/btn"
                  >
                    <span className="font-medium">Learn More</span>
                    <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover/btn:translate-x-1" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <p className="text-lg text-slate-600 mb-6">
            Can't decide? Let us help you plan the perfect Idaho adventure.
          </p>
          <Link
            to="/book"
            className="btn-primary text-lg px-8 py-4"
          >
            Plan My Adventure
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default AdventureHighlights;
