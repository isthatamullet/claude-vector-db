import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronDown, Clock, Users, Star, MapPin, Camera, Shield, Calendar, Tent, Wifi, Coffee, Bath } from 'lucide-react';

const Glamping = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [expandedFaq, setExpandedFaq] = useState(null);

  const accommodations = [
    {
      name: "Luxury Safari Tent",
      sleeps: "2 guests",
      price: "$299",
      size: "400 sq ft",
      highlights: ["King-size bed", "Private bathroom", "Heated floors", "Mountain views"],
      description: "Spacious canvas tent with luxury amenities and stunning mountain vistas."
    },
    {
      name: "Family Cabin",
      sleeps: "4-6 guests",
      price: "$449",
      size: "600 sq ft",
      highlights: ["Two bedrooms", "Full kitchen", "Living area", "Private deck"],
      description: "Perfect for families with separate bedrooms and full kitchen facilities."
    },
    {
      name: "Romantic Treehouse",
      sleeps: "2 guests",
      price: "$399",
      size: "350 sq ft",
      highlights: ["Elevated design", "Hot tub", "Fireplace", "Stargazing deck"],
      description: "Unique elevated accommodation with private hot tub and romantic ambiance."
    }
  ];

  const amenities = [
    {
      icon: Tent,
      title: "Luxury Accommodations",
      description: "Premium tents and cabins with hotel-quality amenities in a natural setting."
    },
    {
      icon: Wifi,
      title: "Modern Conveniences",
      description: "High-speed WiFi, electricity, and climate control for your comfort."
    },
    {
      icon: Coffee,
      title: "Gourmet Dining",
      description: "On-site restaurant and room service featuring local Idaho ingredients."
    },
    {
      icon: Bath,
      title: "Spa Services",
      description: "Relaxing spa treatments and wellness activities in nature."
    }
  ];

  const activities = [
    {
      title: "Guided Nature Walks",
      description: "Explore local flora and fauna with our expert naturalist guides.",
      image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Stargazing Sessions",
      description: "Professional telescope viewing under Idaho's pristine dark skies.",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Outdoor Yoga",
      description: "Morning yoga sessions with mountain views and fresh air.",
      image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Campfire Experiences",
      description: "Evening gatherings with s'mores and storytelling around the fire.",
      image: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    }
  ];

  const faqs = [
    {
      question: "What's included in the glamping experience?",
      answer: "All accommodations include luxury bedding, private bathrooms, climate control, WiFi, and access to common areas. Meals can be added or you can use kitchen facilities where available."
    },
    {
      question: "Is glamping suitable for children?",
      answer: "Absolutely! We welcome families and have accommodations specifically designed for families with children. We also offer kid-friendly activities and amenities."
    },
    {
      question: "What should I bring?",
      answer: "We provide all bedding, towels, and basic amenities. Bring comfortable outdoor clothing, personal items, and any specific gear for activities you plan to enjoy."
    },
    {
      question: "Are pets allowed?",
      answer: "We welcome well-behaved pets in select accommodations for an additional fee. Please inform us when booking and review our pet policy."
    },
    {
      question: "What's the cancellation policy?",
      answer: "Cancellations made 7+ days in advance receive full refund. 3-6 days: 50% refund. Less than 3 days: no refund unless due to weather or emergency."
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/80 to-amber-900/80 z-10"></div>
        <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
             style={{backgroundImage: "url('https://images.unsplash.com/photo-1504851149312-7a075b496cc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')"}}></div>
        
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <motion.h1 
            className="text-5xl md:text-7xl font-bold mb-6"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Luxury Glamping
          </motion.h1>
          <motion.p 
            className="text-xl md:text-2xl mb-8 text-green-100"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Experience the great outdoors with all the comforts of a luxury resort
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <Link
              to="/book"
              className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Book Your Stay
            </Link>
            <button 
              onClick={() => setActiveTab('accommodations')}
              className="border-2 border-white text-white hover:bg-white hover:text-slate-800 px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              View Accommodations
            </button>
          </motion.div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
          <ChevronDown size={32} />
        </div>
      </section>

      {/* Navigation Tabs */}
      <section className="bg-white shadow-lg sticky top-20 z-30">
        <div className="max-w-6xl mx-auto px-4">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'accommodations', label: 'Accommodations' },
              { id: 'activities', label: 'Activities' },
              { id: 'faq', label: 'FAQ' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-amber-500 text-amber-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </section>

      {/* Overview Section */}
      {activeTab === 'overview' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-4xl font-bold text-slate-800 mb-6">Luxury Meets Nature</h2>
                <p className="text-lg text-slate-600 mb-6">
                  Escape to our premium glamping resort where luxury accommodations blend seamlessly 
                  with Idaho's pristine wilderness. Experience the beauty of camping without sacrificing 
                  comfort, featuring heated tents, private bathrooms, and gourmet dining.
                </p>
                <p className="text-lg text-slate-600 mb-8">
                  Located in a secluded valley surrounded by towering pines and mountain peaks, our 
                  eco-luxury resort offers the perfect base for outdoor adventures while providing 
                  all the amenities of a five-star hotel.
                </p>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="flex items-center space-x-3">
                    <Tent className="text-amber-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Accommodations</p>
                      <p className="text-slate-600">Luxury tents & cabins</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Users className="text-amber-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Capacity</p>
                      <p className="text-slate-600">2-6 guests per unit</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Star className="text-amber-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Rating</p>
                      <p className="text-slate-600">5-star luxury</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="text-amber-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Location</p>
                      <p className="text-slate-600">Private valley</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1504851149312-7a075b496cc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                  alt="Luxury glamping tent"
                  className="rounded-lg shadow-xl"
                />
                <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-lg shadow-lg">
                  <div className="flex items-center space-x-2 text-amber-600">
                    <Shield size={24} />
                    <span className="font-semibold">Eco-Certified</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Amenities Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {amenities.map((amenity, index) => (
                <motion.div 
                  key={amenity.title}
                  className="text-center"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <amenity.icon className="text-amber-600" size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">{amenity.title}</h3>
                  <p className="text-slate-600">{amenity.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* Accommodations Section */}
      {activeTab === 'accommodations' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Choose Your Accommodation</h2>
              <p className="text-xl text-slate-600">From romantic retreats to family-friendly cabins</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {accommodations.map((accommodation, index) => (
                <motion.div 
                  key={accommodation.name}
                  className="bg-slate-50 rounded-xl overflow-hidden hover:shadow-lg transition-shadow"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="h-48 bg-gradient-to-br from-amber-400 to-amber-600"></div>
                  
                  <div className="p-8">
                    <div className="text-center mb-6">
                      <h3 className="text-2xl font-bold text-slate-800 mb-2">{accommodation.name}</h3>
                      <div className="text-3xl font-bold text-amber-600 mb-2">{accommodation.price}</div>
                      <p className="text-slate-600">per night</p>
                    </div>
                    
                    <div className="space-y-4 mb-6">
                      <div className="flex items-center space-x-3">
                        <Users className="text-amber-600" size={20} />
                        <span className="text-slate-700">{accommodation.sleeps}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <MapPin className="text-amber-600" size={20} />
                        <span className="text-slate-700">{accommodation.size}</span>
                      </div>
                    </div>
                    
                    <p className="text-slate-600 mb-6">{accommodation.description}</p>
                    
                    <ul className="space-y-2 mb-8">
                      {accommodation.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-amber-600 rounded-full"></div>
                          <span className="text-slate-700">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Link
                      to="/book"
                      className="block w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-semibold transition-colors text-center"
                    >
                      Book This Stay
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Special Packages */}
            <div className="mt-16 bg-gradient-to-r from-green-600 to-amber-600 rounded-xl p-8 text-white text-center">
              <h3 className="text-2xl font-bold mb-4">Romantic Getaway Package</h3>
              <p className="text-lg mb-6">
                Includes champagne welcome, couples massage, private dinner under the stars, 
                and late checkout. Perfect for anniversaries, honeymoons, or proposals.
              </p>
              <Link
                to="/book"
                className="bg-white text-green-600 hover:bg-slate-100 px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Learn More
              </Link>
            </div>
          </div>
        </motion.section>
      )}

      {/* Activities Section */}
      {activeTab === 'activities' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Activities & Experiences</h2>
              <p className="text-xl text-slate-600">Immerse yourself in nature with guided activities</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {activities.map((activity, index) => (
                <motion.div 
                  key={activity.title}
                  className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={activity.image} 
                      alt={activity.title}
                      className="w-full h-full object-cover transition-transform hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/20"></div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-slate-800 mb-3">{activity.title}</h3>
                    <p className="text-slate-600 mb-4">{activity.description}</p>
                    <button className="text-amber-600 hover:text-amber-700 font-semibold transition-colors">
                      Learn More →
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Additional Activities */}
            <div className="mt-12 grid md:grid-cols-3 gap-6 text-center">
              <div className="bg-white p-6 rounded-lg shadow">
                <h4 className="font-bold text-slate-800 mb-2">Adventure Packages</h4>
                <p className="text-slate-600">Combine glamping with river tours or helicopter flights</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <h4 className="font-bold text-slate-800 mb-2">Wellness Retreats</h4>
                <p className="text-slate-600">Yoga, meditation, and spa treatments in nature</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <h4 className="font-bold text-slate-800 mb-2">Family Fun</h4>
                <p className="text-slate-600">Kid-friendly activities and educational programs</p>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* FAQ Section */}
      {activeTab === 'faq' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-slate-600">Everything you need to know about glamping with us</p>
            </div>
            
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <motion.div 
                  key={index}
                  className="border border-slate-200 rounded-lg"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <button
                    onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                    className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-slate-800">{faq.question}</span>
                    <ChevronDown 
                      className={`text-slate-500 transition-transform ${
                        expandedFaq === index ? 'rotate-180' : ''
                      }`} 
                      size={20} 
                    />
                  </button>
                  {expandedFaq === index && (
                    <div className="px-6 pb-4">
                      <p className="text-slate-600">{faq.answer}</p>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* CTA Section */}
      <section className="bg-amber-600 py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">Ready for Your Glamping Adventure?</h2>
          <p className="text-xl text-amber-100 mb-8">
            Book your luxury outdoor experience and create unforgettable memories in Idaho's wilderness
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/book"
              className="bg-white text-amber-600 hover:bg-slate-100 px-8 py-4 rounded-lg text-lg font-semibold transition-colors flex items-center justify-center space-x-2"
            >
              <Calendar size={20} />
              <span>Book Your Stay</span>
            </Link>
            <a
              href="tel:+12085550125"
              className="border-2 border-white text-white hover:bg-white hover:text-amber-600 px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Call (208) 555-0125
            </a>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default Glamping;
