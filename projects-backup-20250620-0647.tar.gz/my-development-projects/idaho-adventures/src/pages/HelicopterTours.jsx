import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronDown, Clock, Users, Star, MapPin, Camera, Shield, Calendar, Plane, Mountain, Eye } from 'lucide-react';

const HelicopterTours = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [expandedFaq, setExpandedFaq] = useState(null);

  const tourPackages = [
    {
      name: "Scenic Valley Tour",
      duration: "30 minutes",
      price: "$199",
      capacity: "Up to 3 passengers",
      highlights: ["Payette River Valley", "Mountain peaks", "Wildlife spotting", "Professional pilot"],
      description: "Perfect introduction to Idaho's beauty from above with stunning valley views."
    },
    {
      name: "Mountain Explorer",
      duration: "60 minutes",
      price: "$349",
      capacity: "Up to 3 passengers",
      highlights: ["Sawtooth Mountains", "Alpine lakes", "Glacier views", "Photo opportunities"],
      description: "Extended flight over Idaho's most dramatic mountain landscapes and pristine wilderness."
    },
    {
      name: "Sunset Adventure",
      duration: "90 minutes",
      price: "$499",
      capacity: "Up to 3 passengers",
      highlights: ["Golden hour lighting", "Champagne service", "Romantic setting", "Custom route"],
      description: "Ultimate romantic experience with champagne service and breathtaking sunset views."
    }
  ];

  const features = [
    {
      icon: Shield,
      title: "Safety First",
      description: "FAA certified pilots with thousands of flight hours and extensive experience."
    },
    {
      icon: Mountain,
      title: "Unique Perspectives",
      description: "Access remote locations and viewpoints impossible to reach by foot or vehicle."
    },
    {
      icon: Camera,
      title: "Photography Focus",
      description: "Large windows and stable flight patterns perfect for capturing stunning aerial photos."
    },
    {
      icon: Eye,
      title: "Wildlife Viewing",
      description: "Spot elk, deer, eagles, and other wildlife from a respectful aerial distance."
    }
  ];

  const faqs = [
    {
      question: "What should I wear for the helicopter tour?",
      answer: "Dress comfortably and avoid loose items. Closed-toe shoes are required. We provide headsets for communication. Avoid wearing hats that might blow off."
    },
    {
      question: "Are there weight restrictions?",
      answer: "Yes, for safety reasons we have a 300lb per passenger limit and 600lb total weight limit per flight. Please inform us of passenger weights when booking."
    },
    {
      question: "What happens if weather conditions are poor?",
      answer: "Safety is our top priority. Flights may be cancelled or rescheduled due to weather. We'll contact you with updates and offer full refunds or rescheduling options."
    },
    {
      question: "Can I bring my camera?",
      answer: "Absolutely! We encourage photography. Our helicopters have large windows perfect for photos. GoPros and professional cameras are welcome with secure straps."
    },
    {
      question: "Do you offer private tours?",
      answer: "Yes! All our tours can be booked privately. We also offer custom routes for special occasions like proposals, anniversaries, or aerial photography sessions."
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-sky-900/80 to-orange-900/80 z-10"></div>
        <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
             style={{backgroundImage: "url('https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')"}}></div>
        
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <motion.h1 
            className="text-5xl md:text-7xl font-bold mb-6"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Helicopter Tours
          </motion.h1>
          <motion.p 
            className="text-xl md:text-2xl mb-8 text-sky-100"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Soar above Idaho's majestic landscapes and experience breathtaking aerial views
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <Link
              to="/book"
              className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Book Your Flight
            </Link>
            <button 
              onClick={() => setActiveTab('gallery')}
              className="border-2 border-white text-white hover:bg-white hover:text-slate-800 px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              View Routes
            </button>
          </motion.div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
          <ChevronDown size={32} />
        </div>
      </section>

      {/* Navigation Tabs */}
      <section className="bg-white shadow-lg sticky top-20 z-30">
        <div className="max-w-6xl mx-auto px-4">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'tours', label: 'Flight Packages' },
              { id: 'gallery', label: 'Gallery' },
              { id: 'faq', label: 'FAQ' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-orange-500 text-orange-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </section>

      {/* Overview Section */}
      {activeTab === 'overview' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-4xl font-bold text-slate-800 mb-6">Aerial Adventures Above Idaho</h2>
                <p className="text-lg text-slate-600 mb-6">
                  Experience Idaho's stunning landscapes from a completely new perspective. Our helicopter 
                  tours offer unparalleled views of the Sawtooth Mountains, pristine alpine lakes, and 
                  vast wilderness areas that are impossible to access by ground.
                </p>
                <p className="text-lg text-slate-600 mb-8">
                  Our experienced pilots are not just skilled aviators but also knowledgeable guides who 
                  share fascinating insights about Idaho's geology, wildlife, and history while ensuring 
                  your safety and comfort throughout the flight.
                </p>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="flex items-center space-x-3">
                    <Clock className="text-orange-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Duration</p>
                      <p className="text-slate-600">30-90 minutes</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Users className="text-orange-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Capacity</p>
                      <p className="text-slate-600">Up to 3 guests</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Star className="text-orange-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Experience</p>
                      <p className="text-slate-600">All ages welcome</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Plane className="text-orange-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Aircraft</p>
                      <p className="text-slate-600">Modern helicopters</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                  alt="Helicopter flying over mountains"
                  className="rounded-lg shadow-xl"
                />
                <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-lg shadow-lg">
                  <div className="flex items-center space-x-2 text-orange-600">
                    <Shield size={24} />
                    <span className="font-semibold">FAA Certified</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <motion.div 
                  key={feature.title}
                  className="text-center"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="text-orange-600" size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">{feature.title}</h3>
                  <p className="text-slate-600">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* Tour Packages Section */}
      {activeTab === 'tours' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Choose Your Flight Experience</h2>
              <p className="text-xl text-slate-600">From scenic tours to romantic sunset flights</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {tourPackages.map((tour, index) => (
                <motion.div 
                  key={tour.name}
                  className="bg-slate-50 rounded-xl p-8 hover:shadow-lg transition-shadow"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-slate-800 mb-2">{tour.name}</h3>
                    <div className="text-3xl font-bold text-orange-600 mb-2">{tour.price}</div>
                    <p className="text-slate-600">per person</p>
                  </div>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center space-x-3">
                      <Clock className="text-orange-600" size={20} />
                      <span className="text-slate-700">{tour.duration}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Users className="text-orange-600" size={20} />
                      <span className="text-slate-700">{tour.capacity}</span>
                    </div>
                  </div>
                  
                  <p className="text-slate-600 mb-6">{tour.description}</p>
                  
                  <ul className="space-y-2 mb-8">
                    {tour.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                        <span className="text-slate-700">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link
                    to="/book"
                    className="block w-full bg-orange-600 hover:bg-orange-700 text-white py-3 rounded-lg font-semibold transition-colors text-center"
                  >
                    Book This Flight
                  </Link>
                </motion.div>
              ))}
            </div>

            {/* Special Offers */}
            <div className="mt-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl p-8 text-white text-center">
              <h3 className="text-2xl font-bold mb-4">Special Occasion Flights</h3>
              <p className="text-lg mb-6">
                Make your proposal, anniversary, or celebration unforgettable with a custom helicopter tour. 
                We can arrange special routes, champagne service, and even coordinate with photographers.
              </p>
              <Link
                to="/book"
                className="bg-white text-orange-600 hover:bg-slate-100 px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Plan Custom Flight
              </Link>
            </div>
          </div>
        </motion.section>
      )}

      {/* Gallery Section */}
      {activeTab === 'gallery' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Aerial Photography Gallery</h2>
              <p className="text-xl text-slate-600">Stunning views from our helicopter tours</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                "https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              ].map((image, index) => (
                <motion.div 
                  key={index}
                  className="relative group cursor-pointer overflow-hidden rounded-lg"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <img 
                    src={image} 
                    alt={`Aerial view ${index + 1}`}
                    className="w-full h-64 object-cover transition-transform group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Camera className="text-white" size={32} />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* FAQ Section */}
      {activeTab === 'faq' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-slate-600">Everything you need to know about our helicopter tours</p>
            </div>
            
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <motion.div 
                  key={index}
                  className="border border-slate-200 rounded-lg"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <button
                    onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                    className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-slate-800">{faq.question}</span>
                    <ChevronDown 
                      className={`text-slate-500 transition-transform ${
                        expandedFaq === index ? 'rotate-180' : ''
                      }`} 
                      size={20} 
                    />
                  </button>
                  {expandedFaq === index && (
                    <div className="px-6 pb-4">
                      <p className="text-slate-600">{faq.answer}</p>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* CTA Section */}
      <section className="bg-orange-600 py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Take Flight?</h2>
          <p className="text-xl text-orange-100 mb-8">
            Experience Idaho's beauty from above with our professional helicopter tour services
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/book"
              className="bg-white text-orange-600 hover:bg-slate-100 px-8 py-4 rounded-lg text-lg font-semibold transition-colors flex items-center justify-center space-x-2"
            >
              <Calendar size={20} />
              <span>Book Flight</span>
            </Link>
            <a
              href="tel:+12085550124"
              className="border-2 border-white text-white hover:bg-white hover:text-orange-600 px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Call (208) 555-0124
            </a>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default HelicopterTours;
