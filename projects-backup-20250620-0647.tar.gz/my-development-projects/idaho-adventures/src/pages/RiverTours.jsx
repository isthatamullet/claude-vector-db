import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronDown, Clock, Users, Star, MapPin, Camera, Shield, Calendar } from 'lucide-react';

const RiverTours = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [expandedFaq, setExpandedFaq] = useState(null);

  const tourPackages = [
    {
      name: "Half-Day Adventure",
      duration: "4 hours",
      price: "$149",
      capacity: "Up to 12 guests",
      highlights: ["Hell's Canyon entrance", "Wildlife viewing", "Light rapids", "Snacks included"],
      description: "Perfect introduction to Snake River's beauty with gentle rapids and stunning scenery."
    },
    {
      name: "Full-Day Explorer",
      duration: "8 hours",
      price: "$249",
      capacity: "Up to 10 guests",
      highlights: ["Deep Hell's Canyon", "Historic sites", "Class III rapids", "Gourmet lunch"],
      description: "Complete Hell's Canyon experience with thrilling rapids and historical exploration."
    },
    {
      name: "Multi-Day Expedition",
      duration: "2-3 days",
      price: "$599",
      capacity: "Up to 8 guests",
      highlights: ["Camping under stars", "All meals included", "Expert guides", "Photography workshops"],
      description: "Ultimate wilderness adventure with overnight camping and comprehensive exploration."
    }
  ];

  const faqs = [
    {
      question: "What should I bring on the tour?",
      answer: "We provide life jackets and safety equipment. Bring sunscreen, hat, sunglasses, camera, and comfortable clothes that can get wet. We recommend quick-dry materials."
    },
    {
      question: "Are the tours suitable for children?",
      answer: "Yes! Children 6 and older can join our half-day tours. Full-day tours are recommended for ages 12+. All children must be accompanied by an adult."
    },
    {
      question: "What if the weather is bad?",
      answer: "Safety is our priority. Tours may be rescheduled due to severe weather. We'll contact you 24 hours before your tour with any updates."
    },
    {
      question: "Do you provide food and drinks?",
      answer: "Half-day tours include snacks and water. Full-day tours include a gourmet lunch. Multi-day expeditions include all meals prepared by our camp chefs."
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-emerald-900/80 z-10"></div>
        <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
             style={{backgroundImage: "url('https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')"}}></div>
        
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <motion.h1 
            className="text-5xl md:text-7xl font-bold mb-6"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Snake River Tours
          </motion.h1>
          <motion.p 
            className="text-xl md:text-2xl mb-8 text-blue-100"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Experience the power and beauty of Hell's Canyon aboard our custom jet boats
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <Link
              to="/book"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Book Your Adventure
            </Link>
            <button 
              onClick={() => setActiveTab('gallery')}
              className="border-2 border-white text-white hover:bg-white hover:text-slate-800 px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              View Gallery
            </button>
          </motion.div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
          <ChevronDown size={32} />
        </div>
      </section>

      {/* Navigation Tabs */}
      <section className="bg-white shadow-lg sticky top-20 z-30">
        <div className="max-w-6xl mx-auto px-4">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'tours', label: 'Tour Packages' },
              { id: 'gallery', label: 'Gallery' },
              { id: 'faq', label: 'FAQ' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-emerald-500 text-emerald-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </section>

      {/* Overview Section */}
      {activeTab === 'overview' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-slate-800 mb-6">Hell's Canyon Adventure</h2>
                <p className="text-lg text-slate-600 mb-6">
                  Navigate the deepest river gorge in North America aboard our state-of-the-art jet boats. 
                  The Snake River carves through Hell's Canyon, creating a dramatic landscape of towering 
                  cliffs, pristine wilderness, and thrilling rapids.
                </p>
                <p className="text-lg text-slate-600 mb-8">
                  Our experienced captains share the rich history of the region while ensuring your safety 
                  and comfort throughout the journey. From ancient petroglyphs to abandoned homesteads, 
                  every bend in the river reveals new wonders.
                </p>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="flex items-center space-x-3">
                    <Clock className="text-emerald-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Duration</p>
                      <p className="text-slate-600">4-8 hours</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Users className="text-emerald-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Group Size</p>
                      <p className="text-slate-600">8-12 guests</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Star className="text-emerald-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Difficulty</p>
                      <p className="text-slate-600">All levels</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="text-emerald-600" size={24} />
                    <div>
                      <p className="font-semibold text-slate-800">Location</p>
                      <p className="text-slate-600">Hell's Canyon</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                  alt="Jet boat in Hell's Canyon"
                  className="rounded-lg shadow-xl"
                />
                <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-lg shadow-lg">
                  <div className="flex items-center space-x-2 text-emerald-600">
                    <Shield size={24} />
                    <span className="font-semibold">Certified Guides</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* Tour Packages Section */}
      {activeTab === 'tours' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Choose Your Adventure</h2>
              <p className="text-xl text-slate-600">From quick escapes to multi-day expeditions</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {tourPackages.map((tour, index) => (
                <motion.div 
                  key={tour.name}
                  className="bg-slate-50 rounded-xl p-8 hover:shadow-lg transition-shadow"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-slate-800 mb-2">{tour.name}</h3>
                    <div className="text-3xl font-bold text-emerald-600 mb-2">{tour.price}</div>
                    <p className="text-slate-600">per person</p>
                  </div>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center space-x-3">
                      <Clock className="text-emerald-600" size={20} />
                      <span className="text-slate-700">{tour.duration}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Users className="text-emerald-600" size={20} />
                      <span className="text-slate-700">{tour.capacity}</span>
                    </div>
                  </div>
                  
                  <p className="text-slate-600 mb-6">{tour.description}</p>
                  
                  <ul className="space-y-2 mb-8">
                    {tour.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-emerald-600 rounded-full"></div>
                        <span className="text-slate-700">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link
                    to="/book"
                    className="block w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-lg font-semibold transition-colors text-center"
                  >
                    Book This Tour
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* Gallery Section */}
      {activeTab === 'gallery' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Experience Gallery</h2>
              <p className="text-xl text-slate-600">See what awaits you on the Snake River</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              ].map((image, index) => (
                <motion.div 
                  key={index}
                  className="relative group cursor-pointer overflow-hidden rounded-lg"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <img 
                    src={image} 
                    alt={`River tour ${index + 1}`}
                    className="w-full h-64 object-cover transition-transform group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Camera className="text-white" size={32} />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* FAQ Section */}
      {activeTab === 'faq' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-slate-600">Everything you need to know about our river tours</p>
            </div>
            
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <motion.div 
                  key={index}
                  className="border border-slate-200 rounded-lg"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <button
                    onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                    className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-slate-800">{faq.question}</span>
                    <ChevronDown 
                      className={`text-slate-500 transition-transform ${
                        expandedFaq === index ? 'rotate-180' : ''
                      }`} 
                      size={20} 
                    />
                  </button>
                  {expandedFaq === index && (
                    <div className="px-6 pb-4">
                      <p className="text-slate-600">{faq.answer}</p>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      )}

      {/* CTA Section */}
      <section className="bg-emerald-600 py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">Ready for Your Snake River Adventure?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Book now and experience the thrill of Hell's Canyon with Idaho's premier river tour company
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/book"
              className="bg-white text-emerald-600 hover:bg-slate-100 px-8 py-4 rounded-lg text-lg font-semibold transition-colors flex items-center justify-center space-x-2"
            >
              <Calendar size={20} />
              <span>Book Now</span>
            </Link>
            <a
              href="tel:+12085550123"
              className="border-2 border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Call (208) 555-0123
            </a>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default RiverTours;
