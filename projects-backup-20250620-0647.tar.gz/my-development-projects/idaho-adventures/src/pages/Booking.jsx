import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Calendar, Users, Clock, MapPin, Phone, Mail, CreditCard, Check } from 'lucide-react';

const Booking = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedTour, setSelectedTour] = useState('');
  const [formData, setFormData] = useState({
    tourType: '',
    tourPackage: '',
    date: '',
    time: '',
    guests: 1,
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    specialRequests: '',
    emergencyContact: '',
    emergencyPhone: ''
  });

  const tours = {
    river: {
      name: "Snake River Tours",
      packages: [
        { id: 'river-half', name: 'Half-Day Adventure', duration: '4 hours', price: 149 },
        { id: 'river-full', name: 'Full-Day Explorer', duration: '8 hours', price: 249 },
        { id: 'river-multi', name: 'Multi-Day Expedition', duration: '2-3 days', price: 599 }
      ]
    },
    helicopter: {
      name: "Helicopter Tours",
      packages: [
        { id: 'heli-scenic', name: 'Scenic Valley Tour', duration: '30 minutes', price: 199 },
        { id: 'heli-mountain', name: 'Mountain Explorer', duration: '60 minutes', price: 349 },
        { id: 'heli-sunset', name: 'Sunset Adventure', duration: '90 minutes', price: 499 }
      ]
    },
    glamping: {
      name: "Luxury Glamping",
      packages: [
        { id: 'glamp-safari', name: 'Luxury Safari Tent', duration: 'per night', price: 299 },
        { id: 'glamp-family', name: 'Family Cabin', duration: 'per night', price: 449 },
        { id: 'glamp-tree', name: 'Romantic Treehouse', duration: 'per night', price: 399 }
      ]
    }
  };

  const timeSlots = {
    river: ['8:00 AM', '1:00 PM'],
    helicopter: ['9:00 AM', '11:00 AM', '2:00 PM', '4:00 PM', '6:00 PM'],
    glamping: ['Check-in: 3:00 PM']
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const getSelectedPackage = () => {
    if (!formData.tourType || !formData.tourPackage) return null;
    return tours[formData.tourType]?.packages.find(pkg => pkg.id === formData.tourPackage);
  };

  const calculateTotal = () => {
    const selectedPackage = getSelectedPackage();
    if (!selectedPackage) return 0;
    return selectedPackage.price * formData.guests;
  };

  const steps = [
    { number: 1, title: 'Select Tour', description: 'Choose your adventure' },
    { number: 2, title: 'Date & Time', description: 'Pick your preferred schedule' },
    { number: 3, title: 'Guest Details', description: 'Provide contact information' },
    { number: 4, title: 'Payment', description: 'Complete your booking' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="pt-20 min-h-screen bg-slate-50"
    >
      {/* Header */}
      <section className="bg-white shadow-sm py-8">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-slate-800 text-center mb-4">Book Your Adventure</h1>
          <p className="text-xl text-slate-600 text-center">Reserve your Idaho wilderness experience in just a few steps</p>
        </div>
      </section>

      {/* Progress Steps */}
      <section className="bg-white border-b py-6">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold ${
                    currentStep >= step.number 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-slate-200 text-slate-500'
                  }`}>
                    {currentStep > step.number ? <Check size={16} /> : step.number}
                  </div>
                  <div className="text-center mt-2">
                    <div className="text-sm font-semibold text-slate-800">{step.title}</div>
                    <div className="text-xs text-slate-500">{step.description}</div>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div className={`flex-1 h-1 mx-4 ${
                    currentStep > step.number ? 'bg-emerald-600' : 'bg-slate-200'
                  }`}></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg p-8">
              
              {/* Step 1: Select Tour */}
              {currentStep === 1 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-bold text-slate-800 mb-6">Select Your Adventure</h2>
                  
                  <div className="space-y-4 mb-6">
                    {Object.entries(tours).map(([key, tour]) => (
                      <div key={key} className="border border-slate-200 rounded-lg p-4">
                        <div className="flex items-center mb-3">
                          <input
                            type="radio"
                            id={key}
                            name="tourType"
                            value={key}
                            checked={formData.tourType === key}
                            onChange={(e) => handleInputChange('tourType', e.target.value)}
                            className="mr-3"
                          />
                          <label htmlFor={key} className="text-lg font-semibold text-slate-800">
                            {tour.name}
                          </label>
                        </div>
                        
                        {formData.tourType === key && (
                          <div className="ml-6 space-y-2">
                            {tour.packages.map((pkg) => (
                              <div key={pkg.id} className="flex items-center">
                                <input
                                  type="radio"
                                  id={pkg.id}
                                  name="tourPackage"
                                  value={pkg.id}
                                  checked={formData.tourPackage === pkg.id}
                                  onChange={(e) => handleInputChange('tourPackage', e.target.value)}
                                  className="mr-3"
                                />
                                <label htmlFor={pkg.id} className="flex-1 flex justify-between">
                                  <span>{pkg.name} ({pkg.duration})</span>
                                  <span className="font-semibold">${pkg.price}</span>
                                </label>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Step 2: Date & Time */}
              {currentStep === 2 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-bold text-slate-800 mb-6">Select Date & Time</h2>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        <Calendar className="inline mr-2" size={16} />
                        Preferred Date
                      </label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => handleInputChange('date', e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        <Clock className="inline mr-2" size={16} />
                        Preferred Time
                      </label>
                      <select
                        value={formData.time}
                        onChange={(e) => handleInputChange('time', e.target.value)}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      >
                        <option value="">Select time</option>
                        {formData.tourType && timeSlots[formData.tourType]?.map((time) => (
                          <option key={time} value={time}>{time}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      <Users className="inline mr-2" size={16} />
                      Number of Guests
                    </label>
                    <select
                      value={formData.guests}
                      onChange={(e) => handleInputChange('guests', parseInt(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    >
                      {[1,2,3,4,5,6,7,8,9,10,11,12].map(num => (
                        <option key={num} value={num}>{num} {num === 1 ? 'Guest' : 'Guests'}</option>
                      ))}
                    </select>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Guest Details */}
              {currentStep === 3 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-bold text-slate-800 mb-6">Guest Information</h2>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">First Name</label>
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange('firstName', e.target.value)}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="Enter first name"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Last Name</label>
                      <input
                        type="text"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange('lastName', e.target.value)}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="Enter last name"
                      />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        <Mail className="inline mr-2" size={16} />
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="Enter email address"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        <Phone className="inline mr-2" size={16} />
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="Enter phone number"
                      />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Emergency Contact Name</label>
                      <input
                        type="text"
                        value={formData.emergencyContact}
                        onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="Emergency contact name"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">Emergency Contact Phone</label>
                      <input
                        type="tel"
                        value={formData.emergencyPhone}
                        onChange={(e) => handleInputChange('emergencyPhone', e.target.value)}
                        className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="Emergency contact phone"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Special Requests or Dietary Restrictions</label>
                    <textarea
                      value={formData.specialRequests}
                      onChange={(e) => handleInputChange('specialRequests', e.target.value)}
                      rows={4}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      placeholder="Any special requests, dietary restrictions, or accessibility needs..."
                    />
                  </div>
                </motion.div>
              )}

              {/* Step 4: Payment */}
              {currentStep === 4 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-bold text-slate-800 mb-6">Payment Information</h2>
                  
                  <div className="bg-slate-50 p-6 rounded-lg mb-6">
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">Secure Payment</h3>
                    <div className="flex items-center space-x-4 mb-4">
                      <CreditCard className="text-slate-600" size={24} />
                      <span className="text-slate-600">Your payment information is encrypted and secure</span>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Card Number</label>
                        <input
                          type="text"
                          placeholder="1234 5678 9012 3456"
                          className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Cardholder Name</label>
                        <input
                          type="text"
                          placeholder="Name on card"
                          className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Expiry Date</label>
                        <input
                          type="text"
                          placeholder="MM/YY"
                          className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">CVV</label>
                        <input
                          type="text"
                          placeholder="123"
                          className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-emerald-50 p-4 rounded-lg mb-6">
                    <div className="flex items-center space-x-2 text-emerald-800">
                      <Check size={20} />
                      <span className="font-semibold">Cancellation Policy</span>
                    </div>
                    <p className="text-emerald-700 text-sm mt-2">
                      Free cancellation up to 48 hours before your tour. Weather-related cancellations receive full refund.
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between pt-6 border-t">
                <button
                  onClick={handlePrevious}
                  disabled={currentStep === 1}
                  className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                    currentStep === 1
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                  }`}
                >
                  Previous
                </button>
                
                <button
                  onClick={currentStep === 4 ? () => alert('Booking submitted!') : handleNext}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold transition-colors"
                >
                  {currentStep === 4 ? 'Complete Booking' : 'Next Step'}
                </button>
              </div>
            </div>
          </div>

          {/* Booking Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-24">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Booking Summary</h3>
              
              {getSelectedPackage() && (
                <div className="space-y-4">
                  <div className="border-b pb-4">
                    <h4 className="font-semibold text-slate-800">{tours[formData.tourType]?.name}</h4>
                    <p className="text-slate-600">{getSelectedPackage().name}</p>
                    <p className="text-sm text-slate-500">{getSelectedPackage().duration}</p>
                  </div>
                  
                  {formData.date && (
                    <div className="flex items-center space-x-2 text-slate-600">
                      <Calendar size={16} />
                      <span>{new Date(formData.date).toLocaleDateString()}</span>
                    </div>
                  )}
                  
                  {formData.time && (
                    <div className="flex items-center space-x-2 text-slate-600">
                      <Clock size={16} />
                      <span>{formData.time}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center space-x-2 text-slate-600">
                    <Users size={16} />
                    <span>{formData.guests} {formData.guests === 1 ? 'Guest' : 'Guests'}</span>
                  </div>
                  
                  <div className="border-t pt-4">
                    <div className="flex justify-between mb-2">
                      <span>Price per person:</span>
                      <span>${getSelectedPackage().price}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span>Guests:</span>
                      <span>{formData.guests}</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg border-t pt-2">
                      <span>Total:</span>
                      <span>${calculateTotal()}</span>
                    </div>
                  </div>
                </div>
              )}
              
              {!getSelectedPackage() && (
                <p className="text-slate-500 text-center py-8">Select a tour to see pricing details</p>
              )}
              
              <div className="mt-6 pt-6 border-t">
                <div className="flex items-center space-x-2 text-emerald-600 mb-2">
                  <Phone size={16} />
                  <span className="text-sm">Need help? Call (208) 555-0123</span>
                </div>
                <div className="flex items-center space-x-2 text-emerald-600">
                  <Mail size={16} />
                  <span className="text-sm">info@idahoadventures.com</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default Booking;
