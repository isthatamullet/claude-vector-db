import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Award, Users, Heart, Shield, Mountain, Star, Calendar, MapPin } from 'lucide-react';

const About = () => {
  const [activeTab, setActiveTab] = useState('story');

  const teamMembers = [
    {
      name: "Sarah Mitchell",
      role: "Founder & CEO",
      experience: "15 years",
      bio: "Former wilderness guide turned entrepreneur, Sarah founded Idaho Adventures to share her passion for Idaho's natural beauty.",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "Jake Thompson",
      role: "Head River Guide",
      experience: "12 years",
      bio: "Master navigator of Hell's Canyon with over 2,000 successful river tours and extensive wilderness experience.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "Maria Rodriguez",
      role: "Chief Pilot",
      experience: "18 years",
      bio: "Commercial helicopter pilot with extensive mountain flying experience and passion for aerial photography.",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "David Chen",
      role: "Hospitality Director",
      experience: "10 years",
      bio: "Luxury resort veteran who ensures every glamping guest experiences five-star service in the wilderness.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    }
  ];

  const timeline = [
    {
      year: "2015",
      title: "The Beginning",
      description: "Sarah Mitchell starts Idaho Adventures with a single jet boat and a dream to share Idaho's wilderness."
    },
    {
      year: "2017",
      title: "Taking Flight",
      description: "Added helicopter tours to our offerings, becoming the first company to offer combined river and aerial adventures."
    },
    {
      year: "2019",
      title: "Luxury Camping",
      description: "Opened our glamping resort, providing luxury accommodations in pristine wilderness settings."
    },
    {
      year: "2021",
      title: "Award Recognition",
      description: "Named 'Best Adventure Tour Company' by Idaho Tourism Board and achieved 5-star safety rating."
    },
    {
      year: "2023",
      title: "Expansion",
      description: "Expanded fleet and team, now serving over 5,000 guests annually while maintaining personalized service."
    },
    {
      year: "2025",
      title: "Today",
      description: "Leading Idaho's adventure tourism with commitment to safety, sustainability, and unforgettable experiences."
    }
  ];

  const values = [
    {
      icon: Shield,
      title: "Safety First",
      description: "Every adventure begins with comprehensive safety protocols and expert guides with impeccable records."
    },
    {
      icon: Heart,
      title: "Passion for Nature",
      description: "We're not just guides—we're nature enthusiasts sharing our love for Idaho's incredible landscapes."
    },
    {
      icon: Users,
      title: "Personal Service",
      description: "Small groups and personalized attention ensure every guest has a unique, memorable experience."
    },
    {
      icon: Mountain,
      title: "Environmental Stewardship",
      description: "Committed to preserving Idaho's wilderness for future generations through sustainable practices."
    }
  ];

  const certifications = [
    {
      title: "FAA Certified",
      description: "All pilots hold commercial licenses with mountain flying endorsements"
    },
    {
      title: "USCG Licensed",
      description: "River guides certified by US Coast Guard for passenger vessel operations"
    },
    {
      title: "Wilderness First Aid",
      description: "All staff trained in wilderness emergency response and first aid"
    },
    {
      title: "Eco-Tourism Certified",
      description: "Recognized for sustainable tourism practices and environmental protection"
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 to-emerald-900/80 z-10"></div>
        <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
             style={{backgroundImage: "url('https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')"}}></div>
        
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <motion.h1 
            className="text-5xl md:text-7xl font-bold mb-6"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            About Idaho Adventures
          </motion.h1>
          <motion.p 
            className="text-xl md:text-2xl mb-8 text-slate-100"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Passionate guides sharing Idaho's wilderness through safe, sustainable adventures
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
              Meet Our Team
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-slate-800 px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
              Our Story
            </button>
          </motion.div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
          <ChevronDown size={32} />
        </div>
      </section>

      {/* Navigation Tabs */}
      <section className="bg-white shadow-lg sticky top-20 z-30">
        <div className="max-w-6xl mx-auto px-4">
          <nav className="flex space-x-8">
            {[
              { id: 'story', label: 'Our Story' },
              { id: 'team', label: 'Meet the Team' },
              { id: 'values', label: 'Our Values' },
              { id: 'certifications', label: 'Certifications' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-emerald-500 text-emerald-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </section>

      {/* Our Story Section */}
      {activeTab === 'story' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-4xl font-bold text-slate-800 mb-6">Born from Passion</h2>
                <p className="text-lg text-slate-600 mb-6">
                  Idaho Adventures began with a simple belief: everyone should experience the raw beauty 
                  and thrilling adventures that Idaho's wilderness offers. Founded by Sarah Mitchell, 
                  a former wilderness guide with over 15 years of experience, our company started with 
                  a single jet boat and an unwavering commitment to safety and sustainability.
                </p>
                <p className="text-lg text-slate-600 mb-8">
                  What started as weekend river tours has grown into Idaho's premier adventure company, 
                  offering helicopter tours, luxury glamping, and multi-day expeditions. Despite our 
                  growth, we've never lost sight of our core mission: creating transformative experiences 
                  that connect people with nature while preserving these incredible landscapes for future generations.
                </p>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-emerald-600 mb-2">10+</div>
                    <p className="text-slate-600">Years of Excellence</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-emerald-600 mb-2">5,000+</div>
                    <p className="text-slate-600">Happy Guests</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-emerald-600 mb-2">100%</div>
                    <p className="text-slate-600">Satisfaction</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-emerald-600 mb-2">25+</div>
                    <p className="text-slate-600">Expert Guides</p>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                  alt="Idaho wilderness landscape"
                  className="rounded-lg shadow-xl"
                />
                <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-lg shadow-lg">
                  <div className="flex items-center space-x-2 text-emerald-600">
                    <Award size={24} />
                    <span className="font-semibold">Award Winning</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Timeline */}
            <div className="mb-16">
              <h3 className="text-3xl font-bold text-slate-800 text-center mb-12">Our Journey</h3>
              <div className="relative">
                <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-emerald-200"></div>
                {timeline.map((item, index) => (
                  <motion.div 
                    key={item.year}
                    className={`flex items-center mb-8 ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}
                    initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div className={`w-5/12 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
                      <div className="bg-white p-6 rounded-lg shadow-lg">
                        <div className="text-2xl font-bold text-emerald-600 mb-2">{item.year}</div>
                        <h4 className="text-xl font-bold text-slate-800 mb-2">{item.title}</h4>
                        <p className="text-slate-600">{item.description}</p>
                      </div>
                    </div>
                    <div className="w-2/12 flex justify-center">
                      <div className="w-4 h-4 bg-emerald-600 rounded-full border-4 border-white shadow-lg"></div>
                    </div>
                    <div className="w-5/12"></div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* Team Section */}
      {activeTab === 'team' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Meet Our Expert Team</h2>
              <p className="text-xl text-slate-600">Passionate professionals dedicated to your adventure</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers.map((member, index) => (
                <motion.div 
                  key={member.name}
                  className="bg-slate-50 rounded-xl overflow-hidden hover:shadow-lg transition-shadow"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="h-64 overflow-hidden">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-slate-800 mb-1">{member.name}</h3>
                    <p className="text-emerald-600 font-semibold mb-2">{member.role}</p>
                    <div className="flex items-center space-x-2 mb-4">
                      <Calendar className="text-slate-400" size={16} />
                      <span className="text-slate-600 text-sm">{member.experience} experience</span>
                    </div>
                    <p className="text-slate-600 text-sm">{member.bio}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Team Stats */}
            <div className="mt-16 bg-emerald-600 rounded-xl p-8 text-white text-center">
              <h3 className="text-2xl font-bold mb-6">Our Team by the Numbers</h3>
              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <div className="text-3xl font-bold mb-2">25+</div>
                  <p>Expert Guides</p>
                </div>
                <div>
                  <div className="text-3xl font-bold mb-2">150+</div>
                  <p>Years Combined Experience</p>
                </div>
                <div>
                  <div className="text-3xl font-bold mb-2">12</div>
                  <p>Languages Spoken</p>
                </div>
                <div>
                  <div className="text-3xl font-bold mb-2">100%</div>
                  <p>Certified Professionals</p>
                </div>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* Values Section */}
      {activeTab === 'values' && (
        <motion.section 
          className="py-16 bg-slate-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Our Core Values</h2>
              <p className="text-xl text-slate-600">The principles that guide everything we do</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8 mb-16">
              {values.map((value, index) => (
                <motion.div 
                  key={value.title}
                  className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="flex items-start space-x-4">
                    <div className="bg-emerald-100 p-3 rounded-lg">
                      <value.icon className="text-emerald-600" size={32} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-800 mb-3">{value.title}</h3>
                      <p className="text-slate-600">{value.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Mission Statement */}
            <div className="bg-white p-8 rounded-xl shadow-lg text-center">
              <h3 className="text-2xl font-bold text-slate-800 mb-4">Our Mission</h3>
              <p className="text-lg text-slate-600 max-w-4xl mx-auto">
                To provide transformative outdoor experiences that connect people with Idaho's pristine wilderness 
                while maintaining the highest standards of safety, sustainability, and personalized service. We believe 
                that adventure has the power to inspire, heal, and create lasting memories that enrich lives and 
                foster a deeper appreciation for our natural world.
              </p>
            </div>
          </div>
        </motion.section>
      )}

      {/* Certifications Section */}
      {activeTab === 'certifications' && (
        <motion.section 
          className="py-16 bg-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Certifications & Awards</h2>
              <p className="text-xl text-slate-600">Recognized excellence in safety and service</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {certifications.map((cert, index) => (
                <motion.div 
                  key={cert.title}
                  className="text-center"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Award className="text-emerald-600" size={40} />
                  </div>
                  <h3 className="text-lg font-bold text-slate-800 mb-2">{cert.title}</h3>
                  <p className="text-slate-600">{cert.description}</p>
                </motion.div>
              ))}
            </div>

            {/* Awards */}
            <div className="bg-slate-50 p-8 rounded-xl">
              <h3 className="text-2xl font-bold text-slate-800 text-center mb-8">Recent Awards & Recognition</h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-2">
                    <Star className="text-yellow-500" size={24} />
                    <span className="font-bold text-slate-800">2024</span>
                  </div>
                  <p className="text-slate-600">Best Adventure Tour Company - Idaho Tourism Board</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-2">
                    <Shield className="text-emerald-600" size={24} />
                    <span className="font-bold text-slate-800">2023</span>
                  </div>
                  <p className="text-slate-600">5-Star Safety Rating - Adventure Tourism Association</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-2">
                    <Mountain className="text-blue-600" size={24} />
                    <span className="font-bold text-slate-800">2023</span>
                  </div>
                  <p className="text-slate-600">Sustainable Tourism Excellence Award</p>
                </div>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* CTA Section */}
      <section className="bg-emerald-600 py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Adventure with Us?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Join thousands of satisfied guests who have experienced Idaho's wilderness with our expert team
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-emerald-600 hover:bg-slate-100 px-8 py-4 rounded-lg text-lg font-semibold transition-colors flex items-center justify-center space-x-2">
              <Calendar size={20} />
              <span>Book Adventure</span>
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default About;
