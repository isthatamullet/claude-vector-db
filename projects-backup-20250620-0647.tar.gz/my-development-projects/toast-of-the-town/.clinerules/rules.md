# Cline Rules - Toast of the Town Restaurant Website

## Project Foundation Rules

### Always follow the instructions and guidelines in /docs and /.clinerules

1. **Read and reference the PRD** (`/docs/prd.md`) for all technical requirements, implementation order, and success metrics
2. **Follow the Design System** (`/docs/design-system.md`) for all visual components, colors, typography, and styling decisions
3. **Use the Tailwind Installation Guide** (`/docs/tailwind-installation.md`) exactly as specified for setup

## Technology Stack Requirements

### Required Technologies
- **Build Tool:** Vite (must be primary build system)
- **Styling:** Tailwind CSS with @tailwindcss/vite plugin
- **JavaScript:** Modern ES6+ vanilla JavaScript or React (Vite + React if complex state needed)
- **Image API:** Pixabay API with key `50523160-a1585f1d1edc8217bd4bef1a6`

### Prohibited Technologies
- **No Webpack or other bundlers** (Vite only)
- **No Bootstrap or other CSS frameworks** (Tailwind only)
- **No jQuery** (Modern JavaScript only)
- **No outdated build processes** (npm/yarn scripts with Vite)

## Development Standards

### Code Quality
- **Mobile-First Approach:** Always start with mobile layout, then enhance for larger screens
- **Semantic HTML5:** Use proper semantic elements (`<nav>`, `<main>`, `<section>`, `<article>`)
- **Accessibility:** Include ARIA labels, alt text, and keyboard navigation support
- **Performance:** Optimize images, use lazy loading, minimize bundle size

### File Structure Requirements
```
project-root/
├── public/
│   ├── images/
│   └── favicon.ico
├── src/
│   ├── styles/
│   │   └── main.css
│   ├── scripts/
│   │   └── main.js
│   ├── components/
│   └── pages/
├── docs/
├── .clinerules/
├── package.json
└── vite.config.js
```

### CSS/Styling Rules
- **Use Design System tokens:** Reference color, spacing, and typography variables from design system
- **Tailwind-first:** Use Tailwind utilities for 90% of styling
- **Custom CSS sparingly:** Only for complex animations, parallax effects, or design system tokens
- **Component-based:** Create reusable component classes that combine Tailwind utilities

## Content and Functionality Requirements

### Page Requirements
All pages must be fully functional with realistic content:

1. **Home Page:**
   - Hero section with parallax scrolling
   - Featured menu items (minimum 6 items)
   - Location overview
   - Call-to-action buttons

2. **Menu Page:**
   - Categorized menu (Toasts, Coffee, Sides)
   - Item cards with images, descriptions, pricing
   - Filtering functionality
   - Minimum 20 menu items total

3. **Locations Page:**
   - Multiple location cards (minimum 3 locations)
   - Address, hours, contact info for each
   - Map integration placeholder
   - Store locator functionality

4. **Contact Page:**
   - Working contact form
   - Business information
   - FAQ section (minimum 8 Q&As)
   - Social media links

5. **Order Now Page:**
   - Menu selection interface
   - Order customization options
   - Checkout flow mockup
   - Payment gateway placeholder

### Image Requirements
- **Use Pixabay API** for all placeholder images during development
- **Search terms:** toast, coffee, restaurant, food, avocado, bread, espresso
- **Optimize images:** WebP format when possible, appropriate sizing
- **Alt text:** Descriptive alternative text for all images

### Interactive Elements
- **All navigation links must work** and route to correct pages
- **Hover effects** on buttons, cards, and interactive elements
- **Form validation** on contact and order forms
- **Responsive behavior** across all device sizes
- **Loading states** for dynamic content

## Design Implementation Rules

### Color Usage
- **Primary Brand Color:** `#D4A574` (toast-golden) for CTAs and accents
- **Text Colors:** Coffee-brown tones from design system
- **Backgrounds:** White primary, cream secondary `#FFF8E1`
- **Success Color:** `#7CB342` (avocado-green) for confirmations

### Typography Implementation
```css
/* Required font imports */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&display=swap');
```

### Component Standards
- **Buttons:** Use design system button classes, include hover and active states
- **Cards:** Consistent padding, border-radius, and shadow effects
- **Forms:** Proper validation, focus states, and error handling
- **Navigation:** Fixed header with backdrop blur effect

## Performance Requirements

### Loading Performance
- **First Contentful Paint:** < 1.5 seconds
- **Image Optimization:** Lazy loading for below-fold images
- **CSS/JS Minification:** Use Vite's built-in optimization
- **Font Loading:** Use font-display: swap for Google Fonts

### SEO Requirements
- **Meta tags:** Title, description, and keywords for each page
- **Structured data:** Restaurant schema markup
- **Open Graph tags:** For social media sharing
- **Semantic HTML:** Proper heading hierarchy (h1 → h6)

## Animation and Interaction Rules

### Parallax Scrolling
- **Use modern libraries:** Locomotive Scroll or GSAP for parallax effects
- **Performance focus:** Use transform3d and will-change properties
- **Accessibility:** Respect `prefers-reduced-motion`

### Micro-interactions
- **Hover effects:** Subtle lift and scale effects on cards
- **Button feedback:** Scale and color transitions
- **Form interactions:** Focus states and validation feedback
- **Loading states:** Skeleton screens and spinners

## Testing and Quality Assurance

### Cross-browser Testing
- **Primary browsers:** Chrome, Safari, Firefox, Edge (latest versions)
- **Mobile browsers:** iOS Safari, Chrome Mobile
- **Responsive testing:** 320px to 1920px viewport widths

### Accessibility Testing
- **Keyboard navigation:** Tab through all interactive elements
- **Screen reader testing:** Proper ARIA labels and semantic structure
- **Color contrast:** Minimum 4.5:1 ratio for body text
- **Focus indicators:** Visible focus states for all interactive elements

### Performance Validation
- **Lighthouse scores:** 90+ for Performance, Accessibility, Best Practices, SEO
- **Core Web Vitals:** Meet Google's thresholds
- **Mobile optimization:** Mobile-first approach with fast loading

## Error Handling and Fallbacks

### Image Fallbacks
- **Pixabay API errors:** Provide placeholder images
- **Loading failures:** Show skeleton screens
- **Alt text:** Always include descriptive alternative text

### JavaScript Errors
- **Progressive enhancement:** Site must work without JavaScript
- **Error boundaries:** Catch and handle JavaScript errors gracefully
- **Form submission:** Include server-side validation assumptions

### Browser Compatibility
- **CSS fallbacks:** Provide fallbacks for modern CSS features
- **JavaScript polyfills:** For older browser support if needed
- **Graceful degradation:** Core functionality works everywhere

## Deployment Preparation

### Build Optimization
- **Asset optimization:** Compress images, minify CSS/JS
- **Bundle analysis:** Keep bundle sizes reasonable
- **Environment configuration:** Separate dev/prod configs
- **Static asset handling:** Proper caching headers

### Final Checklist
- [ ] All pages load and display correctly
- [ ] All navigation links function properly
- [ ] Forms include proper validation
- [ ] Images load with appropriate alt text
- [ ] Mobile responsiveness works across devices
- [ ] Accessibility standards met
- [ ] Performance benchmarks achieved
- [ ] Cross-browser compatibility verified

## Common Pitfalls to Avoid

1. **Don't ignore mobile-first** - Always start with mobile layout
2. **Don't skip accessibility** - Include ARIA labels and semantic HTML
3. **Don't use placeholder content** - Create realistic, branded content
4. **Don't forget error states** - Handle loading and error conditions
5. **Don't overlook performance** - Optimize images and minimize bundles
6. **Don't break semantic HTML** - Use proper document structure
7. **Don't ignore browser differences** - Test across multiple browsers
8. **Don't skip the design system** - Use consistent colors, fonts, and spacing

These rules ensure the Toast of the Town website meets all requirements for a modern, accessible, and performant restaurant website that showcases the brand effectively.