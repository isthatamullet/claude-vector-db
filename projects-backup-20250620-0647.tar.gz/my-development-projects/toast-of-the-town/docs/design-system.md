# Toast of the Town - Design System

## Brand Guidelines

### Brand Identity
**Toast of the Town** represents artisanal craftsmanship, premium quality, and European-inspired culinary tradition with a modern twist.

#### Brand Personality
- **Artisanal:** Handcrafted quality and attention to detail
- **Modern:** Contemporary design with clean lines
- **Warm:** Inviting and approachable atmosphere
- **Premium:** High-quality ingredients and experience
- **Innovative:** Creative twists on classic favorites

#### Brand Voice & Tone
- **Conversational:** Friendly and approachable
- **Confident:** Knowledgeable about craft and quality
- **Inviting:** Welcoming to all customers
- **Authentic:** Genuine passion for food and coffee

### Logo Guidelines
- **Primary Logo:** Wordmark with toast icon accent
- **Minimum Size:** 120px width for digital
- **Clear Space:** Equal to the height of the "T" in Toast
- **Usage:** Always on appropriate contrast backgrounds

## Color System

### Primary Palette
```css
/* Warm Toast Tones */
--toast-golden: #D4A574;      /* Primary brand color */
--toast-amber: #B8956A;       /* Primary variant */
--toast-caramel: #8B6F47;     /* Primary dark */

/* Coffee Rich Browns */
--coffee-espresso: #3C2415;   /* Primary dark text */
--coffee-mocha: #5D4037;      /* Secondary dark */
--coffee-latte: #8D6E63;      /* Medium brown */

/* Fresh Accents */
--avocado-green: #7CB342;     /* Success/Fresh */
--cream-white: #FFF8E1;       /* Background light */
--butter-yellow: #FFF176;     /* Accent warm */
```

### Semantic Color Tokens
```css
/* Text Colors */
--text-primary: var(--coffee-espresso);
--text-secondary: var(--coffee-mocha);
--text-muted: var(--coffee-latte);
--text-inverse: var(--cream-white);

/* Background Colors */
--bg-primary: #FFFFFF;
--bg-secondary: var(--cream-white);
--bg-accent: var(--toast-golden);
--bg-dark: var(--coffee-espresso);

/* Interactive Colors */
--interactive-primary: var(--toast-golden);
--interactive-hover: var(--toast-amber);
--interactive-active: var(--toast-caramel);
--interactive-disabled: #E0E0E0;

/* Status Colors */
--success: var(--avocado-green);
--warning: var(--butter-yellow);
--error: #F44336;
--info: #2196F3;
```

### Color Usage Guidelines
- **Primary Actions:** Use toast-golden for CTAs and key interactions
- **Text Hierarchy:** Coffee tones for readability and warmth
- **Backgrounds:** Cream-white for secondary sections, white for primary
- **Accents:** Avocado-green for fresh, healthy menu items

## Typography Scale

### Font Families
```css
/* Primary Font Stack */
--font-primary: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;

/* Display Font */
--font-display: 'Playfair Display', Georgia, serif;

/* Monospace */
--font-mono: 'JetBrains Mono', 'Fira Code', monospace;
```

### Type Scale
```css
/* Headings */
--text-5xl: 3rem;     /* 48px - Hero titles */
--text-4xl: 2.25rem;  /* 36px - Page titles */
--text-3xl: 1.875rem; /* 30px - Section titles */
--text-2xl: 1.5rem;   /* 24px - Subsection titles */
--text-xl: 1.25rem;   /* 20px - Card titles */
--text-lg: 1.125rem;  /* 18px - Large body */

/* Body Text */
--text-base: 1rem;    /* 16px - Default body */
--text-sm: 0.875rem;  /* 14px - Small text */
--text-xs: 0.75rem;   /* 12px - Captions */

/* Line Heights */
--leading-tight: 1.25;
--leading-normal: 1.5;
--leading-relaxed: 1.625;
--leading-loose: 2;

/* Font Weights */
--font-light: 300;
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;
--font-extrabold: 800;
```

### Typography Usage
```css
/* Heading Styles */
.heading-hero {
  font-family: var(--font-display);
  font-size: var(--text-5xl);
  font-weight: var(--font-bold);
  line-height: var(--leading-tight);
  color: var(--text-primary);
}

.heading-page {
  font-family: var(--font-display);
  font-size: var(--text-4xl);
  font-weight: var(--font-semibold);
  line-height: var(--leading-tight);
  color: var(--text-primary);
}

.heading-section {
  font-family: var(--font-primary);
  font-size: var(--text-3xl);
  font-weight: var(--font-semibold);
  line-height: var(--leading-normal);
  color: var(--text-primary);
}

/* Body Styles */
.body-large {
  font-family: var(--font-primary);
  font-size: var(--text-lg);
  font-weight: var(--font-normal);
  line-height: var(--leading-relaxed);
  color: var(--text-secondary);
}

.body-default {
  font-family: var(--font-primary);
  font-size: var(--text-base);
  font-weight: var(--font-normal);
  line-height: var(--leading-normal);
  color: var(--text-secondary);
}
```

## Spacing and Layout

### Spacing Scale
```css
/* Spacing tokens */
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
--space-20: 5rem;     /* 80px */
--space-24: 6rem;     /* 96px */
```

### Grid System
```css
/* Container widths */
--container-sm: 640px;
--container-md: 768px;
--container-lg: 1024px;
--container-xl: 1280px;
--container-2xl: 1536px;

/* Grid columns */
.grid-layout {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: var(--space-6);
  max-width: var(--container-xl);
  margin: 0 auto;
  padding: 0 var(--space-4);
}

/* Breakpoints */
@media (min-width: 640px) { /* sm */ }
@media (min-width: 768px) { /* md */ }
@media (min-width: 1024px) { /* lg */ }
@media (min-width: 1280px) { /* xl */ }
@media (min-width: 1536px) { /* 2xl */ }
```

## Component Library

### Buttons

#### Primary Button
```css
.btn-primary {
  background-color: var(--interactive-primary);
  color: white;
  font-weight: var(--font-semibold);
  padding: var(--space-3) var(--space-6);
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: var(--text-base);
}

.btn-primary:hover {
  background-color: var(--interactive-hover);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(212, 165, 116, 0.3);
}

.btn-primary:active {
  background-color: var(--interactive-active);
  transform: translateY(0);
}
```

#### Secondary Button
```css
.btn-secondary {
  background-color: transparent;
  color: var(--interactive-primary);
  border: 2px solid var(--interactive-primary);
  font-weight: var(--font-semibold);
  padding: var(--space-3) var(--space-6);
  border-radius: 0.5rem;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-secondary:hover {
  background-color: var(--interactive-primary);
  color: white;
}
```

#### Button Sizes
```css
.btn-sm { padding: var(--space-2) var(--space-4); font-size: var(--text-sm); }
.btn-md { padding: var(--space-3) var(--space-6); font-size: var(--text-base); }
.btn-lg { padding: var(--space-4) var(--space-8); font-size: var(--text-lg); }
```

### Cards

#### Menu Item Card
```css
.card-menu-item {
  background: white;
  border-radius: 1rem;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.card-menu-item:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
}

.card-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.card-content {
  padding: var(--space-6);
}

.card-title {
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.card-description {
  color: var(--text-secondary);
  margin-bottom: var(--space-4);
}

.card-price {
  font-size: var(--text-lg);
  font-weight: var(--font-bold);
  color: var(--interactive-primary);
}
```

#### Location Card
```css
.card-location {
  background: white;
  border-radius: 1rem;
  padding: var(--space-6);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  border-left: 4px solid var(--interactive-primary);
}

.location-name {
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  margin-bottom: var(--space-3);
}

.location-address {
  color: var(--text-secondary);
  margin-bottom: var(--space-4);
}

.location-hours {
  font-size: var(--text-sm);
  color: var(--text-muted);
}
```

### Forms

#### Input Fields
```css
.form-input {
  width: 100%;
  padding: var(--space-3) var(--space-4);
  border: 2px solid #E5E7EB;
  border-radius: 0.5rem;
  font-size: var(--text-base);
  transition: border-color 0.2s ease;
}

.form-input:focus {
  outline: none;
  border-color: var(--interactive-primary);
  box-shadow: 0 0 0 3px rgba(212, 165, 116, 0.1);
}

.form-label {
  display: block;
  font-weight: var(--font-medium);
  margin-bottom: var(--space-2);
  color: var(--text-primary);
}

.form-group {
  margin-bottom: var(--space-6);
}
```

#### Select Dropdown
```css
.form-select {
  width: 100%;
  padding: var(--space-3) var(--space-4);
  border: 2px solid #E5E7EB;
  border-radius: 0.5rem;
  background-color: white;
  cursor: pointer;
}
```

### Navigation

#### Primary Navigation
```css
.navbar {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(212, 165, 116, 0.1);
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000;
}

.nav-container {
  max-width: var(--container-xl);
  margin: 0 auto;
  padding: var(--space-4);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.nav-logo {
  font-family: var(--font-display);
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--interactive-primary);
  text-decoration: none;
}

.nav-links {
  display: flex;
  gap: var(--space-8);
}

.nav-link {
  color: var(--text-primary);
  text-decoration: none;
  font-weight: var(--font-medium);
  transition: color 0.2s ease;
}

.nav-link:hover,
.nav-link.active {
  color: var(--interactive-primary);
}
```

## Interaction Patterns and Animations

### Hover Effects
```css
/* Lift effect for cards */
.hover-lift {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.hover-lift:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
}

/* Scale effect for images */
.hover-scale {
  transition: transform 0.3s ease;
  overflow: hidden;
}

.hover-scale img {
  transition: transform 0.3s ease;
}

.hover-scale:hover img {
  transform: scale(1.05);
}
```

### Loading States
```css
.loading-skeleton {
  background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
  background-size: 200% 100%;
  animation: loading 1.5s infinite;
}

@keyframes loading {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
```

### Parallax Scrolling
```css
.parallax-container {
  overflow-x: hidden;
}

.parallax-element {
  will-change: transform;
}

/* Implemented via JavaScript with Locomotive Scroll or GSAP */
```

### Micro-interactions
```css
/* Button press feedback */
.btn-feedback {
  transition: transform 0.1s ease;
}

.btn-feedback:active {
  transform: scale(0.98);
}

/* Icon rotation on hover */
.icon-rotate {
  transition: transform 0.3s ease;
}

.icon-rotate:hover {
  transform: rotate(360deg);
}
```

## UX Guidelines and User Flows

### Navigation Principles
1. **Clear Hierarchy:** Primary navigation in header, secondary in footer
2. **Consistent Placement:** Navigation elements in expected locations
3. **Visual Feedback:** Active states and hover effects
4. **Mobile-First:** Hamburger menu for mobile, expanded for desktop

### User Flow: Menu Browsing
1. **Landing:** Home page with featured items
2. **Browse:** Navigate to full menu
3. **Filter:** Category and dietary filters
4. **Detail:** Expand item for full description
5. **Action:** Add to order or view similar items

### User Flow: Order Process
1. **Menu Selection:** Browse and select items
2. **Customization:** Modify ingredients/preparation
3. **Location:** Choose pickup or delivery location
4. **Payment:** Secure checkout process
5. **Confirmation:** Order confirmation and timing

### Information Architecture
```
Home
├── Hero Section
├── Featured Items
├── About Us
├── Locations Overview
└── Call to Action

Menu
├── Toast Categories
├── Coffee & Beverages
├── Sides & Extras
└── Dietary Filters

Locations
├── Store Locator
├── Individual Locations
│   ├── Address & Hours
│   ├── Contact Info
│   └── Directions
└── Map Integration

Contact
├── Contact Form
├── Business Info
├── FAQ
└── Social Media

Order Now
├── Menu Selection
├── Customization
├── Location Choice
├── Payment
└── Confirmation
```

## Accessibility Standards

### WCAG 2.1 AA Compliance

#### Color and Contrast
- **Text Contrast:** Minimum 4.5:1 for normal text, 3:1 for large text
- **Interactive Elements:** Minimum 3:1 contrast ratio
- **Focus Indicators:** Visible and high contrast

#### Keyboard Navigation
```css
.focus-visible {
  outline: 2px solid var(--interactive-primary);
  outline-offset: 2px;
}

/* Remove outline for mouse users */
.focus-not-visible {
  outline: none;
}
```

#### Screen Reader Support
```html
<!-- Semantic HTML structure -->
<nav aria-label="Main navigation">
<main role="main">
<section aria-labelledby="menu-heading">
<h2 id="menu-heading">Our Menu</h2>

<!-- ARIA labels for interactive elements -->
<button aria-label="Add avocado toast to order">
<img alt="Fresh avocado toast with microgreens" />
```

#### Alternative Text Guidelines
- **Decorative Images:** Empty alt attribute `alt=""`
- **Informative Images:** Descriptive alt text
- **Complex Images:** Extended descriptions via `aria-describedby`

## Responsive Behavior Specifications

### Breakpoint Strategy
- **Mobile First:** Design for 320px minimum width
- **Progressive Enhancement:** Add features for larger screens
- **Flexible Grid:** CSS Grid and Flexbox for layout
- **Fluid Typography:** clamp() for responsive text sizing

### Component Responsiveness

#### Navigation
```css
/* Mobile: Hamburger menu */
@media (max-width: 767px) {
  .nav-links {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    background: white;
    flex-direction: column;
    padding: var(--space-4);
  }
  
  .nav-links.active {
    display: flex;
  }
}

/* Desktop: Horizontal menu */
@media (min-width: 768px) {
  .nav-links {
    display: flex;
    flex-direction: row;
  }
  
  .hamburger {
    display: none;
  }
}
```

#### Grid Layout
```css
/* Mobile: Single column */
.menu-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: var(--space-4);
}

/* Tablet: Two columns */
@media (min-width: 768px) {
  .menu-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: var(--space-6);
  }
}

/* Desktop: Three columns */
@media (min-width: 1024px) {
  .menu-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

### Image Responsiveness
```css
.responsive-image {
  width: 100%;
  height: auto;
  object-fit: cover;
}

/* Responsive image container */
.image-container {
  position: relative;
  aspect-ratio: 16/9;
  overflow: hidden;
}
```

## Implementation Examples

### CSS Custom Properties Setup
```css
:root {
  /* Import all color, typography, and spacing tokens */
  /* as defined in previous sections */
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
  :root {
    --bg-primary: var(--coffee-espresso);
    --text-primary: var(--cream-white);
    /* Adjust other tokens as needed */
  }
}
```

### Utility Classes
```css
/* Spacing utilities */
.mt-4 { margin-top: var(--space-4); }
.mb-6 { margin-bottom: var(--space-6); }
.p-8 { padding: var(--space-8); }

/* Typography utilities */
.text-primary { color: var(--text-primary); }
.text-center { text-align: center; }
.font-bold { font-weight: var(--font-bold); }

/* Layout utilities */
.flex { display: flex; }
.grid { display: grid; }
.container { max-width: var(--container-xl); margin: 0 auto; }
```

This comprehensive design system provides the foundation for consistent, accessible, and beautiful user experiences across the Toast of the Town restaurant website.