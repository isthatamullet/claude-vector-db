// Toast of the Town - Main JavaScript
// Mobile-first responsive interactions and functionality

class ToastOfTheTown {
  constructor() {
    this.init();
  }

  init() {
    this.setupNavigation();
    this.setupScrollEffects();
    this.setupImageLazyLoading();
    this.setupFormValidation();
    this.setupMenuFiltering();
    this.setupAccessibility();
  }

  // Navigation functionality
  setupNavigation() {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    const navItems = document.querySelectorAll('.nav-link');

    // Mobile menu toggle
    if (hamburger && navLinks) {
      hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        hamburger.setAttribute('aria-expanded', 
          hamburger.getAttribute('aria-expanded') === 'true' ? 'false' : 'true'
        );
      });
    }

    // Close mobile menu when clicking nav items
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        if (navLinks) {
          navLinks.classList.remove('active');
        }
        if (hamburger) {
          hamburger.setAttribute('aria-expanded', 'false');
        }
      });
    });

    // Active navigation highlighting
    this.updateActiveNavigation();
    window.addEventListener('scroll', () => this.updateActiveNavigation());
  }

  updateActiveNavigation() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    let current = '';
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      if (window.scrollY >= (sectionTop - 200)) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  }

  // Enhanced scroll effects and animations
  setupScrollEffects() {
    // Check for reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    // Primary Effect: Hero Background Parallax (Home page only)
    this.setupHeroParallax(prefersReducedMotion);
    
    // Secondary Effect: Intersection Observer Reveals
    this.setupScrollRevealAnimations();
    
    // Tertiary Effect: Hover Micro-interactions (handled in CSS)
  }

  setupHeroParallax(prefersReducedMotion) {
    const hero = document.querySelector('.hero-section');
    const heroImage = hero?.querySelector('img');
    
    if (!hero || !heroImage || prefersReducedMotion) {
      // Fallback: Static background for reduced motion preferences
      if (heroImage && prefersReducedMotion) {
        heroImage.style.transform = 'none';
      }
      return;
    }

    // Classic background parallax with 0.5x scroll rate for subtle depth
    const handleParallax = ToastOfTheTown.debounce(() => {
      const scrolled = window.pageYOffset;
      const rate = scrolled * 0.5; // 0.5x scroll rate for subtle effect
      
      // Only apply parallax if hero is in viewport
      const heroRect = hero.getBoundingClientRect();
      if (heroRect.bottom >= 0 && heroRect.top <= window.innerHeight) {
        heroImage.style.transform = `translate3d(0, ${rate}px, 0)`;
      }
    }, 16); // ~60fps throttling

    window.addEventListener('scroll', handleParallax, { passive: true });
  }

  setupScrollRevealAnimations() {
    // Intersection Observer for fade + slide up animations
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
          // Stagger animations with 0.1s delay between items
          setTimeout(() => {
            entry.target.classList.add('reveal-animate');
          }, index * 100); // 0.1s stagger
          
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    // Observe menu items, feature sections, and cards
    const elementsToAnimate = document.querySelectorAll(
      '.card-menu-item, .location-card, .feature-card, .menu-item, section[id] > .container > *'
    );
    
    elementsToAnimate.forEach(el => {
      el.classList.add('reveal-hidden');
      observer.observe(el);
    });
  }

  // Lazy loading for images
  setupImageLazyLoading() {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.classList.remove('lazy');
          imageObserver.unobserve(img);
        }
      });
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
      imageObserver.observe(img);
    });
  }

  // Form validation
  setupFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
      form.addEventListener('submit', (e) => {
        if (!this.validateForm(form)) {
          e.preventDefault();
        }
      });

      // Real-time validation
      const inputs = form.querySelectorAll('input, textarea, select');
      inputs.forEach(input => {
        input.addEventListener('blur', () => this.validateField(input));
        input.addEventListener('input', () => this.clearFieldError(input));
      });
    });
  }

  validateForm(form) {
    let isValid = true;
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    
    inputs.forEach(input => {
      if (!this.validateField(input)) {
        isValid = false;
      }
    });

    return isValid;
  }

  validateField(field) {
    const value = field.value.trim();
    const type = field.type;
    let isValid = true;
    let errorMessage = '';

    // Required field validation
    if (field.hasAttribute('required') && !value) {
      isValid = false;
      errorMessage = 'This field is required';
    }

    // Email validation
    if (type === 'email' && value) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(value)) {
        isValid = false;
        errorMessage = 'Please enter a valid email address';
      }
    }

    // Phone validation
    if (type === 'tel' && value) {
      const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
      if (!phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
        isValid = false;
        errorMessage = 'Please enter a valid phone number';
      }
    }

    this.showFieldValidation(field, isValid, errorMessage);
    return isValid;
  }

  showFieldValidation(field, isValid, errorMessage) {
    const errorElement = field.parentNode.querySelector('.field-error');
    
    if (!isValid) {
      field.classList.add('error');
      if (errorElement) {
        errorElement.textContent = errorMessage;
      } else {
        const error = document.createElement('span');
        error.className = 'field-error text-red-500 text-sm mt-1';
        error.textContent = errorMessage;
        field.parentNode.appendChild(error);
      }
    } else {
      field.classList.remove('error');
      if (errorElement) {
        errorElement.remove();
      }
    }
  }

  clearFieldError(field) {
    field.classList.remove('error');
    const errorElement = field.parentNode.querySelector('.field-error');
    if (errorElement) {
      errorElement.remove();
    }
  }

  // Menu filtering functionality
  setupMenuFiltering() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const menuItems = document.querySelectorAll('.menu-item');

    filterButtons.forEach(button => {
      button.addEventListener('click', () => {
        const filter = button.dataset.filter;
        
        // Update active filter button
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        // Filter menu items with staggered animation
        menuItems.forEach((item, index) => {
          if (filter === 'all' || item.dataset.category === filter) {
            item.style.display = 'block';
            // Stagger the reveal animation
            setTimeout(() => {
              item.classList.add('reveal-animate');
            }, index * 50); // 0.05s stagger for filtering
          } else {
            item.style.display = 'none';
            item.classList.remove('reveal-animate');
          }
        });
      });
    });
  }

  // Accessibility enhancements
  setupAccessibility() {
    // Skip to main content link
    const skipLink = document.querySelector('.skip-link');
    if (skipLink) {
      skipLink.addEventListener('click', (e) => {
        e.preventDefault();
        const target = document.querySelector(skipLink.getAttribute('href'));
        if (target) {
          target.focus();
          target.scrollIntoView();
        }
      });
    }

    // Keyboard navigation for custom elements
    document.addEventListener('keydown', (e) => {
      // Escape key closes mobile menu
      if (e.key === 'Escape') {
        const navLinks = document.querySelector('.nav-links');
        const hamburger = document.querySelector('.hamburger');
        if (navLinks && navLinks.classList.contains('active')) {
          navLinks.classList.remove('active');
          if (hamburger) {
            hamburger.setAttribute('aria-expanded', 'false');
            hamburger.focus();
          }
        }
      }
    });

    // Focus management for modals and dropdowns
    this.setupFocusTrapping();
  }

  setupFocusTrapping() {
    const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
    
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        const modal = document.querySelector('.modal.active');
        if (modal) {
          const focusable = modal.querySelectorAll(focusableElements);
          const firstFocusable = focusable[0];
          const lastFocusable = focusable[focusable.length - 1];

          if (e.shiftKey) {
            if (document.activeElement === firstFocusable) {
              lastFocusable.focus();
              e.preventDefault();
            }
          } else {
            if (document.activeElement === lastFocusable) {
              firstFocusable.focus();
              e.preventDefault();
            }
          }
        }
      }
    });
  }

  // Utility methods
  static async fetchMenuData() {
    // Placeholder for menu data fetching
    // In a real application, this would fetch from an API
    return {
      toasts: [
        {
          id: 1,
          name: "Classic Avocado Toast",
          description: "Fresh avocado, lime, sea salt on artisan sourdough",
          price: 12.99,
          category: "toasts",
          image: "avocado-toast.jpg",
          dietary: ["vegetarian", "vegan"]
        },
        // More menu items...
      ]
    };
  }

  static formatPrice(price) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  }

  static debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
}

// Pixabay API integration for placeholder images
class ImageService {
  constructor() {
    this.apiKey = '50523160-a1585f1d1edc8217bd4bef1a6';
    this.baseUrl = 'https://pixabay.com/api/';
  }

  async searchImages(query, category = 'food', perPage = 20) {
    try {
      const url = `${this.baseUrl}?key=${this.apiKey}&q=${encodeURIComponent(query)}&category=${category}&per_page=${perPage}&safesearch=true&image_type=photo&min_width=640`;
      const response = await fetch(url);
      const data = await response.json();
      return data.hits || [];
    } catch (error) {
      console.error('Error fetching images:', error);
      return [];
    }
  }

  async getToastImages() {
    const queries = ['avocado toast', 'artisan bread', 'gourmet toast', 'breakfast toast'];
    const allImages = [];
    
    for (const query of queries) {
      const images = await this.searchImages(query);
      allImages.push(...images.slice(0, 5));
    }
    
    return allImages;
  }

  async getCoffeeImages() {
    const queries = ['espresso coffee', 'latte art', 'coffee beans', 'cappuccino'];
    const allImages = [];
    
    for (const query of queries) {
      const images = await this.searchImages(query);
      allImages.push(...images.slice(0, 5));
    }
    
    return allImages;
  }

  getOptimizedImageUrl(image, size = 'webformatURL') {
    // Return WebP format if available, fallback to regular format
    return image[size] || image.webformatURL || image.largeImageURL;
  }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ToastOfTheTown();
  
  // Initialize image service for dynamic content
  window.imageService = new ImageService();
});

// Export for module usage
export { ToastOfTheTown, ImageService };
