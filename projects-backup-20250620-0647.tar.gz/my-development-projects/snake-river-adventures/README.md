# Snake River Adventures - Landing Page

A modern, responsive landing page for an outdoor adventure company offering jet boat tours, helicopter tours, and other Snake River experiences.

## 🚀 Project Overview

This project showcases modern web development techniques with a focus on performance, accessibility, and user experience. Built as a portfolio-worthy example of a professional outdoor adventure company website.

## 🛠️ Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **CSS Framework**: Custom CSS with CSS Grid/Flexbox
- **Animations**: CSS animations, Intersection Observer API
- **Icons**: Lucide Icons or Feather Icons (to be added)
- **Fonts**: Google Fonts (Montserrat + Open Sans)
- **Deployment**: Static hosting ready (GitHub Pages, Netlify, or GCP)

## 🎨 Design Features

### Color Palette
- **Primary**: Deep blue (#1e40af)
- **Secondary**: Sunset orange (#f97316)
- **Accent**: Forest green (#16a34a)
- **Neutral**: Charcoal (#374151)

### Typography
- **Headings**: Montserrat (bold, modern)
- **Body**: Open Sans (readable, clean)

## 📱 Responsive Design

- **Mobile-first approach**
- **Breakpoints**: 320px, 768px, 1024px, 1440px
- **Touch-friendly buttons** (44px minimum)
- **Optimized for all devices**

## ✨ Key Features

### 🏠 Hero Section
- Full-screen gradient background (placeholder for video/image)
- Parallax scrolling effect
- Call-to-action button "Book Your Adventure"
- Company logo and tagline overlay

### 🚤 Services Section
- **Jet Boat Tours** - High-speed navigation through scenic canyons
- **Helicopter Tours** - Aerial photography and mountain views
- **Additional Adventures** - Rafting, fishing charters, sunset tours

### 🖼️ Gallery Section
- Grid layout with hover effects
- Lightbox functionality (Phase 3)
- High-quality adventure photos (placeholders)

### ℹ️ About Section
- Company story and experience
- Safety certifications
- Local expertise highlight

### 📞 Contact/Booking Section
- Interactive contact form with validation
- Phone number and location
- Social media links
- Map placeholder (to be integrated)

## 🚀 Getting Started

### Prerequisites
- Modern web browser
- Local web server (optional, for development)

### Installation

1. **Clone or download the project**
   ```bash
   git clone [repository-url]
   cd snake-river-adventures
   ```

2. **Open in browser**
   - Simply open `index.html` in your web browser
   - Or use a local server for development:
   ```bash
   # Using Python
   python -m http.server 8000
   
   # Using Node.js
   npx serve .
   
   # Using PHP
   php -S localhost:8000
   ```

3. **View the site**
   - Open http://localhost:8000 in your browser

## 📁 Project Structure

```
snake-river-adventures/
├── index.html              # Main HTML file
├── css/
│   ├── style.css          # Main stylesheet
│   └── responsive.css     # Responsive design styles
├── js/
│   ├── main.js           # Core functionality
│   └── animations.js     # Animation effects
├── images/               # Image assets
│   ├── hero/            # Hero section images
│   ├── gallery/         # Gallery images
│   ├── services/        # Service images
│   ├── about/           # About section images
│   └── icons/           # Icon assets
└── README.md            # Project documentation
```

## 🎯 Development Phases

### ✅ Phase 1: Structure & Layout (COMPLETED)
- [x] HTML semantic structure
- [x] Basic CSS layout and responsive grid
- [x] Navigation and footer
- [x] Mobile-first responsive design
- [x] Basic JavaScript functionality

### 🔄 Phase 2: Styling & Design (NEXT)
- [ ] Enhanced visual design
- [ ] Color scheme refinement
- [ ] Typography improvements
- [ ] Card components styling
- [ ] Button and form enhancements

### 🔄 Phase 3: Animations & Interactions
- [ ] Parallax scrolling implementation
- [ ] Advanced scroll animations
- [ ] Hover effects and transitions
- [ ] Gallery lightbox functionality
- [ ] Micro-interactions

### 🔄 Phase 4: Content & Polish
- [ ] Real content integration
- [ ] Image optimization (WebP format)
- [ ] Cross-browser testing
- [ ] Performance optimization
- [ ] SEO improvements

## 🌟 Features Implemented

### Navigation
- ✅ Sticky navigation with scroll effects
- ✅ Mobile hamburger menu
- ✅ Smooth scrolling to sections
- ✅ Active section highlighting

### Forms
- ✅ Contact form with validation
- ✅ Form submission handling
- ✅ Success/error messaging
- ✅ Accessible form design

### Animations
- ✅ Scroll-triggered animations
- ✅ Parallax hero background
- ✅ Button hover effects
- ✅ Loading animations
- ✅ Reduced motion support

### Accessibility
- ✅ WCAG 2.1 AA compliance focus
- ✅ Semantic HTML structure
- ✅ Keyboard navigation support
- ✅ Screen reader friendly
- ✅ Focus management

## 🔧 Customization

### Colors
Update CSS custom properties in `css/style.css`:
```css
:root {
    --primary-blue: #1e40af;
    --secondary-orange: #f97316;
    --accent-green: #16a34a;
    --neutral-charcoal: #374151;
}
```

### Content
- Edit `index.html` for text content
- Replace placeholder images in `/images/` directories
- Update contact information and social links

### Styling
- Modify `css/style.css` for design changes
- Adjust `css/responsive.css` for responsive behavior

## 📊 Performance

### Optimization Features
- ✅ Throttled scroll events
- ✅ Intersection Observer for animations
- ✅ Efficient CSS selectors
- ✅ Minimal JavaScript footprint
- ✅ Mobile-first responsive design

### Planned Optimizations (Phase 4)
- [ ] Image lazy loading
- [ ] WebP image format
- [ ] CSS/JS minification
- [ ] Critical CSS inlining
- [ ] Service worker for caching

## 🌐 Browser Support

- ✅ Chrome/Edge (last 2 versions)
- ✅ Firefox (last 2 versions)
- ✅ Safari (last 2 versions)
- ✅ Mobile Safari and Chrome Mobile

## 📝 To-Do List

### Immediate (Phase 2)
- [ ] Add real images to replace placeholders
- [ ] Implement icon system (Lucide/Feather)
- [ ] Enhance visual design consistency
- [ ] Add loading states for better UX

### Future Enhancements
- [ ] Gallery lightbox functionality
- [ ] Interactive map integration
- [ ] Blog/news section
- [ ] Customer testimonials
- [ ] Booking system integration
- [ ] Multi-language support

## 🤝 Contributing

This is a portfolio project, but suggestions and improvements are welcome:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test across browsers
5. Submit a pull request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 📞 Contact

For questions about this project:
- Email: [your-email@example.com]
- Portfolio: [your-portfolio-url]
- LinkedIn: [your-linkedin-profile]

---

**Built with ❤️ as a modern web development showcase**
