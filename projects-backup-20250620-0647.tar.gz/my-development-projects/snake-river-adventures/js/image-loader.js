// ===== ENHANCED IMAGE LOADER FOR PICSUM INTEGRATION =====

class ImageLoader {
    constructor() {
        this.cache = new Map();
        this.retryAttempts = 3;
        this.retryDelay = 1000;
        this.fallbackImages = {
            'service-1': 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjI4MCIgdmlld0JveD0iMCAwIDQwMCAyODAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iMjgwIiBmaWxsPSIjMWU0MGFmIi8+Cjx0ZXh0IHg9IjIwMCIgeT0iMTQwIiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iPkpldCBCb2F0IFRvdXJzPC90ZXh0Pgo8L3N2Zz4=',
            'service-2': 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjI4MCIgdmlld0JveD0iMCAwIDQwMCAyODAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iMjgwIiBmaWxsPSIjZjk3MzE2Ii8+Cjx0ZXh0IHg9IjIwMCIgeT0iMTQwIiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iPkhlbGljb3B0ZXIgVG91cnM8L3RleHQ+Cjwvc3ZnPg==',
            'service-3': 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjI4MCIgdmlld0JveD0iMCAwIDQwMCAyODAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iMjgwIiBmaWxsPSIjMTZhMzRhIi8+Cjx0ZXh0IHg9IjIwMCIgeT0iMTQwIiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iPkFkdmVudHVyZSBUb3VyczwvdGV4dD4KPHN2Zz4=',
            'gallery': 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzUwIiBoZWlnaHQ9IjM1MCIgdmlld0JveD0iMCAwIDM1MCAzNTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzNTAiIGhlaWdodD0iMzUwIiBmaWxsPSIjMzc0MTUxIi8+Cjx0ZXh0IHg9IjE3NSIgeT0iMTc1IiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE2IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iPkdhbGxlcnkgSW1hZ2U8L3RleHQ+Cjwvc3ZnPg==',
            'about': 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAwIiBoZWlnaHQ9IjQwMCIgdmlld0JveD0iMCAwIDUwMCA0MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI1MDAiIGhlaWdodD0iNDAwIiBmaWxsPSIjMWU0MGFmIi8+Cjx0ZXh0IHg9IjI1MCIgeT0iMjAwIiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iPk91ciBUZWFtPC90ZXh0Pgo8L3N2Zz4='
        };
        this.loadingIndicator = this.createLoadingIndicator();
    }

    createLoadingIndicator() {
        return 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMTgiIHN0cm9rZT0iIzFlNDBhZiIgc3Ryb2tlLXdpZHRoPSI0IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1kYXNoYXJyYXk9IjI4LjI3IDI4LjI3IiBvcGFjaXR5PSIwLjMiPgogIDxhbmltYXRlVHJhbnNmb3JtIGF0dHJpYnV0ZU5hbWU9InRyYW5zZm9ybSIgdHlwZT0icm90YXRlIiB2YWx1ZXM9IjAgMjAgMjA7MzYwIDIwIDIwIiBkdXI9IjJzIiByZXBlYXRDb3VudD0iaW5kZWZpbml0ZSIvPgo8L2NpcmNsZT4KPHN2Zz4=';
    }

    async loadImage(url, fallbackType = 'gallery', retryCount = 0) {
        // Check cache first
        if (this.cache.has(url)) {
            return this.cache.get(url);
        }

        try {
            const response = await this.fetchWithTimeout(url, 5000);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const blob = await response.blob();
            const imageUrl = URL.createObjectURL(blob);
            
            // Cache the successful result
            this.cache.set(url, imageUrl);
            return imageUrl;

        } catch (error) {
            console.warn(`Image load attempt ${retryCount + 1} failed for ${url}:`, error.message);
            
            // Retry logic
            if (retryCount < this.retryAttempts) {
                await this.delay(this.retryDelay * (retryCount + 1));
                return this.loadImage(url, fallbackType, retryCount + 1);
            }
            
            // Return fallback after all retries exhausted
            console.error(`All retry attempts failed for ${url}, using fallback`);
            return this.fallbackImages[fallbackType] || this.fallbackImages.gallery;
        }
    }

    async fetchWithTimeout(url, timeout) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        
        try {
            const response = await fetch(url, {
                signal: controller.signal,
                cache: 'force-cache'
            });
            clearTimeout(timeoutId);
            return response;
        } catch (error) {
            clearTimeout(timeoutId);
            throw error;
        }
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async loadImageWithProgress(imgElement, url, fallbackType = 'gallery') {
        // Show loading indicator
        const originalSrc = imgElement.src;
        imgElement.src = this.loadingIndicator;
        imgElement.style.opacity = '0.7';
        
        // Add loading class for styling
        imgElement.classList.add('loading');
        
        try {
            const imageUrl = await this.loadImage(url, fallbackType);
            
            // Create a new image to preload
            const tempImg = new Image();
            tempImg.onload = () => {
                imgElement.src = imageUrl;
                imgElement.style.opacity = '1';
                imgElement.classList.remove('loading');
                imgElement.classList.add('loaded');
            };
            tempImg.onerror = () => {
                imgElement.src = this.fallbackImages[fallbackType] || this.fallbackImages.gallery;
                imgElement.style.opacity = '1';
                imgElement.classList.remove('loading');
                imgElement.classList.add('fallback');
            };
            tempImg.src = imageUrl;
            
        } catch (error) {
            console.error('Failed to load image:', error);
            imgElement.src = this.fallbackImages[fallbackType] || this.fallbackImages.gallery;
            imgElement.style.opacity = '1';
            imgElement.classList.remove('loading');
            imgElement.classList.add('fallback');
        }
    }

    // Batch load multiple images
    async loadImages(imageConfigs) {
        const promises = imageConfigs.map(config => 
            this.loadImage(config.url, config.fallbackType)
        );
        
        try {
            const results = await Promise.allSettled(promises);
            return results.map((result, index) => ({
                ...imageConfigs[index],
                success: result.status === 'fulfilled',
                imageUrl: result.status === 'fulfilled' ? result.value : this.fallbackImages[imageConfigs[index].fallbackType]
            }));
        } catch (error) {
            console.error('Batch image loading failed:', error);
            return imageConfigs.map(config => ({
                ...config,
                success: false,
                imageUrl: this.fallbackImages[config.fallbackType]
            }));
        }
    }

    // Initialize all images on the page
    initializePageImages() {
        const imageConfigs = [
            // Service images
            { selector: '.service-card:nth-child(1) img', url: 'https://picsum.photos/400/280?random=1', fallbackType: 'service-1' },
            { selector: '.service-card:nth-child(2) img', url: 'https://picsum.photos/400/280?random=2', fallbackType: 'service-2' },
            { selector: '.service-card:nth-child(3) img', url: 'https://picsum.photos/400/280?random=3', fallbackType: 'service-3' },
            
            // Gallery images
            { selector: '.gallery-item:nth-child(1) img', url: 'https://picsum.photos/350/350?random=4', fallbackType: 'gallery' },
            { selector: '.gallery-item:nth-child(2) img', url: 'https://picsum.photos/350/350?random=5', fallbackType: 'gallery' },
            { selector: '.gallery-item:nth-child(3) img', url: 'https://picsum.photos/350/350?random=6', fallbackType: 'gallery' },
            { selector: '.gallery-item:nth-child(4) img', url: 'https://picsum.photos/350/350?random=7', fallbackType: 'gallery' },
            { selector: '.gallery-item:nth-child(5) img', url: 'https://picsum.photos/350/350?random=8', fallbackType: 'gallery' },
            { selector: '.gallery-item:nth-child(6) img', url: 'https://picsum.photos/350/350?random=9', fallbackType: 'gallery' },
            
            // About image
            { selector: '.about-image img', url: 'https://picsum.photos/500/400?random=10', fallbackType: 'about' }
        ];

        imageConfigs.forEach(config => {
            const imgElement = document.querySelector(config.selector);
            if (imgElement) {
                this.loadImageWithProgress(imgElement, config.url, config.fallbackType);
            }
        });
    }

    // Lazy loading implementation
    initializeLazyLoading() {
        const lazyImages = document.querySelectorAll('img[data-src]');
        
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        const src = img.getAttribute('data-src');
                        const fallbackType = img.getAttribute('data-fallback') || 'gallery';
                        
                        this.loadImageWithProgress(img, src, fallbackType);
                        img.removeAttribute('data-src');
                        imageObserver.unobserve(img);
                    }
                });
            });

            lazyImages.forEach(img => imageObserver.observe(img));
        } else {
            // Fallback for browsers without IntersectionObserver
            lazyImages.forEach(img => {
                const src = img.getAttribute('data-src');
                const fallbackType = img.getAttribute('data-fallback') || 'gallery';
                this.loadImageWithProgress(img, src, fallbackType);
                img.removeAttribute('data-src');
            });
        }
    }

    // Preload critical images
    preloadCriticalImages() {
        const criticalImages = [
            'https://picsum.photos/400/280?random=1',
            'https://picsum.photos/400/280?random=2',
            'https://picsum.photos/400/280?random=3'
        ];

        criticalImages.forEach(url => {
            this.loadImage(url, 'service-1');
        });
    }

    // Clean up blob URLs to prevent memory leaks
    cleanup() {
        this.cache.forEach(url => {
            if (url.startsWith('blob:')) {
                URL.revokeObjectURL(url);
            }
        });
        this.cache.clear();
    }
}

// Global instance
window.imageLoader = new ImageLoader();

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Preload critical images first
    window.imageLoader.preloadCriticalImages();
    
    // Initialize all page images
    setTimeout(() => {
        window.imageLoader.initializePageImages();
        window.imageLoader.initializeLazyLoading();
    }, 100);
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    window.imageLoader.cleanup();
});

// Export for use in other scripts
window.ImageLoader = ImageLoader;
