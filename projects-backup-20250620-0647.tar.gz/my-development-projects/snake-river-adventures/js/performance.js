// ===== PERFORMANCE OPTIMIZATION SCRIPT - PHASE 4 =====

class PerformanceOptimizer {
    constructor() {
        this.metrics = {
            loadTime: 0,
            firstContentfulPaint: 0,
            largestContentfulPaint: 0,
            cumulativeLayoutShift: 0,
            firstInputDelay: 0
        };
        this.resourceHints = [];
        this.criticalResources = [];
        this.init();
    }

    init() {
        this.measurePerformance();
        this.optimizeImages();
        this.preloadCriticalResources();
        this.implementServiceWorker();
        this.optimizeScrollPerformance();
        this.monitorWebVitals();
    }

    // ===== PERFORMANCE MEASUREMENT =====
    measurePerformance() {
        // Wait for page load to complete
        window.addEventListener('load', () => {
            setTimeout(() => {
                this.collectMetrics();
                this.reportMetrics();
            }, 100);
        });
    }

    collectMetrics() {
        // Navigation timing
        const navigation = performance.getEntriesByType('navigation')[0];
        if (navigation) {
            this.metrics.loadTime = navigation.loadEventEnd - navigation.fetchStart;
        }

        // Paint timing
        const paintEntries = performance.getEntriesByType('paint');
        paintEntries.forEach(entry => {
            if (entry.name === 'first-contentful-paint') {
                this.metrics.firstContentfulPaint = entry.startTime;
            }
        });

        // Largest Contentful Paint
        if ('PerformanceObserver' in window) {
            const lcpObserver = new PerformanceObserver((list) => {
                const entries = list.getEntries();
                const lastEntry = entries[entries.length - 1];
                this.metrics.largestContentfulPaint = lastEntry.startTime;
            });
            lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
        }

        // Resource timing
        const resources = performance.getEntriesByType('resource');
        this.analyzeResourceTiming(resources);
    }

    analyzeResourceTiming(resources) {
        const slowResources = resources.filter(resource => 
            resource.duration > 1000 // Resources taking more than 1 second
        );

        if (slowResources.length > 0) {
            console.warn('Slow loading resources detected:', slowResources);
            this.optimizeSlowResources(slowResources);
        }
    }

    optimizeSlowResources(resources) {
        resources.forEach(resource => {
            if (resource.name.includes('picsum.photos')) {
                console.log('Optimizing picsum image:', resource.name);
                // Already handled by our image loader
            }
        });
    }

    reportMetrics() {
        console.group('🚀 Performance Metrics');
        console.log(`Load Time: ${this.metrics.loadTime.toFixed(2)}ms`);
        console.log(`First Contentful Paint: ${this.metrics.firstContentfulPaint.toFixed(2)}ms`);
        console.log(`Largest Contentful Paint: ${this.metrics.largestContentfulPaint.toFixed(2)}ms`);
        console.groupEnd();

        // Performance scoring
        this.calculatePerformanceScore();
    }

    calculatePerformanceScore() {
        let score = 100;
        
        // Deduct points for slow metrics
        if (this.metrics.loadTime > 3000) score -= 20;
        if (this.metrics.firstContentfulPaint > 1800) score -= 15;
        if (this.metrics.largestContentfulPaint > 2500) score -= 15;

        const grade = score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 70 ? 'C' : 'D';
        console.log(`📊 Performance Score: ${score}/100 (Grade: ${grade})`);
    }

    // ===== IMAGE OPTIMIZATION =====
    optimizeImages() {
        // Add WebP support detection
        this.detectWebPSupport();
        
        // Implement lazy loading for below-fold images
        this.implementLazyLoading();
        
        // Optimize image sizes based on viewport
        this.implementResponsiveImages();
    }

    detectWebPSupport() {
        const webP = new Image();
        webP.onload = webP.onerror = () => {
            const isSupported = webP.height === 2;
            document.documentElement.classList.toggle('webp-support', isSupported);
            console.log(`WebP Support: ${isSupported ? 'Yes' : 'No'}`);
        };
        webP.src = 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA';
    }

    implementLazyLoading() {
        // Enhanced lazy loading with intersection observer
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        this.loadImageOptimized(img);
                        observer.unobserve(img);
                    }
                });
            }, {
                rootMargin: '50px 0px',
                threshold: 0.01
            });

            // Observe images that are not in the initial viewport
            const lazyImages = document.querySelectorAll('img[data-src]');
            lazyImages.forEach(img => imageObserver.observe(img));
        }
    }

    loadImageOptimized(img) {
        const src = img.getAttribute('data-src');
        if (src) {
            // Use our enhanced image loader
            if (window.imageLoader) {
                const fallbackType = img.getAttribute('data-fallback') || 'gallery';
                window.imageLoader.loadImageWithProgress(img, src, fallbackType);
            } else {
                img.src = src;
            }
            img.removeAttribute('data-src');
        }
    }

    implementResponsiveImages() {
        // Add srcset for different screen densities
        const images = document.querySelectorAll('img[src*="picsum.photos"]');
        images.forEach(img => {
            const src = img.src;
            const url = new URL(src);
            const width = url.pathname.split('/')[1] || '400';
            const height = url.pathname.split('/')[2] || '300';
            
            // Create responsive srcset
            const srcset = [
                `${src} 1x`,
                `${src.replace(`/${width}/${height}`, `/${width * 2}/${height * 2}`)} 2x`
            ].join(', ');
            
            img.setAttribute('srcset', srcset);
        });
    }

    // ===== RESOURCE PRELOADING =====
    preloadCriticalResources() {
        this.criticalResources = [
            { href: 'css/style.css', as: 'style' },
            { href: 'css/responsive.css', as: 'style' },
            { href: 'js/main.js', as: 'script' },
            { href: 'js/animations.js', as: 'script' },
            { href: 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;500;600&display=swap', as: 'style' }
        ];

        this.criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = resource.href;
            link.as = resource.as;
            if (resource.as === 'style') {
                link.onload = () => {
                    link.rel = 'stylesheet';
                };
            }
            document.head.appendChild(link);
        });
    }

    // ===== SERVICE WORKER =====
    implementServiceWorker() {
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                this.registerServiceWorker();
            });
        }
    }

    async registerServiceWorker() {
        try {
            // Create service worker content
            const swContent = this.generateServiceWorkerContent();
            const blob = new Blob([swContent], { type: 'application/javascript' });
            const swUrl = URL.createObjectURL(blob);
            
            const registration = await navigator.serviceWorker.register(swUrl);
            console.log('Service Worker registered:', registration);
            
            // Clean up blob URL
            URL.revokeObjectURL(swUrl);
        } catch (error) {
            console.log('Service Worker registration failed:', error);
        }
    }

    generateServiceWorkerContent() {
        return `
            const CACHE_NAME = 'snake-river-adventures-v1';
            const urlsToCache = [
                '/',
                '/css/style.css',
                '/css/responsive.css',
                '/js/main.js',
                '/js/animations.js',
                '/js/image-loader.js',
                '/js/performance.js'
            ];

            self.addEventListener('install', event => {
                event.waitUntil(
                    caches.open(CACHE_NAME)
                        .then(cache => cache.addAll(urlsToCache))
                );
            });

            self.addEventListener('fetch', event => {
                event.respondWith(
                    caches.match(event.request)
                        .then(response => {
                            if (response) {
                                return response;
                            }
                            return fetch(event.request);
                        })
                );
            });
        `;
    }

    // ===== SCROLL OPTIMIZATION =====
    optimizeScrollPerformance() {
        // Throttle scroll events
        let ticking = false;
        
        const optimizedScrollHandler = () => {
            if (!ticking) {
                requestAnimationFrame(() => {
                    this.handleOptimizedScroll();
                    ticking = false;
                });
                ticking = true;
            }
        };

        window.addEventListener('scroll', optimizedScrollHandler, { passive: true });
    }

    handleOptimizedScroll() {
        // Batch DOM reads and writes
        const scrollY = window.pageYOffset;
        const windowHeight = window.innerHeight;
        
        // Update navbar
        const navbar = document.getElementById('navbar');
        if (navbar) {
            navbar.classList.toggle('scrolled', scrollY > 100);
        }

        // Update scroll progress
        const progressBar = document.querySelector('.scroll-progress');
        if (progressBar) {
            const docHeight = document.documentElement.scrollHeight - windowHeight;
            const scrollPercent = (scrollY / docHeight) * 100;
            progressBar.style.width = `${Math.min(scrollPercent, 100)}%`;
        }
    }

    // ===== WEB VITALS MONITORING =====
    monitorWebVitals() {
        // Monitor Cumulative Layout Shift
        if ('PerformanceObserver' in window) {
            const clsObserver = new PerformanceObserver((list) => {
                let clsValue = 0;
                for (const entry of list.getEntries()) {
                    if (!entry.hadRecentInput) {
                        clsValue += entry.value;
                    }
                }
                this.metrics.cumulativeLayoutShift = clsValue;
                
                if (clsValue > 0.1) {
                    console.warn('High Cumulative Layout Shift detected:', clsValue);
                }
            });
            clsObserver.observe({ entryTypes: ['layout-shift'] });

            // Monitor First Input Delay
            const fidObserver = new PerformanceObserver((list) => {
                for (const entry of list.getEntries()) {
                    this.metrics.firstInputDelay = entry.processingStart - entry.startTime;
                    console.log('First Input Delay:', this.metrics.firstInputDelay);
                }
            });
            fidObserver.observe({ entryTypes: ['first-input'] });
        }
    }

    // ===== CRITICAL CSS INLINING =====
    inlineCriticalCSS() {
        // Extract and inline critical CSS for above-the-fold content
        const criticalCSS = `
            /* Critical CSS for above-the-fold content */
            .navbar { position: fixed; top: 0; width: 100%; z-index: 1000; }
            .hero { height: 100vh; display: flex; align-items: center; justify-content: center; }
            .hero-title { font-size: 3.5rem; margin-bottom: 1.5rem; }
            .hero-cta { display: inline-block; padding: 1rem 2.5rem; border-radius: 50px; }
        `;

        const style = document.createElement('style');
        style.textContent = criticalCSS;
        document.head.insertBefore(style, document.head.firstChild);
    }

    // ===== RESOURCE HINTS =====
    addResourceHints() {
        const hints = [
            { rel: 'dns-prefetch', href: '//fonts.googleapis.com' },
            { rel: 'dns-prefetch', href: '//fonts.gstatic.com' },
            { rel: 'dns-prefetch', href: '//picsum.photos' },
            { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
            { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: true }
        ];

        hints.forEach(hint => {
            const link = document.createElement('link');
            link.rel = hint.rel;
            link.href = hint.href;
            if (hint.crossorigin) link.crossOrigin = hint.crossorigin;
            document.head.appendChild(link);
        });
    }

    // ===== MEMORY OPTIMIZATION =====
    optimizeMemoryUsage() {
        // Clean up event listeners on page unload
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });

        // Monitor memory usage
        if ('memory' in performance) {
            setInterval(() => {
                const memory = performance.memory;
                if (memory.usedJSHeapSize > memory.jsHeapSizeLimit * 0.9) {
                    console.warn('High memory usage detected');
                    this.triggerGarbageCollection();
                }
            }, 30000); // Check every 30 seconds
        }
    }

    triggerGarbageCollection() {
        // Force garbage collection if possible
        if (window.gc) {
            window.gc();
        }
        
        // Clean up image cache
        if (window.imageLoader) {
            window.imageLoader.cleanup();
        }
    }

    cleanup() {
        // Clean up observers and event listeners
        console.log('Cleaning up performance optimizer...');
        
        // Clean up image loader
        if (window.imageLoader) {
            window.imageLoader.cleanup();
        }
    }

    // ===== PERFORMANCE REPORTING =====
    generatePerformanceReport() {
        const report = {
            timestamp: new Date().toISOString(),
            metrics: this.metrics,
            userAgent: navigator.userAgent,
            connection: navigator.connection ? {
                effectiveType: navigator.connection.effectiveType,
                downlink: navigator.connection.downlink,
                rtt: navigator.connection.rtt
            } : null,
            recommendations: this.generateRecommendations()
        };

        console.log('📊 Performance Report:', report);
        return report;
    }

    generateRecommendations() {
        const recommendations = [];

        if (this.metrics.loadTime > 3000) {
            recommendations.push('Consider optimizing images and reducing bundle size');
        }

        if (this.metrics.firstContentfulPaint > 1800) {
            recommendations.push('Optimize critical rendering path');
        }

        if (this.metrics.cumulativeLayoutShift > 0.1) {
            recommendations.push('Reduce layout shifts by setting image dimensions');
        }

        return recommendations;
    }
}

// Initialize performance optimizer
const performanceOptimizer = new PerformanceOptimizer();

// Export for use in other scripts
window.PerformanceOptimizer = PerformanceOptimizer;
window.performanceOptimizer = performanceOptimizer;

// Add performance monitoring to console
console.log('🚀 Performance Optimizer initialized');
