// ===== ENHANCED ANIMATIONS JAVASCRIPT FILE =====

// Enhanced animation configuration
const ANIMATION_CONFIG = {
    duration: 600,
    easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px',
    staggerDelay: 100,
    bounceEasing: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)'
};

// ===== ENHANCED COUNTER ANIMATIONS =====
function initCounterAnimations() {
    const counters = document.querySelectorAll('[data-counter]');
    
    if (counters.length > 0) {
        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    counterObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.7 });
        
        counters.forEach(counter => {
            counterObserver.observe(counter);
        });
    }
}

// Enhanced counter animation with easing
function animateCounter(element) {
    const target = parseInt(element.getAttribute('data-counter'));
    const duration = 2500;
    const startTime = performance.now();
    
    function updateCounter(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for smooth animation
        const easeOutCubic = 1 - Math.pow(1 - progress, 3);
        const current = Math.floor(target * easeOutCubic);
        
        // Format number with commas for large numbers
        element.textContent = current.toLocaleString();
        
        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        } else {
            // Add completion effect
            element.style.transform = 'scale(1.1)';
            element.style.color = 'var(--secondary-orange)';
            setTimeout(() => {
                element.style.transform = 'scale(1)';
                element.style.color = 'var(--primary-blue)';
            }, 300);
        }
    }
    
    requestAnimationFrame(updateCounter);
}

// ===== ADVANCED SCROLL ANIMATIONS WITH INTERSECTION OBSERVER =====
function initScrollAnimations() {
    // Enhanced fade-in animations
    const fadeInObserver = new IntersectionObserver(handleFadeInAnimation, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    // Slide-in animations from different directions
    const slideInObserver = new IntersectionObserver(handleSlideInAnimation, {
        threshold: 0.2,
        rootMargin: '0px 0px -100px 0px'
    });

    // Scale and rotate animations
    const scaleInObserver = new IntersectionObserver(handleScaleInAnimation, {
        threshold: 0.15,
        rootMargin: '0px 0px -75px 0px'
    });

    // Staggered animations for groups
    const staggerObserver = new IntersectionObserver(handleStaggerAnimation, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    // Apply fade-in to headers and text content
    const fadeElements = document.querySelectorAll('.section-header, .about-story, .contact-info');
    fadeElements.forEach((element, index) => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = `opacity 800ms ${ANIMATION_CONFIG.easing}, transform 800ms ${ANIMATION_CONFIG.easing}`;
        element.style.transitionDelay = `${index * 150}ms`;
        fadeInObserver.observe(element);
    });

    // Apply slide-in to cards and content blocks
    const slideElements = document.querySelectorAll('.service-card, .about-certifications, .about-expertise');
    slideElements.forEach((element, index) => {
        const direction = index % 2 === 0 ? -50 : 50; // Alternate directions
        element.style.opacity = '0';
        element.style.transform = `translateX(${direction}px) rotateY(${direction > 0 ? 5 : -5}deg)`;
        element.style.transition = `opacity 700ms ${ANIMATION_CONFIG.easing}, transform 700ms ${ANIMATION_CONFIG.easing}`;
        element.style.transitionDelay = `${index * 200}ms`;
        slideInObserver.observe(element);
    });

    // Apply scale-in to gallery items and stats
    const scaleElements = document.querySelectorAll('.gallery-item, .stat-item');
    scaleElements.forEach((element, index) => {
        element.style.opacity = '0';
        element.style.transform = 'scale(0.8) rotateZ(-5deg)';
        element.style.transition = `opacity 600ms ${ANIMATION_CONFIG.easing}, transform 600ms ${ANIMATION_CONFIG.bounceEasing}`;
        element.style.transitionDelay = `${index * 100}ms`;
        scaleInObserver.observe(element);
    });

    // Apply staggered animations to feature lists
    const staggerElements = document.querySelectorAll('.service-features, .about-certifications ul');
    staggerElements.forEach(element => {
        staggerObserver.observe(element);
    });
}

// Enhanced animation handlers
function handleFadeInAnimation(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            entry.target.classList.add('animated-fade-in');
        }
    });
}

function handleSlideInAnimation(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateX(0) rotateY(0)';
            entry.target.classList.add('animated-slide-in');
        }
    });
}

function handleScaleInAnimation(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'scale(1) rotateZ(0)';
            entry.target.classList.add('animated-scale-in');
        }
    });
}

function handleStaggerAnimation(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const children = entry.target.children;
            Array.from(children).forEach((child, index) => {
                child.style.opacity = '0';
                child.style.transform = 'translateY(20px)';
                child.style.transition = `opacity 500ms ${ANIMATION_CONFIG.easing}, transform 500ms ${ANIMATION_CONFIG.easing}`;
                
                setTimeout(() => {
                    child.style.opacity = '1';
                    child.style.transform = 'translateY(0)';
                }, index * 100);
            });
        }
    });
}

// ===== ENHANCED PARALLAX EFFECTS =====
function initAdvancedParallaxEffect() {
    const heroBackground = document.querySelector('.hero-background');
    let ticking = false;

    function updateParallax() {
        const scrolled = window.pageYOffset;
        
        // Hero background parallax
        if (heroBackground) {
            const rate = scrolled * -0.5;
            const opacity = Math.max(0.3, 1 - scrolled / (window.innerHeight * 1.2));
            heroBackground.style.transform = `translateY(${rate}px)`;
            heroBackground.style.opacity = opacity;
        }

        ticking = false;
    }

    function requestParallaxUpdate() {
        if (!ticking) {
            requestAnimationFrame(updateParallax);
            ticking = true;
        }
    }

    window.addEventListener('scroll', requestParallaxUpdate, { passive: true });
}

// ===== ENHANCED GALLERY LIGHTBOX =====
function initGalleryLightbox() {
    const galleryItems = document.querySelectorAll('.gallery-item');
    
    if (galleryItems.length === 0) return;
    
    // Create enhanced lightbox HTML
    const lightboxHTML = `
        <div id="lightbox" class="lightbox">
            <div class="lightbox-overlay"></div>
            <div class="lightbox-content">
                <img class="lightbox-image" src="" alt="">
                <div class="lightbox-caption"></div>
                <button class="lightbox-close" aria-label="Close lightbox">&times;</button>
                <button class="lightbox-prev" aria-label="Previous image">&#8249;</button>
                <button class="lightbox-next" aria-label="Next image">&#8250;</button>
                <div class="lightbox-counter">
                    <span class="current">1</span> / <span class="total">${galleryItems.length}</span>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', lightboxHTML);
    
    // Enhanced lightbox styles
    const lightboxStyles = `
        <style id="lightbox-styles">
            .lightbox {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 10000;
                display: none;
                align-items: center;
                justify-content: center;
                opacity: 0;
                transition: opacity 400ms cubic-bezier(0.4, 0, 0.2, 1);
                backdrop-filter: blur(0px);
            }
            
            .lightbox.active {
                display: flex;
                opacity: 1;
                backdrop-filter: blur(20px);
            }
            
            .lightbox-overlay {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.9);
                transition: background 400ms ease;
            }
            
            .lightbox-content {
                position: relative;
                max-width: 90vw;
                max-height: 90vh;
                display: flex;
                flex-direction: column;
                align-items: center;
                z-index: 1;
            }
            
            .lightbox-image {
                max-width: 100%;
                max-height: 80vh;
                object-fit: contain;
                border-radius: 12px;
                box-shadow: 0 25px 80px rgba(0, 0, 0, 0.6);
                transform: scale(0.8) rotateY(10deg);
                transition: transform 500ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
                filter: brightness(0.8);
            }
            
            .lightbox.active .lightbox-image {
                transform: scale(1) rotateY(0);
                filter: brightness(1);
            }
            
            .lightbox-caption {
                color: white;
                font-size: 1.2rem;
                font-weight: 600;
                margin-top: 1.5rem;
                text-align: center;
                text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.8);
                opacity: 0;
                transform: translateY(20px);
                transition: opacity 400ms ease 200ms, transform 400ms ease 200ms;
            }
            
            .lightbox.active .lightbox-caption {
                opacity: 1;
                transform: translateY(0);
            }
            
            .lightbox-counter {
                position: absolute;
                bottom: 20px;
                left: 50%;
                transform: translateX(-50%);
                color: white;
                background: rgba(0, 0, 0, 0.5);
                padding: 8px 16px;
                border-radius: 20px;
                font-size: 0.9rem;
                backdrop-filter: blur(10px);
            }
            
            .lightbox-close,
            .lightbox-prev,
            .lightbox-next {
                position: absolute;
                background: rgba(255, 255, 255, 0.1);
                border: none;
                color: white;
                font-size: 2rem;
                font-weight: bold;
                cursor: pointer;
                padding: 12px 16px;
                border-radius: 50%;
                transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
                backdrop-filter: blur(10px);
                opacity: 0.8;
            }
            
            .lightbox-close {
                top: 20px;
                right: 20px;
                font-size: 2.5rem;
                padding: 8px 14px;
            }
            
            .lightbox-prev {
                left: 20px;
                top: 50%;
                transform: translateY(-50%);
            }
            
            .lightbox-next {
                right: 20px;
                top: 50%;
                transform: translateY(-50%);
            }
            
            .lightbox-close:hover,
            .lightbox-prev:hover,
            .lightbox-next:hover {
                background: rgba(255, 255, 255, 0.2);
                opacity: 1;
                transform: scale(1.1);
            }
            
            .lightbox-prev:hover {
                transform: translateY(-50%) scale(1.1);
            }
            
            .lightbox-next:hover {
                transform: translateY(-50%) scale(1.1);
            }
            
            @media (max-width: 768px) {
                .lightbox-prev,
                .lightbox-next {
                    font-size: 1.5rem;
                    padding: 10px 14px;
                }
                
                .lightbox-close {
                    font-size: 2rem;
                    top: 10px;
                    right: 10px;
                }
                
                .lightbox-counter {
                    bottom: 10px;
                    font-size: 0.8rem;
                }
            }
        </style>
    `;
    
    document.head.insertAdjacentHTML('beforeend', lightboxStyles);
    
    // Enhanced lightbox functionality
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = lightbox.querySelector('.lightbox-image');
    const lightboxCaption = lightbox.querySelector('.lightbox-caption');
    const closeBtn = lightbox.querySelector('.lightbox-close');
    const prevBtn = lightbox.querySelector('.lightbox-prev');
    const nextBtn = lightbox.querySelector('.lightbox-next');
    const currentCounter = lightbox.querySelector('.current');
    
    let currentImageIndex = 0;
    const images = Array.from(galleryItems);
    
    // Open lightbox with enhanced animations
    galleryItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            currentImageIndex = index;
            openLightbox();
        });
    });
    
    function openLightbox() {
        const currentItem = images[currentImageIndex];
        const img = currentItem.querySelector('img');
        const caption = currentItem.querySelector('.gallery-caption');
        
        lightboxImage.src = img.src;
        lightboxImage.alt = img.alt;
        lightboxCaption.textContent = caption ? caption.textContent : '';
        currentCounter.textContent = currentImageIndex + 1;
        
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Add keyboard navigation
        document.addEventListener('keydown', handleKeyNavigation);
    }
    
    function closeLightbox() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
        document.removeEventListener('keydown', handleKeyNavigation);
    }
    
    function showPrevImage() {
        currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
        updateLightboxImage();
    }
    
    function showNextImage() {
        currentImageIndex = (currentImageIndex + 1) % images.length;
        updateLightboxImage();
    }
    
    function updateLightboxImage() {
        const currentItem = images[currentImageIndex];
        const img = currentItem.querySelector('img');
        const caption = currentItem.querySelector('.gallery-caption');
        
        // Animate out
        lightboxImage.style.transform = 'scale(0.8) rotateY(-10deg)';
        lightboxImage.style.opacity = '0.5';
        
        setTimeout(() => {
            lightboxImage.src = img.src;
            lightboxImage.alt = img.alt;
            lightboxCaption.textContent = caption ? caption.textContent : '';
            currentCounter.textContent = currentImageIndex + 1;
            
            // Animate in
            lightboxImage.style.transform = 'scale(1) rotateY(0)';
            lightboxImage.style.opacity = '1';
        }, 200);
    }
    
    function handleKeyNavigation(e) {
        switch(e.key) {
            case 'Escape':
                closeLightbox();
                break;
            case 'ArrowLeft':
                showPrevImage();
                break;
            case 'ArrowRight':
                showNextImage();
                break;
        }
    }
    
    // Event listeners
    closeBtn.addEventListener('click', closeLightbox);
    prevBtn.addEventListener('click', showPrevImage);
    nextBtn.addEventListener('click', showNextImage);
    lightbox.querySelector('.lightbox-overlay').addEventListener('click', closeLightbox);
    
    // Touch/swipe support for mobile
    let startX = 0;
    let endX = 0;
    
    lightbox.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
    });
    
    lightbox.addEventListener('touchend', (e) => {
        endX = e.changedTouches[0].clientX;
        const diff = startX - endX;
        
        if (Math.abs(diff) > 50) { // Minimum swipe distance
            if (diff > 0) {
                showNextImage();
            } else {
                showPrevImage();
            }
        }
    });
}

// ===== ENHANCED MICRO-INTERACTIONS =====
function initMicroInteractions() {
    initFloatingElements();
    initMagneticButtons();
    initInteractiveHovers();
    initRippleEffects();
}

function initFloatingElements() {
    const floatingElements = document.querySelectorAll('.service-card, .gallery-item');
    
    floatingElements.forEach(element => {
        element.addEventListener('mousemove', (e) => {
            const rect = element.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;
            
            element.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(20px)`;
            element.style.boxShadow = `${(centerX - x) / 10}px ${(centerY - y) / 10}px 30px rgba(0, 0, 0, 0.2)`;
        });
        
        element.addEventListener('mouseleave', () => {
            element.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
            element.style.boxShadow = '';
        });
    });
}

function initMagneticButtons() {
    const magneticButtons = document.querySelectorAll('.hero-cta, .service-cta, .form-submit');
    
    magneticButtons.forEach(button => {
        button.addEventListener('mousemove', (e) => {
            const rect = button.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            
            const distance = Math.sqrt(x * x + y * y);
            const maxDistance = 60;
            
            if (distance < maxDistance) {
                const strength = (maxDistance - distance) / maxDistance;
                const moveX = x * strength * 0.3;
                const moveY = y * strength * 0.3;
                
                button.style.transform = `translate(${moveX}px, ${moveY}px) scale(1.05)`;
                button.style.boxShadow = `${moveX}px ${moveY + 10}px 25px rgba(0, 0, 0, 0.2)`;
            }
        });
        
        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translate(0, 0) scale(1)';
            button.style.boxShadow = '';
        });
    });
}

function initInteractiveHovers() {
    // Enhanced social links
    const socialLinks = document.querySelectorAll('.social-links a, .footer-social a');
    
    socialLinks.forEach(link => {
        link.addEventListener('mouseenter', () => {
            link.style.transform = 'translateY(-5px) rotate(5deg) scale(1.1)';
            link.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.3)';
            link.style.filter = 'brightness(1.2)';
        });
        
        link.addEventListener('mouseleave', () => {
            link.style.transform = 'translateY(0) rotate(0) scale(1)';
            link.style.boxShadow = '';
            link.style.filter = '';
        });
    });
    
    // Enhanced navigation links
    const navLinks = document.querySelectorAll('.nav-link:not(.cta-button)');
    
    navLinks.forEach(link => {
        link.addEventListener('mouseenter', () => {
            link.style.transform = 'translateY(-3px) scale(1.05)';
            link.style.textShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
        });
        
        link.addEventListener('mouseleave', () => {
            link.style.transform = 'translateY(0) scale(1)';
            link.style.textShadow = '';
        });
    });
}

function initRippleEffects() {
    const rippleElements = document.querySelectorAll('.btn, .service-cta, .hero-cta, .nav-link');
    
    rippleElements.forEach(element => {
        element.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                background: radial-gradient(circle, rgba(255, 255, 255, 0.6) 0%, transparent 70%);
                border-radius: 50%;
                transform: scale(0);
                animation: ripple 0.8s cubic-bezier(0.4, 0, 0.2, 1);
                pointer-events: none;
                z-index: 1;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 800);
        });
    });

    // Add enhanced ripple animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            0% {
                transform: scale(0);
                opacity: 1;
            }
            50% {
                opacity: 0.5;
            }
            100% {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// ===== ENHANCED SCROLL EFFECTS =====
function initAdvancedScrollEffects() {
    initScrollProgress();
    initSectionColorChanges();
    initScrollReveal();
}

function initScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    document.body.appendChild(progressBar);

    let ticking = false;

    function updateProgress() {
        const scrollTop = window.pageYOffset;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrollPercent = (scrollTop / docHeight) * 100;
        
        progressBar.style.width = `${Math.min(scrollPercent, 100)}%`;
        
        // Add glow effect when near completion
        if (scrollPercent > 90) {
            progressBar.style.boxShadow = '0 0 20px var(--secondary-orange)';
        } else {
            progressBar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        }
        
        ticking = false;
    }

    function requestProgressUpdate() {
        if (!ticking) {
            requestAnimationFrame(updateProgress);
            ticking = true;
        }
    }

    window.addEventListener('scroll', requestProgressUpdate, { passive: true });
}

function initSectionColorChanges() {
    const navbar = document.querySelector('.navbar');
    const sections = document.querySelectorAll('section');
    
    if (!navbar) return;
    
    let ticking = false;

    function updateNavbar() {
        const scrollPos = window.pageYOffset + 100;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            
            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                const sectionId = section.id;
                
                // Enhanced navbar styling based on section
                if (sectionId === 'home') {
                    navbar.style.background = 'rgba(255, 255, 255, 0.1)';
                    navbar.style.backdropFilter = 'blur(20px) saturate(180%)';
                } else {
                    navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                    navbar.style.backdropFilter = 'blur(25px) saturate(200%)';
                }
            }
        });
        
        ticking = false;
    }

    function requestNavbarUpdate() {
        if (!ticking) {
            requestAnimationFrame(updateNavbar);
            ticking = true;
        }
    }
    
    window.addEventListener('scroll', requestNavbarUpdate, { passive: true });
}

function initScrollReveal() {
    // Reveal elements as they come into view
    const revealElements = document.querySelectorAll('.service-features li, .about-certifications li');
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateX(0) scale(1)';
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    revealElements.forEach((element, index) => {
        element.style.opacity = '0';
        element.style.transform = 'translateX(-30px) scale(0.9)';
        element.style.transition = `opacity 600ms ease ${index * 100}ms, transform 600ms cubic-bezier(0.68, -0.55, 0.265, 1.55) ${index * 100}ms`;
        revealObserver.observe(element);
    });
}

// ===== ENHANCED LOADING ANIMATIONS =====
function initLoadingAnimations() {
    // Enhanced page load sequence
    const loadSequence = [
        { selector: '.nav-logo', delay: 0, animation: 'slideDown' },
        { selector: '.nav-menu', delay: 200, animation: 'slideDown' },
        { selector: '.hero-content', delay: 600, animation: 'fadeInUp' },
        { selector: '.scroll-indicator', delay: 1200, animation: 'bounce' }
    ];
    
    loadSequence.forEach(({ selector, delay, animation }) => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            applyLoadAnimation(element, animation, delay);
        });
    });
}

function applyLoadAnimation(element, animationType, delay) {
    const animations = {
        slideDown: {
            initial: { opacity: '0', transform: 'translateY(-50px)' },
            final: { opacity: '1', transform: 'translateY(0)' }
        },
        fadeInUp: {
            initial: { opacity: '0', transform: 'translateY(50px) scale(0.9)' },
            final: { opacity: '1', transform: 'translateY(0) scale(1)' }
        },
        bounce: {
            initial: { opacity: '0', transform: 'scale(0.3)' },
            final: { opacity: '1', transform: 'scale(1)' }
        }
    };
    
    const animation = animations[animationType];
    if (!animation) return;
    
    // Apply initial state
    Object.assign(element.style, animation.initial);
    element.style.transition = 'all 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
    
    // Apply final state after delay
    setTimeout(() => {
        Object.assign(element.style, animation.final);
    }, delay);
}

// ===== UTILITY FUNCTIONS =====
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

// ===== ENHANCED MOBILE TOUCH INTERACTIONS =====
function initMobileTouchInteractions() {
    // Enhanced touch feedback for mobile devices
    if ('ontouchstart' in window) {
        const touchElements = document.querySelectorAll('.service-card, .gallery-item, .nav-link, .hero-cta, .service-cta');
        
        touchElements.forEach(element => {
            element.addEventListener('touchstart', function() {
                this.style.transform = 'scale(0.98)';
                this.style.transition = 'transform 0.1s ease';
            }, { passive: true });
            
            element.addEventListener('touchend', function() {
                this.style.transform = 'scale(1)';
                this.style.transition = 'transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
            }, { passive: true });
            
            element.addEventListener('touchcancel', function() {
                this.style.transform = 'scale(1)';
                this.style.transition = 'transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
            }, { passive: true });
        });
    }
    
    // Enhanced swipe gestures for gallery
    initSwipeGestures();
}

function initSwipeGestures() {
    const gallery = document.querySelector('.gallery-grid');
    if (!gallery) return;
    
    let startX = 0;
    let startY = 0;
    let distX = 0;
    let distY = 0;
    let threshold = 150;
    let restraint = 100;
    let allowedTime = 300;
    let elapsedTime = 0;
    let startTime = 0;
    
    gallery.addEventListener('touchstart', function(e) {
        const touchobj = e.changedTouches[0];
        startX = touchobj.pageX;
        startY = touchobj.pageY;
        startTime = new Date().getTime();
    }, { passive: true });
    
    gallery.addEventListener('touchend', function(e) {
        const touchobj = e.changedTouches[0];
        distX = touchobj.pageX - startX;
        distY = touchobj.pageY - startY;
        elapsedTime = new Date().getTime() - startTime;
        
        if (elapsedTime <= allowedTime) {
            if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) {
                // Horizontal swipe detected
                if (distX > 0) {
                    // Right swipe - could trigger previous gallery action
                    gallery.style.transform = 'translateX(10px)';
                } else {
                    // Left swipe - could trigger next gallery action
                    gallery.style.transform = 'translateX(-10px)';
                }
                
                setTimeout(() => {
                    gallery.style.transform = 'translateX(0)';
                }, 200);
            }
        }
    }, { passive: true });
}

// ===== PROGRESSIVE IMAGE LOADING =====
function initProgressiveImageLoading() {
    const images = document.querySelectorAll('img[src*="picsum"]');
    
    images.forEach(img => {
        // Create low-quality placeholder
        const placeholder = new Image();
        const lowQualitySrc = img.src.replace(/\d+x\d+/, '50x50');
        
        // Apply initial blur effect
        img.style.filter = 'blur(10px)';
        img.style.transition = 'filter 0.8s ease, opacity 0.8s ease';
        img.style.opacity = '0.7';
        
        // Load low quality first
        placeholder.onload = function() {
            img.src = placeholder.src;
            img.style.opacity = '1';
            
            // Then load high quality
            const highQualityImg = new Image();
            highQualityImg.onload = function() {
                img.src = highQualityImg.src;
                img.style.filter = 'blur(0px)';
                img.style.opacity = '1';
            };
            highQualityImg.src = img.dataset.src || img.src.replace('50x50', img.naturalWidth + 'x' + img.naturalHeight);
        };
        placeholder.src = lowQualitySrc;
    });
}

// ===== ENHANCED SCROLL PROGRESS STYLES =====
function addScrollProgressStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .scroll-progress {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-blue), var(--secondary-orange));
            z-index: 10001;
            transition: width 0.1s ease-out, box-shadow 0.3s ease;
            border-radius: 0 2px 2px 0;
        }
        
        .scroll-progress::after {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 20px;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3));
            border-radius: 0 2px 2px 0;
        }
    `;
    document.head.appendChild(style);
}

// ===== PERFORMANCE OPTIMIZATIONS =====
function initPerformanceOptimizations() {
    // Add CSS containment and will-change properties
    const style = document.createElement('style');
    style.textContent = `
        /* Performance optimizations */
        .service-card,
        .gallery-item,
        .hero-content,
        .nav-menu {
            contain: layout style paint;
        }
        
        .service-card:hover,
        .gallery-item:hover,
        .nav-link:hover,
        .hero-cta:hover,
        .service-cta:hover {
            will-change: transform, box-shadow, filter;
        }
        
        .hero-background {
            will-change: transform, opacity;
            contain: layout style paint;
        }
        
        .lightbox-image {
            will-change: transform, filter;
        }
        
        /* Enhanced card shadows and depth */
        .service-card {
            box-shadow: 
                0 4px 20px rgba(0, 0, 0, 0.08),
                0 1px 3px rgba(0, 0, 0, 0.1);
            transition: 
                transform 0.4s cubic-bezier(0.4, 0, 0.2, 1),
                box-shadow 0.4s cubic-bezier(0.4, 0, 0.2, 1),
                filter 0.4s ease;
        }
        
        .service-card:hover {
            box-shadow: 
                0 20px 40px rgba(0, 0, 0, 0.15),
                0 8px 16px rgba(0, 0, 0, 0.1),
                0 0 0 1px rgba(255, 255, 255, 0.1);
            filter: brightness(1.02);
        }
        
        .gallery-item {
            box-shadow: 
                0 8px 25px rgba(0, 0, 0, 0.12),
                0 3px 6px rgba(0, 0, 0, 0.08);
            transition: 
                transform 0.4s cubic-bezier(0.4, 0, 0.2, 1),
                box-shadow 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .gallery-item:hover {
            box-shadow: 
                0 25px 50px rgba(0, 0, 0, 0.2),
                0 12px 24px rgba(0, 0, 0, 0.15);
        }
        
        /* Enhanced typography hierarchy */
        .hero-title {
            font-weight: 700;
            letter-spacing: -0.02em;
            line-height: 1.1;
            text-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }
        
        .section-header h2 {
            font-weight: 600;
            letter-spacing: -0.01em;
            line-height: 1.2;
        }
        
        .service-card h3 {
            font-weight: 600;
            letter-spacing: -0.005em;
            line-height: 1.3;
        }
        
        /* Improved spacing */
        .section-header {
            margin-bottom: 3rem;
        }
        
        .service-card {
            margin-bottom: 2rem;
        }
        
        .gallery-item {
            margin-bottom: 1.5rem;
        }
        
        /* Mobile-first responsive enhancements */
        @media (max-width: 768px) {
            .service-card:hover {
                transform: translateY(-5px) scale(1.02);
            }
            
            .gallery-item:hover {
                transform: scale(1.05);
            }
            
            .hero-title {
                font-size: clamp(2rem, 8vw, 3.5rem);
            }
            
            .section-header h2 {
                font-size: clamp(1.8rem, 6vw, 2.5rem);
            }
        }
        
        /* Reduced motion preferences */
        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }
    `;
    document.head.appendChild(style);
}

// ===== STICKY NAVIGATION ENHANCEMENTS =====
function initStickyNavigation() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;
    
    let lastScrollY = window.pageYOffset;
    let ticking = false;
    
    function updateNavbar() {
        const scrollY = window.pageYOffset;
        const scrollDirection = scrollY > lastScrollY ? 'down' : 'up';
        const scrollDistance = Math.abs(scrollY - lastScrollY);
        
        // Enhanced sticky behavior
        if (scrollY > 100) {
            navbar.classList.add('navbar-scrolled');
            
            // Hide navbar on scroll down, show on scroll up
            if (scrollDirection === 'down' && scrollDistance > 10) {
                navbar.style.transform = 'translateY(-100%)';
            } else if (scrollDirection === 'up' && scrollDistance > 10) {
                navbar.style.transform = 'translateY(0)';
            }
        } else {
            navbar.classList.remove('navbar-scrolled');
            navbar.style.transform = 'translateY(0)';
        }
        
        lastScrollY = scrollY;
        ticking = false;
    }
    
    function requestNavbarUpdate() {
        if (!ticking) {
            requestAnimationFrame(updateNavbar);
            ticking = true;
        }
    }
    
    // Enhanced navbar styles
    const navbarStyles = `
        <style>
            .navbar {
                transition: 
                    transform 0.3s cubic-bezier(0.4, 0, 0.2, 1),
                    background 0.3s ease,
                    backdrop-filter 0.3s ease,
                    box-shadow 0.3s ease;
                will-change: transform, background, backdrop-filter;
            }
            
            .navbar-scrolled {
                background: rgba(255, 255, 255, 0.95) !important;
                backdrop-filter: blur(20px) saturate(180%) !important;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1) !important;
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            }
        </style>
    `;
    document.head.insertAdjacentHTML('beforeend', navbarStyles);
    
    window.addEventListener('scroll', requestNavbarUpdate, { passive: true });
}

// ===== SMOOTH SCROLL BEHAVIOR =====
function initSmoothScrollBehavior() {
    // Enhanced smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const navbar = document.querySelector('.navbar');
                const navbarHeight = navbar ? navbar.offsetHeight : 0;
                const targetPosition = targetSection.offsetTop - navbarHeight - 20;
                
                // Enhanced smooth scroll with easing
                smoothScrollTo(targetPosition, 1000);
            }
        });
    });
}

function smoothScrollTo(targetPosition, duration) {
    const startPosition = window.pageYOffset;
    const distance = targetPosition - startPosition;
    let startTime = null;
    
    function animation(currentTime) {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const progress = Math.min(timeElapsed / duration, 1);
        
        // Enhanced easing function
        const easeInOutCubic = progress < 0.5 
            ? 4 * progress * progress * progress 
            : 1 - Math.pow(-2 * progress + 2, 3) / 2;
        
        window.scrollTo(0, startPosition + distance * easeInOutCubic);
        
        if (timeElapsed < duration) {
            requestAnimationFrame(animation);
        }
    }
    
    requestAnimationFrame(animation);
}

// ===== MAIN INITIALIZATION =====
function initAllAnimations() {
    // Wait for DOM to be fully loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAllAnimations);
        return;
    }
    
    // Initialize all animation systems
    try {
        addScrollProgressStyles();
        initPerformanceOptimizations();
        initStickyNavigation();
        initSmoothScrollBehavior();
        initScrollAnimations();
        initAdvancedParallaxEffect();
        initCounterAnimations();
        initGalleryLightbox();
        initMicroInteractions();
        initAdvancedScrollEffects();
        initLoadingAnimations();
        initMobileTouchInteractions();
        initProgressiveImageLoading();
        
        console.log('🎨 All animations initialized successfully');
    } catch (error) {
        console.error('❌ Error initializing animations:', error);
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAllAnimations);
} else {
    initAllAnimations();
}

// Export functions for external use
window.SnakeRiverAnimations = {
    init: initAllAnimations,
    scrollAnimations: initScrollAnimations,
    parallax: initAdvancedParallaxEffect,
    lightbox: initGalleryLightbox,
    microInteractions: initMicroInteractions,
    mobileTouch: initMobileTouchInteractions,
    progressiveLoading: initProgressiveImageLoading
};
