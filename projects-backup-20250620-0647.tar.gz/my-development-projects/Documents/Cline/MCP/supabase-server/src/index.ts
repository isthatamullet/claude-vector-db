#!/usr/bin/env node

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  McpError,
  ErrorCode,
} from "@modelcontextprotocol/sdk/types.js";
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  throw new Error('SUPABASE_URL and SUPABASE_ANON_KEY environment variables are required');
}

const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

interface SelectArgs {
  tableName: string;
  columns?: string;
  filters?: { [key: string]: any };
}

interface InsertArgs {
  tableName: string;
  data: object[];
}

interface UpdateArgs {
  tableName: string;
  data: object;
  filters: { [key: string]: any };
}

interface DeleteArgs {
  tableName: string;
  filters: { [key: string]: any };
}

interface AuthArgs {
  email?: string;
  password?: string;
}

class SupabaseServer {
  private server: Server;

  constructor() {
    this.server = new Server(
      {
        name: "supabase-server",
        version: "0.1.0",
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupToolHandlers();
    
    this.server.onerror = (error) => console.error('[MCP Error]', error);
    process.on('SIGINT', async () => {
      await this.server.close();
      process.exit(0);
    });
  }

  private setupToolHandlers() {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: [
        {
          name: 'select_from_table',
          description: 'Selects data from a specified table with optional filters and columns.',
          inputSchema: {
            type: 'object',
            properties: {
              tableName: { type: 'string', description: 'The name of the table to select from.' },
              columns: { type: 'string', description: 'Comma-separated list of columns to select (e.g., "id,name,email"). Defaults to "*" for all columns.' },
              filters: { type: 'object', description: 'JSON object for filtering (e.g., { "column": "value" }). Supports "eq", "neq", "gt", "lt", "gte", "lte", "like", "ilike", "is", "in", "cs", "cd", "ov", "sl", "sr", "nx", "adj", "not", "or", "and".' },
            },
            required: ['tableName'],
          },
        },
        {
          name: 'insert_into_table',
          description: 'Inserts one or more rows into a specified table.',
          inputSchema: {
            type: 'object',
            properties: {
              tableName: { type: 'string', description: 'The name of the table to insert into.' },
              data: { type: 'array', items: { type: 'object' }, description: 'An array of JSON objects representing the rows to insert.' },
            },
            required: ['tableName', 'data'],
          },
        },
        {
          name: 'update_table',
          description: 'Updates rows in a specified table based on filters.',
          inputSchema: {
            type: 'object',
            properties: {
              tableName: { type: 'string', description: 'The name of the table to update.' },
              data: { type: 'object', description: 'JSON object of the columns and values to update.' },
              filters: { type: 'object', description: 'JSON object for filtering which rows to update (e.g., { "id": 1 }).' },
            },
            required: ['tableName', 'data', 'filters'],
          },
        },
        {
          name: 'delete_from_table',
          description: 'Deletes rows from a specified table based on filters.',
          inputSchema: {
            type: 'object',
            properties: {
              tableName: { type: 'string', description: 'The name of the table to delete from.' },
              filters: { type: 'object', description: 'JSON object for filtering which rows to delete (e.g., { "id": 1 }).' },
            },
            required: ['tableName', 'filters'],
          },
        },
        {
          name: 'sign_up',
          description: 'Signs up a new user with email and password.',
          inputSchema: {
            type: 'object',
            properties: {
              email: { type: 'string', description: 'User email.' },
              password: { type: 'string', description: 'User password.' },
            },
            required: ['email', 'password'],
          },
        },
        {
          name: 'sign_in_with_password',
          description: 'Signs in a user with email and password.',
          inputSchema: {
            type: 'object',
            properties: {
              email: { type: 'string', description: 'User email.' },
              password: { type: 'string', description: 'User password.' },
            },
            required: ['email', 'password'],
          },
        },
        {
          name: 'sign_out',
          description: 'Signs out the current user.',
          inputSchema: { type: 'object', properties: {} },
        },
        {
          name: 'get_user',
          description: 'Retrieves the currently authenticated user.',
          inputSchema: { type: 'object', properties: {} },
        },
      ],
    }));

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      try {
        let result;
        const args = request.params.arguments as Record<string, any> | undefined;

        if (!args) {
          throw new McpError(ErrorCode.InvalidParams, 'Arguments are required for this tool.');
        }

        switch (request.params.name) {
          case 'select_from_table': {
            const { tableName, columns, filters } = args;
            if (typeof tableName !== 'string') throw new McpError(ErrorCode.InvalidParams, 'tableName is required and must be a string.');
            let query = supabase.from(tableName).select(columns || '*');
            if (filters) {
              for (const key in filters) {
                const filterValue = filters[key];
                if (typeof filterValue === 'object' && filterValue !== null) {
                  const operator = Object.keys(filterValue)[0];
                  const value = filterValue[operator];
                  (query as any)[operator](key, value);
                } else {
                  query = query.eq(key, filterValue);
                }
              }
            }
            result = await query;
            break;
          }
          case 'insert_into_table': {
            const { tableName, data } = args;
            if (typeof tableName !== 'string') throw new McpError(ErrorCode.InvalidParams, 'tableName is required and must be a string.');
            if (!Array.isArray(data)) throw new McpError(ErrorCode.InvalidParams, 'data is required and must be an array.');
            result = await supabase.from(tableName).insert(data);
            break;
          }
          case 'update_table': {
            const { tableName, data, filters } = args;
            if (typeof tableName !== 'string') throw new McpError(ErrorCode.InvalidParams, 'tableName is required and must be a string.');
            if (typeof data !== 'object' || data === null) throw new McpError(ErrorCode.InvalidParams, 'data is required and must be an object.');
            if (typeof filters !== 'object' || filters === null) throw new McpError(ErrorCode.InvalidParams, 'filters are required and must be an object.');
            let query = supabase.from(tableName).update(data);
            if (filters) {
              for (const key in filters) {
                const filterValue = filters[key];
                if (typeof filterValue === 'object' && filterValue !== null) {
                  const operator = Object.keys(filterValue)[0];
                  const value = filterValue[operator];
                  (query as any)[operator](key, value);
                } else {
                  query = query.eq(key, filterValue);
                }
              }
            }
            result = await query;
            break;
          }
          case 'delete_from_table': {
            const { tableName, filters } = args;
            if (typeof tableName !== 'string') throw new McpError(ErrorCode.InvalidParams, 'tableName is required and must be a string.');
            if (typeof filters !== 'object' || filters === null) throw new McpError(ErrorCode.InvalidParams, 'filters are required and must be an object.');
            let query = supabase.from(tableName).delete();
            if (filters) {
              for (const key in filters) {
                const filterValue = filters[key];
                if (typeof filterValue === 'object' && filterValue !== null) {
                  const operator = Object.keys(filterValue)[0];
                  const value = filterValue[operator];
                  (query as any)[operator](key, value);
                } else {
                  query = query.eq(key, filterValue);
                }
              }
            }
            result = await query;
            break;
          }
          case 'sign_up': {
            const { email, password } = args;
            if (typeof email !== 'string' || typeof password !== 'string') throw new McpError(ErrorCode.InvalidParams, 'Email and password are required and must be strings.');
            result = await supabase.auth.signUp({ email, password });
            break;
          }
          case 'sign_in_with_password': {
            const { email, password } = args;
            if (typeof email !== 'string' || typeof password !== 'string') throw new McpError(ErrorCode.InvalidParams, 'Email and password are required and must be strings.');
            result = await supabase.auth.signInWithPassword({ email, password });
            break;
          }
          case 'sign_out':
            result = await supabase.auth.signOut();
            break;
          case 'get_user':
            result = await supabase.auth.getUser();
            break;
          default:
            throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${request.params.name}`);
        }

        // Safely access data and error properties
        if ((result as any).error) {
          return {
            content: [{ type: 'text', text: JSON.stringify((result as any).error, null, 2) }],
            isError: true,
          };
        } else {
          return {
            content: [{ type: 'text', text: JSON.stringify((result as any).data, null, 2) }],
          };
        }
      } catch (error: any) {
        throw new McpError(ErrorCode.InternalError, error.message || 'An unknown error occurred');
      }
    });
  }

  async run() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error('Supabase MCP server running on stdio');
  }
}

const server = new SupabaseServer();
server.run().catch(console.error);
